package com.flp.fms.domain;

import java.util.Date;
import java.util.List;
import java.util.Set;

public class Film {
	
	//System Generated
	private int film_Id;
	private String title;
	private String description;
	private Date realeaseYear;
	private List<Language> languages;
	private Language originalLanguage;
	private Date rentalDuration;
	private int length;
	private double replacementCost;
	private int ratings;
	private String specialFeatures;
	private Set<Actor> actors;
	private Category category;
	
	public Film(){}
	
	
	public Film(int film_Id, String title, String description, Date realeaseYear, List<Language> languages,
			Language originalLanguage, Date rentalDuration, int length, double replacementCost, int ratings,
			String specialFeatures, Set<Actor> actors, Category category) {
		super();
		this.film_Id = film_Id;
		this.title = title;
		this.description = description;
		this.realeaseYear = realeaseYear;
		this.languages = languages;
		this.originalLanguage = originalLanguage;
		this.rentalDuration = rentalDuration;
		this.length = length;
		this.replacementCost = replacementCost;
		this.ratings = ratings;
		this.specialFeatures = specialFeatures;
		this.actors = actors;
		this.category = category;
	}


	public int getFilm_Id() {
		return film_Id;
	}


	public void setFilm_Id(int film_Id) {
		this.film_Id = film_Id;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public Date getRealeaseYear() {
		return realeaseYear;
	}


	public void setRealeaseYear(Date realeaseYear) {
		this.realeaseYear = realeaseYear;
	}


	public List<Language> getLanguages() {
		return languages;
	}


	public void setLanguages(List<Language> languages) {
		this.languages = languages;
	}


	public Language getOriginalLanguage() {
		return originalLanguage;
	}


	public void setOriginalLanguage(Language originalLanguage) {
		this.originalLanguage = originalLanguage;
	}


	public Date getRentalDuration() {
		return rentalDuration;
	}


	public void setRentalDuration(Date rentalDuration) {
		this.rentalDuration = rentalDuration;
	}


	public int getLength() {
		return length;
	}


	public void setLength(int length) {
		this.length = length;
	}


	public double getReplacementCost() {
		return replacementCost;
	}


	public void setReplacementCost(double replacementCost) {
		this.replacementCost = replacementCost;
	}


	public int getRatings() {
		return ratings;
	}


	public void setRatings(int ratings) {
		this.ratings = ratings;
	}


	public String getSpecialFeatures() {
		return specialFeatures;
	}


	public void setSpecialFeatures(String specialFeatures) {
		this.specialFeatures = specialFeatures;
	}


	public Set<Actor> getActors() {
		return actors;
	}


	public void setActors(Set<Actor> actors) {
		this.actors = actors;
	}


	public Category getCategory() {
		return category;
	}


	public void setCategory(Category category) {
		this.category = category;
	}


	@Override
	public String toString() {
		return "Film [film_Id=" + film_Id + ", title=" + title + ", description=" + description + ", realeaseYear="
				+ realeaseYear + ", languages=" + languages + ", originalLanguage=" + originalLanguage
				+ ", rentalDuration=" + rentalDuration + ", length=" + length + ", replacementCost=" + replacementCost
				+ ", ratings=" + ratings + ", specialFeatures=" + specialFeatures + ", actors=" + actors + ", category="
				+ category + "]";
	}
	
	
	

}
