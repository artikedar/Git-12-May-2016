package org.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.pojo.LoginUser;
import org.capgemini.service.LoginServiceImpl;

/**
 * Servlet implementation class ListAllServlet
 */
public class ListAllServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		LoginServiceImpl loginServiceImpl=new LoginServiceImpl();
		ArrayList<LoginUser> loginuser=loginServiceImpl.getAllDetails();
		PrintWriter out=response.getWriter();
		
		out.println("<html>"
				+ "<head>"
				+ "<body>"
				+ "<table>"
				+ "<tr>"
				+ "<th>Customer Id</th>"
				+ "<th>Customer First Name</th>"
				+ "<th>Customer Last Name</th>"
				+ "<th>Customer Address</th>"
				+ "<th>Gender</th>"
				+ "<th>Registration Date</th>"
				+ "<th>Registration Fees</th>"
				+ "<th>Customer Type</th>"
				+ "</tr>"
				);
		for(LoginUser log:loginuser){
			out.println("<tr>"
					+"<td>"+log.getCustId()+"</td>"
							+ "<td>"+log.getCustFName()+"</td>"
							+ "<td>"+log.getCustLName()+"</td>"
							+ "<td>"+log.getCustAddr()+"</td>"
							+ "<td>"+log.getGender()+"</td>"
							+ "<td>"+log.getRegDate()+"</td>"
							+ "<td>"+log.getRegFees()+"</td>"
							+ "<td>"+log.getCustType()+"</td>"
									+ "</tr>"
					);
		
			
			
		}
		out.println("</table></body>");
		out.println("</html>");
		
	}

}
