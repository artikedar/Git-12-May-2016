package org.capgemini.service;

import java.util.ArrayList;

import org.capgemini.pojo.LoginUser;

public interface LoginService {

	public void createForm(LoginUser loginUser);
	
	public ArrayList<LoginUser> getAllDetails();
	void deleteForm(int custId);
	ArrayList<LoginUser> searchForm(int custId);
	
}
