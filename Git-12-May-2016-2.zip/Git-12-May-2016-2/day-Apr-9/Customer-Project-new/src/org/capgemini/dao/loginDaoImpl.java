package org.capgemini.dao;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.capgemini.pojo.LoginUser;

import com.sun.javafx.scene.control.skin.CustomColorDialog;

import jdk.nashorn.internal.ir.RuntimeNode.Request;

public class loginDaoImpl implements LoginDao{

	public Connection getConnection(){ 
		Connection connection=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/cap", "root", "Pass1234");
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return connection;
		
	}
	
	
	@Override
	public void createForm(LoginUser loginUser) {
		Connection con=getConnection();
		String sql="insert into loginUser(custFName,custLName,custAddr,gender,regDate,regFees,custType)" + "values(?,?,?,?,?,?,?)";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setString(1, loginUser.getCustFName()); 
			pst.setString(2, loginUser.getCustLName());
			pst.setString(3, loginUser.getCustAddr());
			pst.setString(4, loginUser.getGender());
			pst.setDate(5,new Date(loginUser.getRegDate().getTime()));
			pst.setDouble(6, loginUser.getRegFees());
			pst.setString(7, loginUser.getCustType());
			
			int count=pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	

	@Override
	public ArrayList<LoginUser> getAllDetails() {
		ArrayList<LoginUser> loginUser=new ArrayList<>();
		Connection con=getConnection();
		String sql="select * from loginUser";
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next()){
				LoginUser loginUser1=new LoginUser();
				loginUser1.setCustId(rs.getInt(1));
				loginUser1.setCustFName(rs.getString(2));
				loginUser1.setCustLName(rs.getString(3));
				loginUser1.setCustAddr(rs.getString(4));
				loginUser1.setGender(rs.getString(5));
				loginUser1.setRegDate((rs.getDate(6).valueOf(rs.getDate(6).toString())));
				loginUser1.setRegFees(rs.getDouble(7));
				loginUser1.setCustType(rs.getString(8));				
				loginUser.add(loginUser1);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return loginUser;
	}


	@Override
	public ArrayList<LoginUser> searchForm(int custId) {
		ArrayList<LoginUser> loginUser=new ArrayList<>();
		LoginUser loginUser3=new LoginUser();
		Connection con = getConnection();
		String sql="search * from loginUser where custId=custId";
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next()){
				if(Integer.toString(custId).equals(rs.getString(1))){
					loginUser3.setCustId(rs.getInt(1));
					loginUser3.setCustFName(rs.getString(2));
					loginUser3.setCustLName(rs.getString(3));
					loginUser3.setCustAddr(rs.getString(4));
					loginUser3.setGender(rs.getString(5));
					loginUser3.setRegDate((rs.getDate(6).valueOf(rs.getDate(6).toString())));
					loginUser3.setRegFees(rs.getDouble(7));
					loginUser3.setCustType(rs.getString(8));				
					loginUser.add(loginUser3);	
				}
			}
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return loginUser;
	}
	



	




	
}

