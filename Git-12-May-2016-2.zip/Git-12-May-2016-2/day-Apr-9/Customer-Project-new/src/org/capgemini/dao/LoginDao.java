package org.capgemini.dao;

import java.util.ArrayList;

import org.capgemini.pojo.LoginUser;

public interface LoginDao {


	void createForm(LoginUser loginUser);
	ArrayList<LoginUser> getAllDetails();
	ArrayList<LoginUser> searchForm(int custId);

}
