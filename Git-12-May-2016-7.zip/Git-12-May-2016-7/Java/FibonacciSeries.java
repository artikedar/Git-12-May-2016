import java.util.Scanner;

public class FibonacciSeries
{
	public static void main(String[] args)
	{
		int length,fibo,fibo1=0,fibo2=1;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter Length: ");
		length=sc.nextInt();
		System.out.println("Fibonacci Series is: " );	
		System.out.println(+fibo1 );
		System.out.println(+fibo2 );	

		for(int i=0;i<length-2;i++)
		{
			fibo=fibo1+fibo2;
			fibo1=fibo2;
			fibo2=fibo;
			System.out.println(fibo);	
		}
	}
}