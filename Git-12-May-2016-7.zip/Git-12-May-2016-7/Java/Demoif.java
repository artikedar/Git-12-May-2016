Class Demoif{
	public static void main(String[] args){
	int num=34;
	if(num>0)
	System.out.println("Positive");	

	}


}