import java.util.Scanner;
public class SalaryBonus{
	public static void main(String[] args){
	
	String ename;
	double salary;
	double bonus;
	
	Scanner sc=new Scanner(System.in);
	
	System.out.println("Enter employee name: ");
	ename=sc.next();
	
	System.out.println("Enter Salary: ");
	salary=sc.nextDouble();

	if(salary>2000000){
		bonus=salary*.15;
		}
	else if(salary>1000000){
		bonus=salary*.2;
		}
	else if(salary>500000){
		bonus=salary*.25;
		}
	else{
		bonus=salary*.3;
		}
	System.out.println("Bonus is" + bonus);
	

	}

}