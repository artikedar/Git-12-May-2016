import java.util.Scanner;
public class StudentInfo{
	public static void main(String[] args){
	String firstName;
	String lastName;
	String address;
	int java;
	int servlets;
	int html;
	int total;
	float avg;
Scanner sc= new Scanner(System.in);
System.out.println("Enter First Name: ");
firstName=sc.nextLine();

System.out.println("Enter Last Name: ");
lastName=sc.nextLine();

System.out.println("Enter Address: ");
address=sc.nextLine();

System.out.println("Enter Java Marks: ");
java=sc.nextInt();

System.out.println("Enter Servlets Marks: ");
servlets=sc.nextInt();

System.out.println("Enter HTML Marks: ");
html=sc.nextInt();

total = java + servlets + html;

System.out.println("Total: " + total);
avg= total/3;
System.out.println("Average: " + avg);

}


}