import java.util.Scanner;
public class NumberIntoWord
{
	public static void main(Strings[] args)
	{
		int number, units, tens, hundreds, thousands;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a four digit number: ");
		number=sc.nextInt();
		
		units=number%10;
		tens=number%100;
		hundreds=number%1000;
		thousands=number%10000;	
		
		switch(tens)
		{
			Case (1):
			{
				System.out.println("One");
				break;
			}
		
			Case (2):
			{
				System.out.println("Two");
				break;
			}
			Case (3):
			{
				System.out.println("Three");
				break;
			}
		
			Case (4):
			{
				System.out.println("Four");
				break;
			}
			Case (5):
			{
				System.out.println("Five");
				break;
			}
		
			Case (6):
			{
				System.out.println("Six");
				break;
			}
			Case (7):
			{
				System.out.println("Seven");
				break;
			}
		
			Case (8):
			{
				System.out.println("Eight");
				break;
			}
			Case (9):
			{
				System.out.println("Nine");
				break;
			}
		
			Case (default):
			{
				System.out.println(" ");
				break;
			}		


		switch(units)
		{
			Case (1):
			{
				System.out.println("One");
				break;
			}
		
			Case (2):
			{
				System.out.println("Two");
				break;
			}
			Case (3):
			{
				System.out.println("Three");
				break;
			}
		
			Case (4):
			{
				System.out.println("Four");
				break;
			}
			Case (5):
			{
				System.out.println("Five");
				break;
			}
		
			Case (6):
			{
				System.out.println("Six");
				break;
			}
			Case (7):
			{
				System.out.println("Seven");
				break;
			}
		
			Case (8):
			{
				System.out.println("Eight");
				break;
			}
			Case (9):
			{
				System.out.println("Nine");
				break;
			}
		
			Case (default):
			{
				System.out.println(" ");
				break;
			}



		}

	}		
}