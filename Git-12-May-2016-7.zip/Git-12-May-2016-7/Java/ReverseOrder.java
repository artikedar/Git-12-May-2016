import java.util.Scanner;
public class ReverseOrder{
	public static void main(String [] args){
		int i;
		final int SIZE=10;
	
		Scanner sc=new Scanner(System.in);
		int myArr[]=new int[SIZE];
		
		System.out.println("Enter 10 numbers: ");
		
		for (i=0;i<myArr.length;i++)
		{
			myArr[i]=sc.nextInt();
		}
		for (i=myArr.length-1;i>=0;i--)
		{
			System.out.println(myArr[i]);
		}
	
	}

}
