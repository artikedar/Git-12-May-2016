public class DigitalNum{
	public static void main(String[] args){
		int row=5,j;
		
		for(j=0;j<row;j++){
			System.out.println("*");
			}
			
		





	}








}