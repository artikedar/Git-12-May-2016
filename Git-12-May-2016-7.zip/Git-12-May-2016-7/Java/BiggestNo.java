public class BiggestNo{

	public static void main(String[] args){
	int a=10;
	int b=20;
	int c=30;
	

	if(a>b){
		if(a>c){
			System.out.println("Biggest no. is a");
			}
		
		}
	else if(b>c){
		System.out.println("Biggest no. is b");

		}
		

	System.out.println("Biggest no. is c");	

	}



}