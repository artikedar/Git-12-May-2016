import java.util.Scanner;
public class OddNoArray
{
	public static void main(String[] args)
	{
		int i,sum=0;
		final int SIZE=10;
		
		Scanner sc= new Scanner(System.in);
		int myArr[]=new int[SIZE];
		
		System.out.println("Enter 10 numbers: ");
		
		for(i=0;i<myArr.length;i++)
		{
			myArr[i]=sc.nextInt();
		}
		
		for(i=0;i<myArr.length;i++)
		{
			if(myArr[i]%2!=0)
			{
				System.out.println(myArr[i]);
				
			}
		}
		

	}
}