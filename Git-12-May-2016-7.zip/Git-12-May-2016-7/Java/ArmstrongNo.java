public class ArmstrongNo{
	public static void main(String[] args){
	 
	int units;
	int tens;
	int hundreds;
	int thousands;
	int armstrong;
	int original;
	int i;
	int temp;
	for(i=1;i<1000;i++){
		original=i;
		temp=i;
		units=original%10;
		original=original/10;
		tens=original%10;
		original=original/10;
		hundreds=original%10;
		original=original/10;
		thousands=original%10;
		armstrong=((units*units*units)+(tens*tens*tens)+(hundreds*hundreds*hundreds)+(thousands*thousands*thousands));
	    if(armstrong==temp){
			System.out.println(temp);
			}                                                                                                                                          

	
	}
	System.out.println("Loop Completed");
	
	}

}