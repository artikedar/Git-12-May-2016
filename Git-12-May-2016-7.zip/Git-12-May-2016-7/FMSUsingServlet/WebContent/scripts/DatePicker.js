$(document).ready(
  
  
  function () {
    $( "#datepicker" ).datepicker({
    });
  }
);
$(document).ready(
		  
		  
		  function () {
		    $( "#datepicker1" ).datepicker({
		    });
		  }
		);