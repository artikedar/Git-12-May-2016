package com.flp.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.flp.fms.Dao.FilmDaoImpForOrgLang;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class FilmServiceImp implements IFilmService{

	private FilmDaoImpForOrgLang filmDao= new FilmDaoImpForOrgLang();
	@Override
	public List<Language> getLanguage() {
		return filmDao.getOriginalLanguage();
	}
	@Override
	public List<Category> getCategory() {
		return filmDao.getCategory();
	}
	
	//add Film object in table FILM
	@Override
	public int addFilm(Film film) {
		
		/*film.setFilm_Id(generate_Film_Id());*/
		//return filmDao.addFilm(film);
		return filmDao.addFilm(film);
		
	}
	/*private int generate_Film_Id() {
		int filmId=0;
		//Verify filmId has been Duplicated or not
				do{
					double fid=Math.random()*1000;
					filmId=(int)fid;
				}while(checkDuplicateFilmId(filmId));
				
				
				return filmId;
		
	}*/
	
	@Override
	public List<Film> getAllFilms() {
		
		return filmDao.getAllFilms();
	}
	/*private boolean checkDuplicateFilmId(int filmId) {
		
		
		Set<Integer>keys=filmDao.getAllFilms().keySet();
		boolean flag=false;
		if(keys.isEmpty() || keys==null){
			flag= false;
		}else{
			for(Integer key:keys){
				if(key==filmId){
					flag=true;
					break;
				}
			}
		}
		
		return flag;
		
	}*/
	@Override
	public Map<Integer, Film> searchFilms() {
		// TODO Auto-generated method stub
		return filmDao.searchFilm();
	}
	@Override
	public int removeFilm(int id) {
		// TODO Auto-generated method stub
		return filmDao.removeFilm(id);
	}

}
