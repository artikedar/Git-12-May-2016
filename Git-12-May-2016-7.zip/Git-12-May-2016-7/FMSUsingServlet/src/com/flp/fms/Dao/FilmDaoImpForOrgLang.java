package com.flp.fms.Dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import com.flp.fms.domain.Film;
import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;

public class FilmDaoImpForOrgLang implements IFilmDao{

	private Map<Integer, Film> film_Repository=new HashMap<>();
	@Override
	public List<Language> getOriginalLanguage() {
   
		List<Language>languages=new ArrayList<>();
		
		/*languages.add(new Language(1, "English"));
		languages.add(new Language(2, "Hindi"));
		languages.add(new Language(3, "Telegu"));
		languages.add(new Language(4, "Marati"));
		languages.add(new Language(5, "Kananta"));
		languages.add(new Language(6, "Tamil"));
		languages.add(new Language(7, "Malayalam"));*/
		
		Connection con=getConnection();
		String sql="select * from LANGUAGE";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				Language lang=new Language();
				lang.setLanguage_Id(rs.getInt(1));
				lang.setLanguage_Name(rs.getString(2));
				
				
				languages.add(lang);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return languages;
	}

	@Override
	public List<Category> getCategory() {
		List<Category> category=new ArrayList<>();
		
		Connection con=getConnection();
		String sql="select * from CATEGORY";
		/*category.add(new Category(1, "Comic"));
		category.add(new Category(2, "Horrer"));
		category.add(new Category(3, "Action"));*/
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				Category category1=new Category();
				category1.setCategory_Id(rs.getInt(1));
				category1.setCategory_Name(rs.getString(2));
				
				
				category.add(category1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return category;
	}
	
	//CURD Operation
		@Override
		public int addFilm(Film film) {
			
		
			Connection con=getConnection();
			String sql="insert into FILM(title,description,releaseYear,originalLanguage,rentalDuration,LENGTH,replacementCost,ratings,specialFeatures,category)"
					+ "	 values(?,?,?,?,?,?,?,?,?,?)";
			
			int count=0;
			try {
				PreparedStatement pst=con.prepareStatement(sql);
				pst.setString(1, film.getTitle());
				pst.setString(2, film.getDescription());
				pst.setDate(3, new Date(film.getRealeaseYear().getTime()));
				int language=film.getOriginalLanguage().getLanguage_Id();
				pst.setInt(4, language);
				pst.setDate(5, new Date(film.getRentalDuration().getTime()));
				pst.setInt(6, film.getLength());
				pst.setDouble(7,film.getReplacementCost());
				
				pst.setInt(8,film.getRatings());
				pst.setString(9,film.getSpecialFeatures());
				int category=film.getCategory().getCategory_Id();
				pst.setInt(10,category);
				count=pst.executeUpdate();
				
				
				//Fetching last film id 
				String sql1="select filmid from FILM order by filmid desc limit 1 ";
				PreparedStatement pst1=con.prepareStatement(sql1);
				ResultSet rs=pst1.executeQuery();
				int film_id=0;
				while(rs.next())
				{
					film_id=rs.getInt(1);
					
				}
				
				
				//insert into film_languages
				String sql2="insert into film_language values(?,?)";
				PreparedStatement pst2=con.prepareStatement(sql2);
			     List<Language> lang=film.getLanguages();
			     System.out.println(lang);
				for(Language lang1:lang){
				pst2.setInt(1, film_id);
				pst2.setInt(2,lang1.getLanguage_Id());
			    count=pst2.executeUpdate();
				}
				
				String sql3="insert into film_actors values(?,?)";
				PreparedStatement pst3=con.prepareStatement(sql3);
			    List<Actor> actor=film.getActors();
				for(Actor act1:actor){
				pst3.setInt(1, film_id);
				pst3.setInt(2,act1.getActor_Id());
				 count=pst3.executeUpdate();
				}
				
				
				
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(film);
			return count;
		}


		@Override
		public List<Film> getAllFilms() {
			
			Connection con=getConnection();
			List<Film> films=new ArrayList<>();
			String sql="select * from FILM";
			
			try {
				PreparedStatement pst=con.prepareStatement(sql);
				ResultSet rs=pst.executeQuery();
				while(rs.next()){
					Film film=new Film();
					film.setFilm_Id(rs.getInt(1));
					film.setTitle(rs.getString(2));
					film.setDescription(rs.getString(3));
					film.setRealeaseYear(rs.getDate(4).valueOf(rs.getDate(4).toString()));
					//Original Language
					int lang_id=rs.getInt(5);
					Language orgLang=getOrgLang(lang_id);
					film.setOriginalLanguage(orgLang);
					
					//Rental Duration
					film.setRentalDuration(rs.getDate(6).valueOf(rs.getDate(6).toString()));
					
					//length
					film.setLength(rs.getInt(7));
					
					//replacementCost
					film.setReplacementCost(rs.getDouble(8));
					
					//rating
					film.setRatings(rs.getInt(9));
					
					//Special Features
					film.setSpecialFeatures(rs.getString(10));
					
					int category_id=rs.getInt(11);
					Category category=getCategoryforListing(category_id);
					film.setCategory(category);
					
					//other Lang
					List<Integer> lang_ids=getLanguagesIDs(film.getFilm_Id());
					List<Language> lang_name=new ArrayList<>();
					for(Integer langid:lang_ids){
						lang_name.add(getOrgLang(langid));
					}
					film.setLanguages(lang_name);
					
					//Actors
					
					
					List<Actor> act=new ArrayList<>();
					List<Integer> actor_id=getActorIDS(film.getFilm_Id());
					for(Integer actor:actor_id){
						act.add(getActors(actor));
					}
					film.setActors(act);
					films.add(film);
					
					
				}
				
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
			
	
			return films;
			
		
		}
		
		
		private Actor getActors(int actor) {
			Actor actor1=new Actor();
			Connection con=getConnection();
			String str="select * from ACTOR where actorID=?";
			try {
				PreparedStatement pst=con.prepareStatement(str);
				pst.setInt(1, actor);
				ResultSet rs=pst.executeQuery();
				while(rs.next()){
					actor1.setActor_Fname(rs.getString(2));
					actor1.setActor_Lname(rs.getString(3));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return actor1;
		}

		private List<Integer> getActorIDS(int film_Id) {


			Connection con=getConnection();
			List<Integer> actorids=new ArrayList<>();
			String str="select * from film_actors where film_id=?";
			try {
				PreparedStatement pst=con.prepareStatement(str);
				pst.setInt(1, film_Id);
				ResultSet rs=pst.executeQuery();
				
				
				while(rs.next()){
					actorids.add(rs.getInt(2));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
			return actorids;
		}

		private List<Integer> getLanguagesIDs(int film_Id) {
			
			Connection con=getConnection();
			String str="select * from film_language where film_id=?";
			List<Integer> id=new ArrayList<>();
			try {
				PreparedStatement pst=con.prepareStatement(str);
				pst.setInt(1, film_Id);
				ResultSet rs=pst.executeQuery();
				
				
				while(rs.next()){
					id.add(rs.getInt(2));
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return id;
		}

		private Category getCategoryforListing(int category_id) {
			Connection con=getConnection();
			Category category=new Category();
			String str="select * from CATEGORY where categoryID=?";
			try {
				PreparedStatement pst=con.prepareStatement(str);
				pst.setInt(1, category_id);
				ResultSet rs=pst.executeQuery();
				
				while(rs.next()){
					category.setCategory_Name(rs.getString(2));
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return category;
		}

		public Language getOrgLang(int langid){
		
			
			Language lang=new Language();
			Connection con=getConnection();
			String str="select * from LANGUAGE where languageID=?";
			try {
				PreparedStatement pst=con.prepareStatement(str);
				pst.setInt(1, langid);
				ResultSet rs=pst.executeQuery();
				
				while(rs.next()){
					lang.setLanguage_Name(rs.getString(2));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return lang;
			
		}

		@Override
		public Map<Integer, Film> searchFilm() {
			return film_Repository;
			
		}

		@Override
		public int removeFilm(int id) {
			
			Connection con=getConnection();
			int count=0;
			
			String str="delete from FILM where filmid=?";
			String str1="delete from film_language where film_id=?";
			String str2="delete from film_actors where film_id=?";
			try {
				PreparedStatement pst=con.prepareStatement(str);
				pst.setInt(1, id);
			    count=pst.executeUpdate();
			    
			    
			    
			    PreparedStatement pst1=con.prepareStatement(str1);
			    pst1.setInt(1, id);
			    count=pst1.executeUpdate();
			    
			    
			    PreparedStatement pst2=con.prepareStatement(str2);
			    pst2.setInt(1, id);
			    count=pst2.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
			return count;
			
			
		}


		public Connection getConnection(){
			
			Connection connection=null;
			
			try {
				Class.forName("com.mysql.jdbc.Driver");
				connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/filmmanagementsystem","root","Pass1234");
				
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
			return connection;
		}
	
	

}
