CREATE TABLE user_details
(
	userName VARCHAR(20) NOT NULL,
	pswd VARCHAR(20)
);

INSERT INTO user_details VALUES('arti','1234');
SELECT * FROM user_details;
