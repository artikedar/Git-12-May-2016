package org.capgemini;

public class MainDemo{
	public static void main(String[] args){
		if(args.length>0){
			for(int i=0;i<args.length;i++)
				System.out.println(args[i]);
		}
		
		main(100,300);
	}

	
	public static void main(int num1,int num2){
		System.out.println("Answer:" + (num1+num2));
	}
	
}