package org.cap.student;

import java.util.Scanner;

public class StudentService {
	
	Student[] students;
	
	public void initializeArray(int size){
		students=new Student[size];
	}

	
	public void getStudents(){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter how many Stduents?");
		int size=sc.nextInt();
		
		initializeArray(size);
		
		for(int i=0;i<size;i++){
			
			students[i]=new Student();
			students[i].getStudentDetails();
			
		}
		
		
	}
	
	public void printStudents(){
		
		System.out.println("StudId \t FirstName \t LastName \t Fees");
		
		for(int i=0;i<students.length;i++)
			students[i].printStudentDetails();
			
		
	}
}
