package org.cap;

public class TestClass {

	public static void main(String[] args) {
		StringBuffer s1=new StringBuffer("Tom");
		System.out.println(s1);
		
					s1=s1.append("Jerry is learning Java programing.");
		
		System.out.println(s1);
		System.out.println("Length:" + s1.length());
		System.out.println("Capacity:" + s1.capacity());
		
		
		System.out.println(Math.random());
		System.out.println(Math.min(12.7, 56.7));
		
	}

}
