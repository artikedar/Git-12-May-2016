package flp.capgemini.demo;

class TestWhile2  {
            public static void main(String args[]) {
                         int i = 1, j = 2, k = 3;

                          while (i < j)
                                while (j < k)
                                       while (k < 4)
                                               System.out.println(i++ + " " + j++ + " " + k++);
            }
   }