package flp.capgemini.demo;

public  class Circle implements Shape,Color{

	@Override
	public void draw() {
		System.out.println("Draw Circle");
		
	}

	@Override
	public void findArea() {
		System.out.println("Area of Circle");
		
	}

	@Override
	public void fillColor() {
		System.out.println("Fill Circle");
		
	}

	@Override
	public void getColor() {
		System.out.println("Get Circle Color");
		
	}

	
	public void myCircleInfo(){
		System.out.println("Circle Class information");
	}

	@Override
	public void animate() {
		System.out.println("Animate Circle");
		
	}

	@Override
	public void move_shape() {
		System.out.println("Move Circle");
		
	}

	@Override
	public void getInfo() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void printInfo() {
		// TODO Auto-generated method stub
		
	}
	

}
