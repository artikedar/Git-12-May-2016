package flp.capgemini.demo;

public interface Color {
 void fillColor();
 void getColor();
}
