package org.capgemini.demo;

public abstract class MyClass {
	
	int count;
	
	public MyClass(){
		System.out.println("No Arg Constructor-MyClass");
	}

	public MyClass(int count){
		System.out.println("Arg Constructor");
		this.count=count;
	}
	
	public abstract int calculate(int num1,int num2);

}
