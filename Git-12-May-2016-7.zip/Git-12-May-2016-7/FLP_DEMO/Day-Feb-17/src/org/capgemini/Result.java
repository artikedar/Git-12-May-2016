package org.capgemini;

public class Result  extends Student{

	int total;
	
	public void calculateAverage(){
		
		getDetails();
		total=mark1+mark2+mark3;
		System.out.println("Avearge:" + (total/3));
	}
	
	public void printResult(){
		printDetails();
	}
}
