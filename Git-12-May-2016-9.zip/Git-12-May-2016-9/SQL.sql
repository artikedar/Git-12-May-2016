USE JavaFLp;
CREATE TABLE customer2(CID INT PRIMARY KEY, fn VARCHAR(20), LN VARCHAR(20), bill VARCHAR(20));
DROP TABLE customer;
SELECT * FROM customer1;
INSERT INTO customer2
VALUES(1,'Arti','Kedar',200) 
INSERT INTO customer2
VALUES(2,'Komal','Mishrikotkar',100); 
INSERT INTO customer2
VALUES(3,'Seema','Mane',200) ;
INSERT INTO customer2
VALUES(4,'Shubhangi','Madane',300) ;
INSERT INTO customer2
VALUES(5,'Pranjali','Dhore',400) ;
INSERT INTO customer2
VALUES(6,'Harshal','Soalo',600);                                                                                       