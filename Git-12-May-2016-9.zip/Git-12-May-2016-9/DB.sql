CREATE TABLE loginUser(custId INT PRIMARY KEY AUTO_INCREMENT,	
	custFName VARCHAR(20) NOT NULL,
	custLName VARCHAR(20) ,
	custAddr VARCHAR(20) ,
	gender VARCHAR(20) ,
	regDate DATE ,
	regFees DOUBLE ,
	custType VARCHAR(20));

SELECT * FROM loginUser;
DROP TABLE loginUser;


DESC loginUser;
