CREATE TABLE customer(
	customer_id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
	customer_email VARCHAR(500) NOT NULL UNIQUE,
	customer_password VARCHAR(50) NOT NULL,
	customer_firstname VARCHAR(50) NOT NULL,
	customer_lastname VARCHAR(50) NOT NULL,
	customer_city VARCHAR(50) NOT NULL,
	customer_state VARCHAR(50) NOT NULL,
	customer_pincode VARCHAR(50) NOT NULL,
	customer_emailverified TINYINT(1) DEFAULT 0,
	customer_regdate TIMESTAMP NOT NULL,
	customer_verificationcode VARCHAR(20),
	customer_phone VARCHAR(20) NOT NULL UNIQUE,
	customer_country VARCHAR(20) NOT NULL,
	customer_address VARCHAR(500) NOT NULL
	
);

INSERT INTO 




DROP TABLE customer;
SELECT * FROM customer;

CREATE TABLE merchant(
merchant_id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
merchant_firstname VARCHAR(50),
merchant_lastname VARCHAR(50),
company_name VARCHAR(200),
company_displayname VARCHAR(200),

company_zip VARCHAR(12),
company_city VARCHAR(90),
company_state VARCHAR(50),

merchant_password VARCHAR(50),
merchant_email_id VARCHAR(500),
merchant_pancard VARCHAR(100),
merchant_trade_license VARCHAR(100),
merchant_mobile_no VARCHAR(20)
);
DROP TABLE merchant;
SELECT * FROM merchant;

CREATE TABLE admin(
admin_id INT(11) PRIMARY KEY UNIQUE AUTO_INCREMENT,
admin_first_name VARCHAR(15) NOT NULL,
admin_last_name	VARCHAR(15) NOT NULL,
admin_mobile_number VARCHAR(15) UNIQUE NOT NULL,
admin_email_id VARCHAR(25) UNIQUE,
admin_password VARCHAR(15) UNIQUE NOT NULL	
);
DROP TABLE admin;
SELECT * FROM admin;

CREATE TABLE product(
	product_id 
	product_name
	category_id
	subCategory_id
	brand_id
	specification
	price
	dateOfPosting
	stock_id
	merchant_id
	no_Of_time_Visited

);
DROP TABLE product;
SELECT * FROM product;