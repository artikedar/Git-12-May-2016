CREATE TABLE Product(
	product_id INT PRIMARY KEY AUTO_INCREMENT,
	product_name VARCHAR(20),
	category_id INT,
	subCategory_id INT,
	brand_id INT,
	specification VARCHAR(20),
	price INT,
	dateOfPosting VARCHAR(20),
	stock_id INT,
	merchant_id INT,
	no_Of_time_Visited INT
);

INSERT INTO Product VALUES(1,'table',1,1,20,'wooden table','2000','2-May-2016',1,1,10);
INSERT INTO Product VALUES(2,'sofa',1,2,30,'wooden sofa','2000','2-May-2016',2,1,20);
INSERT INTO Product VALUES(3,'cupboard',1,3,40,'wooden cupboard','2000','2-May-2016',3,1,90);
INSERT INTO Product VALUES(4,'chair',1,4,50,'wooden chair','2000','2-May-2016',4,1,60);
INSERT INTO Product VALUES(5,'mobile',2,1,110,'samsung s4','2000','2-May-2016',5,2,70);
INSERT INTO Product VALUES(6,'laptop',2,2,120,'lenovo','2000','2-May-2016',6,3,40);
INSERT INTO Product VALUES(7,'harddisk',2,3,130,'hp','2000','2-May-2016',7,4,50);
INSERT INTO Product VALUES(8,'pendrive',2,4,140,'sandisk','2000','2-May-2016',8,5,60);
INSERT INTO Product VALUES(9,'cooker',3,1,220,'prestige','2000','2-May-2016',9,2,70);
INSERT INTO Product VALUES(10,'oven',2,1,530,'ifb','2000','2-May-2016',10,3,10);
INSERT INTO Product VALUES(11,'mixer',2,6,140,'phillips','2000','2-May-2016',11,4,6);
INSERT INTO Product VALUES(12,'heater',2,7,130,'ifb','2000','2-May-2016',12,5,3);
INSERT INTO Product VALUES(13,'bottle',3,2,230,'tupperware','2000','2-May-2016',13,6,7);
INSERT INTO Product VALUES(14,'headphone',2,8,170,'sony','2000','2-May-2016',14,7,45);
INSERT INTO Product VALUES(15,'speaker',2,9,190,'jbl','2000','2-May-2016',15,8,55);
INSERT INTO Product VALUES(16,'sdcard',2,10,130,'hp','2000','2-May-2016',16,9,77);

SELECT * FROM Product;
DROP TABLE Product;

CREATE TABLE Category(
	category_id INT PRIMARY KEY AUTO_INCREMENT,
	cateogry_name VARCHAR(20)
);

INSERT INTO Category VALUES(1,'Wooden Furniture');
INSERT INTO Category VALUES(2,'Electronics');
INSERT INTO Category VALUES(3,'KitchenWare');

SELECT * FROM Category;
DROP TABLE Category;

