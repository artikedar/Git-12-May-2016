USE StudentData
CREATE TABLE student_details
(
	StuId INT NOT NULL UNIQUE KEY,
	RollNo INT NOT NULL PRIMARY KEY,
	FName VARCHAR(20) NOT NULL,
	LName VARCHAR(20) NOT NULL,
	Class VARCHAR(20) NOT NULL,
	Division VARCHAR(20) NOT NULL,
	city VARCHAR(20) NOT NULL,
	
	maths INT NOT NULL,
	chem INT NOT NULL,
	phy INT NOT NULL,
	comScience INT NOT NULL,
	eng INT NOT NULL,
	
	state VARCHAR(20)NOT NULL DEFAULT 'Maharashtra'
	
);

DROP TABLE student_details;

SELECT * FROM student_details;

INSERT INTO student_details
VALUES(123,1,'Arti','Kedar',12,'A','Pune',-90,80,70,60,80,DEFAULT);
INSERT INTO student_details
VALUES(234,2,'Komal','Mishrikotkar',11,'A','Amravati',30,60,50,90,59,DEFAULT);
INSERT INTO student_details
VALUES(334,3,'Shubhangi','Madne',11,'A','Akola',50,70,88,99,86,'Punjab');
INSERT INTO student_details
VALUES(236,4,'Seema','Mane',12,'A','Nagpur',40,45,77,45,56,'Gujarat');
INSERT INTO student_details
VALUES(566,5,'Pranjali','Dhore',10,'A','Nagpur',34,66,54,56,45,'Andhra Pradesh');
INSERT INTO student_details
VALUES(788,6,'Piyush','Jain',10,'A','Satara',76,72,23,23,57,'Jammu Kashmir');
INSERT INTO student_details
VALUES(456,7,'Harshal','Soalo',8,'A','Sangli',56,87,56,64,45,'Rajasthan');
INSERT INTO student_details
VALUES(567,8,'Nikunj','Agarwal',8,'A','Nasik',38,69,34,34,78,'Himachal Pradesh');
INSERT INTO student_details
VALUES(423,9,'Mayur','Gavali',8,'A','Mumbai',23,79,85,57,45,'Uttar Pradesh');
INSERT INTO student_details
VALUES(677,10,'Vikram','Thakre',12,'A','Pune',96,74,88,67,78,DEFAULT);

-- Check Constraint
DELIMITER //
CREATE TRIGGER check_constraint BEFORE INSERT ON student_details
	FOR EACH ROW 
	BEGIN 
	IF NEW.maths <0 THEN
	SET NEW.maths=0;
	END IF;
END; //
DELIMITER ;




-- 1.Name of the students who have obtained highest marks in Individual subject in a class
SELECT FName,LName,Class,maths FROM student_details WHERE maths IN(SELECT MAX(maths) FROM student_details GROUP BY class); 
SELECT FName,LName,Class,phy FROM student_details WHERE phy IN(SELECT MAX(phy) FROM student_details GROUP BY class);
SELECT FName,LName,Class,chem FROM student_details WHERE chem IN(SELECT MAX(chem) FROM student_details GROUP BY class);
SELECT FName,LName,Class,comScience FROM student_details WHERE comScience IN(SELECT MAX(comScience) FROM student_details GROUP BY class);
SELECT FName,LName,Class,eng FROM student_details WHERE eng IN(SELECT MAX(eng) FROM student_details GROUP BY class);

-- 2.Names of the students who have obtained highest marks in Individual subject in entire college
SELECT FName,LName,Class,maths FROM student_details WHERE maths IN(SELECT MAX(maths) FROM student_details); 
SELECT FName,LName,Class,phy FROM student_details WHERE phy IN(SELECT MAX(phy) FROM student_details);
SELECT FName,LName,Class,chem FROM student_details WHERE chem IN(SELECT MAX(chem) FROM student_details);
SELECT FName,LName,Class,comScience FROM student_details WHERE comScience IN(SELECT MAX(comScience) FROM student_details);
SELECT FName,LName,Class,eng FROM student_details WHERE eng IN(SELECT MAX(eng) FROM student_details);

-- 3.Name of the student who ranked top position in the class by marks
SELECT FName,LName,Class, maths+chem+phy+comScience+eng AS Total FROM student_details  WHERE Class='12' ORDER BY total DESC LIMIT 0,1;
SELECT FName,LName,Class, maths+chem+phy+comScience+eng AS Total FROM student_details  WHERE Class='11' ORDER BY total DESC LIMIT 0,1;
SELECT FName,LName,Class, maths+chem+phy+comScience+eng AS Total FROM student_details  WHERE Class='10' ORDER BY total DESC LIMIT 0,1;
SELECT FName,LName,Class, maths+chem+phy+comScience+eng AS Total FROM student_details  WHERE Class='8' ORDER BY total DESC LIMIT 0,1;

-- 4.Name of the student who is topper in entire college 
SELECT FName,LName,Class, maths+chem+phy+comScience+eng AS Total FROM student_details ORDER BY total DESC LIMIT 0,1; 

-- 5.Name of the student who are top three positions in the class
SELECT FName,LName,Class, maths+chem+phy+comScience+eng AS Total FROM student_details  WHERE Class='12' ORDER BY total DESC LIMIT 0,3;
SELECT FName,LName,Class, maths+chem+phy+comScience+eng AS Total FROM student_details  WHERE Class='11' ORDER BY total DESC LIMIT 0,3;
SELECT FName,LName,Class, maths+chem+phy+comScience+eng AS Total FROM student_details  WHERE Class='10' ORDER BY total DESC LIMIT 0,3;
SELECT FName,LName,Class, maths+chem+phy+comScience+eng AS Total FROM student_details  WHERE Class='8' ORDER BY total DESC LIMIT 0,3;

-- 6.Name of the student who are BOTTOM three positions in the class
SELECT FName,LName,Class, maths+chem+phy+comScience+eng AS Total FROM student_details  WHERE Class='12' ORDER BY total LIMIT 0,3;
SELECT FName,LName,Class, maths+chem+phy+comScience+eng AS Total FROM student_details  WHERE Class='11' ORDER BY total LIMIT 0,3;
SELECT FName,LName,Class, maths+chem+phy+comScience+eng AS Total FROM student_details  WHERE Class='10' ORDER BY total LIMIT 0,3;
SELECT FName,LName,Class, maths+chem+phy+comScience+eng AS Total FROM student_details  WHERE Class='8' ORDER BY total LIMIT 0,3;

-- 7.Name of the student who are BOTTOM three positions in entire college
SELECT FName,LName,Class, maths+chem+phy+comScience+eng AS Total FROM student_details ORDER BY total LIMIT 0,3;

-- 8.Name of the students which belong to a given city
SELECT FName,LName,Class,city FROM student_details WHERE city='Pune';
SELECT FName,LName,Class,city FROM student_details WHERE city='Nagpur';

-- 9.All students grouped by their respective cities
SELECT FName,LName,Class,city FROM student_details WHERE city IN(SELECT city FROM student_details GROUP BY city) ORDER BY city;

-- 10.Display all the students of a given class by alphabetical order by name or surname
SELECT FName,LName,Class FROM student_details WHERE Class='12' GROUP BY FName;
SELECT FName,LName,Class FROM student_details WHERE Class='12' GROUP BY LName;
SELECT FName,LName,Class FROM student_details WHERE Class='11' GROUP BY FName;
SELECT FName,LName,Class FROM student_details WHERE Class='11' GROUP BY LName;
SELECT FName,LName,Class FROM student_details WHERE Class='10' GROUP BY FName;
SELECT FName,LName,Class FROM student_details WHERE Class='10' GROUP BY LName;
SELECT FName,LName,Class FROM student_details WHERE Class='8' GROUP BY FName;
SELECT FName,LName,Class FROM student_details WHERE Class='8' GROUP BY LName;

--  11.Display all the students of the entire college by alphabetical order by name or surname
SELECT FName,LName,Class FROM student_details GROUP BY FName;
SELECT FName,LName,Class FROM student_details GROUP BY LName;

-- Procedures Introduction
DELIMITER $$
CREATE PROCEDURE getStudentDetails(IN Roll_No INT, OUT details VARCHAR(20))
BEGIN 
SELECT CONCAT(FName,LName) FROM student_details WHERE RollNo=Roll_No;
END $$
DELIMITER ;
CALL getStudentDetails(1, @OUT);
SELECT @OUT;

DROP PROCEDURE getStudentDetails;
