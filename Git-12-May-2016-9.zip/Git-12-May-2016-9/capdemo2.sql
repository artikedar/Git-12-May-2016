INSERT INTO brand VALUES(1,'Samsung',2);
INSERT INTO brand VALUES(2,'JBL',2);
INSERT INTO brand VALUES(3,'Apple',2);
INSERT INTO brand VALUES(4,'Green-Lam',1);
INSERT INTO brand VALUES(5,'Pepperfry',1);
INSERT INTO brand VALUES(6,'Urban-Ladder',1);
INSERT INTO brand VALUES(7,'La-Opala',3);
INSERT INTO brand VALUES(8,'Hawkins',3);
INSERT INTO brand VALUES(9,'TupperWare',3);
INSERT INTO brand VALUES(10,'Cello',3);
INSERT INTO brand VALUES(11,'Crompton',2);
INSERT INTO brand VALUES(12,'Syska',2);
SELECT * FROM brand;


INSERT INTO category VALUES(1,'Wooden Furniture');
INSERT INTO category VALUES(2,'Electronics');
INSERT INTO category VALUES(3,'KitchenWare');
SELECT * FROM category;

INSERT INTO merchant VALUES(1,'Green-Lam');
INSERT INTO merchant VALUES(2,'CityMobiles');
INSERT INTO merchant VALUES(3,'VijaySales');
INSERT INTO merchant VALUES(4,'TupperWare');
INSERT INTO merchant VALUES(5,'BigBazar');
INSERT INTO merchant VALUES(6,'D-Mart');
INSERT INTO merchant VALUES(7,'Reliance');
INSERT INTO merchant VALUES(8,'RelianceDigital');
SELECT * FROM merchant;


INSERT INTO product VALUES(1,'10fts',STR_TO_DATE('1-01-2012', '%d-%m-%Y'),10,40000,'couch',1,3,1,6,1,6);
INSERT INTO product VALUES(3,'Core i3, Intel HD graphics,8GB max',STR_TO_DATE('1-01-2012', '%d-%m-%Y'),10,60000,'laptop',2,8,6,3,2,3); 
INSERT INTO product VALUES(4,'Home/office background noise: 40-60 dB, ',STR_TO_DATE('1-01-2012', '%d-%m-%Y'),10,4000,'speakers',2,3,8,2,2,2); 
INSERT INTO product VALUES(5,'160 to 265 V, 48 to 52Hz',STR_TO_DATE('1-01-2012', '%d-%m-%Y'),10,2000,'fan',2,8,16,11,2,11); 
INSERT INTO product VALUES(6,'CCT Range: 6500 K (EC), Current (mA):120, Volts (V): 3.25',STR_TO_DATE('1-01-2012', '%d-%m-%Y'),10,100,'led',2,8,17,12,2,12); 
INSERT INTO product VALUES(7,'Set of 6 classy mocktail glasses ',STR_TO_DATE('1-01-2012', '%d-%m-%Y'),10,1000,'glass',3,6,1,7,3,7); 
INSERT INTO product VALUES(8,'Multiutility multichopper',STR_TO_DATE('1-01-2012', '%d-%m-%Y'),10,200,'cutter',3,7,3,6,3,6); 
 
SELECT * FROM product;



INSERT INTO stock VALUES(1,10,1);
INSERT INTO stock VALUES(2,10,3);
INSERT INTO stock VALUES(3,10,2);
INSERT INTO stock VALUES(4,10,4);
INSERT INTO stock VALUES(5,10,5);
INSERT INTO stock VALUES(6,10,6);
INSERT INTO stock VALUES(7,10,7);
INSERT INTO stock VALUES(8,10,8);
INSERT INTO stock VALUES(9,10,9);
INSERT INTO stock VALUES(10,10,10);
SELECT * FROM stock;

INSERT INTO sub_category VALUES(1,'Sofa',1);
INSERT INTO sub_category VALUES(2,'Table',1);
INSERT INTO sub_category VALUES(3,'Chair',1);
INSERT INTO sub_category VALUES(4,'Rack',1);
INSERT INTO sub_category VALUES(5,'Mobile',2);
INSERT INTO sub_category VALUES(6,'Laptop',2);
INSERT INTO sub_category VALUES(7,'Headphones',2);
INSERT INTO sub_category VALUES(8,'Speakers',2);
INSERT INTO sub_category VALUES(9,'Hard-Disk',2);
INSERT INTO sub_category VALUES(10,'Gas',3);
INSERT INTO sub_category VALUES(11,'Dinner-Set',3);
INSERT INTO sub_category VALUES(12,'Bowl-Set',3);
INSERT INTO sub_category VALUES(13,'Glass-Set',3);
INSERT INTO sub_category VALUES(14,'Spoon',3);
INSERT INTO sub_category VALUES(15,'Cutter',3);
INSERT INTO sub_category VALUES(16,'Fan',2);
INSERT INTO sub_category VALUES(17,'Led Lights',2);


SELECT * FROM sub_category;  
