package org.capgemini.demo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CharWriteDemo {

	public static void main(String[] args) {
		
		
		
		File file=new File("D:\\vidavid\\Training\\2016\\FLP_PUNE_8_FEB\\fileDemo\\myInfo.txt");
		FileWriter fileWriter=null;
		
		try{
			//Open will file in append mode
			fileWriter=new FileWriter(file,true);
			
			String str="Hello! Good Morning! Have a Good Day!";
			
			/*for(int i=0;i<str.length();i++)
			{
				int ch=str.charAt(i);
				fileWriter.write(ch);
			}
			*/
			
			//fileWriter.write(str);
			
			fileWriter.write(str,0,10);
			
		}catch(FileNotFoundException ex){
			ex.printStackTrace();
		}catch (IOException e) {
			e.printStackTrace();
		}finally{
			try {
				fileWriter.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	

	}

}
