package org.capgemini.demo;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FormatOutputDemo {

	public static void main(String[] args) {
		
		int empId=1001;
		String empName="Kamal";
		double salary=12000;
		boolean isPermanent=true;
		char gender='m';
		
		
		File file=new File("D:\\vidavid\\Training\\2016\\FLP_PUNE_8_FEB\\fileDemo\\emp.txt");
		FileOutputStream fout=null;
		DataOutputStream dout=null;
		try{
			fout=new FileOutputStream(file);
			dout=new DataOutputStream(fout);
			
			
			dout.writeInt(empId);
			dout.writeChar(gender);
			dout.writeDouble(salary);
			dout.writeBoolean(isPermanent);
			dout.writeChars(empName);
			
			
			
		}catch(FileNotFoundException ex){
			ex.printStackTrace();
		}catch (IOException e) {
			e.printStackTrace();
		}finally{
			try{
			dout.close();
			fout.close();
			}catch(IOException ex){
				ex.printStackTrace();
			}
			
		}
		
		

	}

}













