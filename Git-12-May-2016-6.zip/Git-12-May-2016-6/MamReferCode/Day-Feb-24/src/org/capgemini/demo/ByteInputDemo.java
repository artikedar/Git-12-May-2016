package org.capgemini.demo;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class ByteInputDemo {

	public static void main(String[] args) {
File file=new File("D:\\vidavid\\Training\\2016\\FLP_PUNE_8_FEB\\fileDemo\\byteiodemo.txt");
		
	
		BufferedInputStream bin=null;
		FileInputStream fin=null;
		
		try{
			fin=new FileInputStream(file);
			bin=new BufferedInputStream(fin);
			
			byte[] mybytes=new byte[100];
			
			bin.read(mybytes,0,10);
			
			for(int i=0;i<mybytes.length;i++){
				int myByte=bin.read();
				System.out.print((char)mybytes[i]);
			}
			
			
			/*int len=(int)file.length();
			
			for(int i=0;i<len;i++){
				int myByte=bin.read();
				System.out.print((char)myByte);
			}
			*/
			
		}catch(FileNotFoundException ex){
			ex.printStackTrace();
		}catch (IOException e) {
			e.printStackTrace();
		}finally {
			try{
			fin.close();
			bin.close();
			}catch(IOException e){
				e.printStackTrace();
			}
		}
	}

}
