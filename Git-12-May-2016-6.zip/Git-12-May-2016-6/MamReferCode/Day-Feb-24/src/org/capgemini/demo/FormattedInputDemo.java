package org.capgemini.demo;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FormattedInputDemo {

	public static void main(String[] args) {
		
		File file=new File("D:\\vidavid\\Training\\2016\\FLP_PUNE_8_FEB\\fileDemo\\emp.txt");
		
		
		FileInputStream fin=null;
		DataInputStream din=null;
		
		try{
			fin=new FileInputStream(file);
			din=new DataInputStream(fin);
			
			
			
			
			int eid=din.readInt();
			char gender=din.readChar();
			double sal=din.readDouble();
			boolean status=din.readBoolean();
			String ename=din.readLine();
			

			System.out.println("Employee Id:" +eid + "\nEmployee Name :" + ename +
					"\nSalary :" + sal +
					"\nIs Permenant: " + status +
					"\nGender :" + gender);
			
			
		}catch(FileNotFoundException ex){
			ex.printStackTrace();
		}catch (IOException e) {
			e.printStackTrace();
		}finally{
			try{
			din.close();
			fin.close();
			}catch(IOException ex){
				ex.printStackTrace();
			}
			
		}
		
	}

}
  