package org.capgemini.demo;

import java.util.Comparator;

public class SortByRegFees  implements Comparator<Customer>{

	@Override
	public int compare(Customer cust1, Customer cust2) {
		
		if(cust1.getRegFees()>cust2.getRegFees())
			return 1;
		else if(cust1.getRegFees()<cust2.getRegFees())
			return -1;
		else
			return 0;
	}

}
