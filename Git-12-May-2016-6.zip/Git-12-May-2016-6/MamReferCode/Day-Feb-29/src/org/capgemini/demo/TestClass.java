package org.capgemini.demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

public class TestClass {

	public static void main(String[] args) {
		
		//HashSet<Customer> set=new HashSet<>();
		
	//	TreeSet<Customer> set=new TreeSet<>();
		ArrayList<Customer> set=new ArrayList<>();
		set.add(new Customer(101, "Tom", 2000));
		set.add(new Customer(102, "Jerry", 1200));
		set.add(new Customer(101, "Tom", 2780));
		
		Customer customer=new Customer(1, "Jack", 1200);
		set.add(customer);
		set.add(customer);
		
		//Collections.sort(set);
		Collections.sort(set,new SortByRegFees());
		
		//System.out.println(set);
		Iterator<Customer> itr=set.iterator();
		while(itr.hasNext())
			System.out.println(itr.next());
		
		
	}

}
