package org.capgemini.demomap;

import java.util.Map;
import java.util.TreeMap;

public class TestMap {

	public static void main(String[] args) {
		Employee e1=new Employee(1, "Tom", "Jerry", 12000);
		Employee e2=new Employee(2, "sam", "thomson", 3400);
		Employee e3=new Employee(13, "ram", "singh", 7800);
		Employee e4=new Employee(4, "Tom", "Jerry", 90000);
		Employee e5=new Employee(5, "Tom", "Jerry", 10000);
		Employee e6=new Employee(500, "Emi", "Karan", 11110);
		Employee e7=new Employee(88, "Tom", "Jerry", 15600);
		
		
		Map<Employee,Integer> maps=new TreeMap<Employee,Integer>();
		maps.put( e1,1);
		maps.put( e2,123);
		maps.put( e3,0);
		maps.put( e4,-90);
		maps.put( e5,222);
		maps.put( e6,342);
		maps.put( e7,122);
		
		System.out.println(maps);
		

	}

}
