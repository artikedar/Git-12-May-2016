package org.cap.student;

public class MainClass {
	public static void main(String[] args){
		StudentService service=new StudentService();
		service.getStudents();
		service.printStudents();
	}
}
