package org.cap.demo;

import org.capgemini.demo.Employee;

public class Demo {

	public static void main(String[] args) {
		Employee employee=new Employee();
		System.out.println(employee.firstName);
		//System.out.println(employee.lastName);
		//System.out.println(employee.salary);
	}

}
