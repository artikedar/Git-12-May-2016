package flp.cap.nestedclass;

public class MainMethod {

	public static void main(String[] args) {
		
		
		NonStaticClass nonStaticClass=new NonStaticClass();
		NonStaticClass.MyStaticClass staticClass=new NonStaticClass.MyStaticClass();
		
		staticClass.non_Static_Method();
		
		//staticClass.static_Method();
		
		NonStaticClass.MyStaticClass.static_Method();
	}

}
