package flp.cap.nestedclass;

public class MyClass1 implements Graphics,Graphics.Color{

	@Override
	public void move() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void myColor() {
		// TODO Auto-generated method stub
		
	}

}
