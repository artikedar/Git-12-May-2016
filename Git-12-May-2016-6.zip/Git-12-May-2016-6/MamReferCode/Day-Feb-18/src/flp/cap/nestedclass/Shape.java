package flp.cap.nestedclass;

public abstract class Shape {
	
	abstract public void draw();

}
