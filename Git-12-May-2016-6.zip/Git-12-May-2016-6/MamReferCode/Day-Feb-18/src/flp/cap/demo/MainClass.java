package flp.cap.demo;

import flp.cap.demo.Student.Gendar;

public class MainClass {

	public static void main(String[] args) {
		
		Weekdays[] weekdays= Weekdays.values();
		
		for(Weekdays day : weekdays){
			System.out.println(day +"- " + day.getValue());
		}
		
		MyColor color=MyColor.BLUE;
		System.out.println(color +", " + color.getMinValue() + " -" + color.getMaxValue());
		
		
		Gendar gendar=Gendar.MALE;
		
	}

}
