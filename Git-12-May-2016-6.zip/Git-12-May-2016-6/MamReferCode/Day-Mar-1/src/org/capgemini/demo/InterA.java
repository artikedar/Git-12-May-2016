package org.capgemini.demo;

public interface InterA {
	public void show();
}
