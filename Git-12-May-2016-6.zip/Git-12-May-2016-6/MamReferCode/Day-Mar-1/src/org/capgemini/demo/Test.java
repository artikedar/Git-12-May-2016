package org.capgemini.demo;

public class Test {

	public static void main(String[] args) {
		MClass<InterA> objA=new MClass<InterA>(new X());
		MClass<InterA> objB=new MClass<InterA>(new Y());
		
		objA.printClass();
		objB.printClass();

	}

}
