package org.capgemini.demo;

public class TestClass {

	public static void main(String[] args) {
	
		MyClass<A> objA=new MyClass<A>(new A());
		MyClass<B> objB=new MyClass<B>(new B());
		MyClass<C> objC=new MyClass<C>(new C());
		
		MyClass<A> objAA=new MyClass<A>(new B());
		
		objA.printClass();
		objB.printClass();
		objC.printClass();
		objAA.printClass();
		
		//MyClass<Integer> objAAS=new MyClass<Integer>(new B());
		
	}

}




