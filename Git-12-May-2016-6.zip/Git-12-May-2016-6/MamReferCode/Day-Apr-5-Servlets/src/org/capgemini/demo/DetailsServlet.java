package org.capgemini.demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class DetailsServlet
 */
public class DetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String uemail=request.getParameter("uemail");
		
		PrintWriter out=response.getWriter();
		out.println("<br><br>User Email:" + uemail);
		
		
		//Retrieve the Cookie
		
		Cookie[] cookies=request.getCookies();
		for(Cookie ck:cookies)
			out.println("<br><br>"+ck.getName() + "-"+ ck.getValue());
		
	
		out.println("<br><br><b>Session Object</b>");
		
		
		HttpSession session=request.getSession();
		
		String user=(String)session.getAttribute("userName");
		String eEmail=(String)session.getAttribute("userEmail");
		
		
		out.println("User:" + user);
		out.println("Email:" + eEmail);
	}

}
