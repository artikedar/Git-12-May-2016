package flp.cap.demo;

import java.util.Scanner;

public abstract class Employee {
	
	private int kinId;
	private String firstName;
	private String lastName;
	
	public void getEmployee(){
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter KinId:");
		kinId=scanner.nextInt();
		
		System.out.println("Enter Firstname:");
		firstName=scanner.next();
		
		System.out.println("Enter Lastname:");
		lastName=scanner.next();
		
	}
	
	public void printEmployee(){
		System.out.println("Kind Id:" + kinId + "\nFirstname:" + firstName +"\nLAstName:" + lastName);
	}
	
	
	  abstract double calculateSalary();

}
