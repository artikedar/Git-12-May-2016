package org.capgemini.demo;

public class Demo {

	public static void main(String[] args) {
		
		Demo demo=new Demo();
		System.out.println(demo.calculate());
	}
	
	
	public int calculate(){
		int num1=4,num2=0;
		
		int ans=0;
		if(num2>=0){
			try{
			ans=num1/num2;
			}catch(ArithmeticException ex){
				return 4;
				
			}finally{
				return 10;
			}
			
		}else
			return ans;
		
	}

}
