package org.capgemini.demo;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

public class LinkEdListDemo {

	public static void main(String[] args) {
		
		LinkedList<Integer> lst=new LinkedList<>();
		//List<Integer> lst=new LinkedList<>();
		//Collection<Integer> lst=new LinkedList<>();
		
		
		lst.add(34);
		lst.add(56);
		lst.add(new Integer(-10));
		lst.add(34);
		lst.add(null);
		lst.add(1999);lst.add(34);
		lst.add(null);
		
		
		System.out.println(lst);

		System.out.println(lst.remove(new Integer(34)));
		System.out.println(lst);
		
	
		
	}

}
