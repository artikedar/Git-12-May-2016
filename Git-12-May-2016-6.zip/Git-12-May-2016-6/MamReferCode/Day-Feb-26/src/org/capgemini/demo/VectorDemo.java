package org.capgemini.demo;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;

public class VectorDemo {

	public static void main(String[] args) {
		
		Vector<String> vector=new Vector<>();
		
		vector.add("Tom");
		vector.add("ram");	vector.add("ram");	vector.add("ram");
		vector.add("ram");	vector.add("ram");	vector.add("ram");
		vector.add("ram");	vector.add("ram");	vector.add("ram");
		vector.add("sam");	vector.add("sam");	vector.add("sam");	vector.add("sam");
		vector.add(null);
		vector.add("singh");vector.add("Tom");vector.add("Tom");
		vector.add("jack");vector.add("Tom");
		vector.add("jack");
		vector.add(null);
		
		System.out.println(vector);
		System.out.println("Size:" + vector.size());
		System.out.println("Capacity:" + vector.capacity());
		
		/*Iterator<String> iterator=vector.iterator();
		
		while(iterator.hasNext())
			System.out.println(iterator.next());
		
		
		
		
		Enumeration<String> enums=vector.elements();
		while(enums.hasMoreElements()){
			System.out.print(enums.nextElement()+"-->");
		}
		*/
		
		
		
		
		
	}

}
