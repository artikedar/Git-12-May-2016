package org.capgemini.demo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class TestLst {

	public static void main(String[] args) {
		List<String> mylst=new ArrayList<>();
		
		mylst.add("Tom");
		mylst.add("Jeryy");
		mylst.add("Tom");
		//mylst.add(null);
		mylst.add("ram");
		mylst.add("jack");
		mylst.add("jack");
		mylst.add("Emi");
		mylst.add("Tom");
		//mylst.add(null);
		mylst.add("null");
		
		
		/*for(String str:mylst){
			System.out.println(str);
		}
		*/
		
		
		/*Iterator<String> itr=mylst.iterator();
		while(itr.hasNext()){
			String str=itr.next();
				if(str.equals("jack"))
					itr.remove();
			System.out.println(str);
		}
		
		System.out.println(mylst);*/
		
		ListIterator<String> litr= mylst.listIterator();
		
		
		
		while(litr.hasNext()){
			String str=litr.next();
			if(str.equals("jack"))
				litr.remove();
			System.out.print(str+ "--->");
		}
		

		System.out.println();
		
		System.out.println(mylst);
		
		
		while(litr.hasPrevious()){
			System.out.print(litr.previous() + "--->");
		}
		
		System.out.println();
		mylst.add("Ramsingh");
	
		
		System.out.println(mylst);
		
		
	}

}
