package org.cap.expDemo;

public class MainClass {

	public static void main(String[] args) {
		
		int age=12;
		
		try{
		if(age<18)
			throw new InvalidAgeException("Invalid Age Exception!");
		
		}catch(InvalidAgeException ex){
			System.out.println(ex.getMessage());
		}
	}

}
