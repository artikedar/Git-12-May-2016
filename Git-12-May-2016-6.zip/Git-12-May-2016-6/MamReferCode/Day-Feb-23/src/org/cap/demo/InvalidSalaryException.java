package org.cap.demo;

public class InvalidSalaryException  extends Exception{
	
	public InvalidSalaryException(String msg){
		super(msg);
	}

}
