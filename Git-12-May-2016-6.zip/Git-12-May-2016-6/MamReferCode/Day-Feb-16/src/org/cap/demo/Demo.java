package org.cap.demo;
import static org.capgemini.Employee.*;

import org.capgemini.Employee;

public class Demo {
	
	public void myMethod(){
		System.out.println("My Method - Demo Class");
	}

	public static void main(String[] args) {
		Demo demo=new Demo();
		demo.myMethod();
		
		Employee.myMethod();
		
		
	}

}
