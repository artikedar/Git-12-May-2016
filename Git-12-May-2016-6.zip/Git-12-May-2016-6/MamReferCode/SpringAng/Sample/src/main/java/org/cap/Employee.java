package org.cap;

public class Employee {
	
	int id;
	String name;
	
	public void show(){
		System.out.println("Hai");
	}

	
	public void checkupdate(){
		System.out.println("Check");
	}
	
	
	public void display()
	{
	System.out.println("dis");
	}
}
