package org.cap;

public class Address {

}
