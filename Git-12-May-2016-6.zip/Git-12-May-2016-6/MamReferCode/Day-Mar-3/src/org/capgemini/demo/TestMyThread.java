package org.capgemini.demo;

public class TestMyThread {
	
	public static void main(String[] args){
		MultiplicationTable table=new MultiplicationTable();
		
		
		Thread t1=new Thread(){
			public void run(){
				table.printTable(12);
			}
		};
		
		Thread t2=new Thread(){
			public void run(){
				table.printTable(13);
			}
		};
		
		Thread t3=new Thread(){
			public void run(){
				table.printTable(19);
			}
		};
		
		
		t1.start();
		t2.start();
		t3.start();
		
	}

}
