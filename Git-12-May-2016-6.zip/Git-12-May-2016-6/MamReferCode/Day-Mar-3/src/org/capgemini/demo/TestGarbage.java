package org.capgemini.demo;

public class TestGarbage {

	
	//Cleanup task
	@Override
	public void finalize(){
		System.out.println("Object Collected!");
	}
	
	public static void main(String[] args) {
		
		TestGarbage t1=new TestGarbage();
		TestGarbage t2=new TestGarbage();
		
		t1=null;
		t2=null;
		
		//Request to JVM to call Garbage Collector
		System.gc();
		

	}

}
