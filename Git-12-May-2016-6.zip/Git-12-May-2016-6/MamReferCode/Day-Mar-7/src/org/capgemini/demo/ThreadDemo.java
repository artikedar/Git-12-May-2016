package org.capgemini.demo;

public class ThreadDemo {

	public static void main(String[] args) {
		Table table=new Table();
		
		Thread t1=new Thread(){
			@Override
			public void run(){
				Table.printTable(13);
			}
		};

		
		Thread t2=new Thread(){
			@Override
			public void run(){
				Table.printTable(19);
			}
		};
		
		
		
		Thread t3=new Thread(){
			@Override
			public void run(){
				table.printString("Capgemini");
			}
		};
		
		
		Thread t4=new Thread(){
			@Override
			public void run(){
				table.printString("Welcome");
			}
		};
		
		
		
		t1.start();
		t2.start();
		t3.start();
		t4.start();
	}

}
