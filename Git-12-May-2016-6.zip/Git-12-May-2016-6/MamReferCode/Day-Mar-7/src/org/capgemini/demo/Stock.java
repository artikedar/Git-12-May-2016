package org.capgemini.demo;

public class Stock {
	
	int qty=100;
	
	
	public synchronized void consume(int quantity){
		System.out.println("Consumer Started..!");
		if(this.qty<quantity)
		{
			System.out.println("Waiting for Producer....");
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
			
			this.qty-=quantity;
		
		System.out.println("Stock Consumed! Available Qty :" + this.qty);	
			
	}
	
	
	
	public synchronized void producer(int quantity){
		System.out.println("Producer Started..!");
		
		this.qty+=quantity;
		System.out.println("Stock Produced! Available Qty :" + this.qty);	
		
		notify();
		
		
	}

}
