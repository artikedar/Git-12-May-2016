package org.capgemini.demo;

public class Table {
	
	static int num=10;
	
	String myName="Capgemini";
	
	public  static void printTable(int num){
		System.out.println("Started -->" + Thread.currentThread().getName());
		System.out.println(num++);
		//System.out.println("Name:" + myName);
		synchronized(Table.class){
			for(int i=1;i<=25;i++)
				System.out.println(i+"*"+num+"="+(i*num));
		}
		
		System.out.println("Stopped---> "+ Thread.currentThread().getName());
	}
	
	
	public synchronized void printString(String str){
		System.out.println(num++);
		System.out.println("Name:" + myName);
		for(int i=0;i<=str.length();i++)
			System.out.println(str.substring(0,i));
	}

}
