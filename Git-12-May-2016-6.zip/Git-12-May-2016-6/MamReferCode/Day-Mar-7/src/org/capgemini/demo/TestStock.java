package org.capgemini.demo;

public class TestStock {

	public static void main(String[] args) {
		
		final Stock stock=new Stock();
		
		Thread t1=new Thread(){
			@Override
			public void run(){
				stock.consume(50);
			}
		};
		

		Thread t2=new Thread(){
			@Override
			public void run(){
				stock.consume(80);
			}
		};
		
		Thread t4=new Thread(){
			@Override
			public void run(){
				stock.consume(60);
			}
		};
		
		

		Thread t3=new Thread(){
			@Override
			public void run(){
				stock.producer(100);
			}
		};
		
		t2.setPriority(10);
		
		t1.start();
		t2.start();
		t3.start();
		t4.start();
		
	}

}
