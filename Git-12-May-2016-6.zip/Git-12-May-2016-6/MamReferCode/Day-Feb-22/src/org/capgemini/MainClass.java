package org.capgemini;

public class MainClass {

	public static void main(String[] args) {
		@Publisher(publisherName="ABC Publishers",publishDate="12/12/2000")
		Book book=new Book(1001, "Java Complete Ref");

	}

}
