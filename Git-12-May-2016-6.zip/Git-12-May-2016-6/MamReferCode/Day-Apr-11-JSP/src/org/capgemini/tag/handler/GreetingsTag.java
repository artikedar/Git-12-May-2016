package org.capgemini.tag.handler;

import java.io.IOException;
import java.io.StringWriter;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class GreetingsTag extends SimpleTagSupport{
	
	private String myname;
	
	public String getMyname() {
		return myname;
	}

	public void setMyname(String myname) {
		this.myname = myname;
	}




	@Override
	public void doTag() throws JspException, IOException {
		
		JspWriter out=getJspContext().getOut();
		
		StringWriter str=new StringWriter();
		getJspBody().invoke(str);
		if(myname==null)
			myname="";
		out.println("<h1>Hello! "+ myname+" Welcome To JSP</h1>" + str);
		
	}
	
	

}
