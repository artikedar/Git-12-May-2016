package org.capgemini.onetoone;

import org.capgemini.demo.Book;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class TestClass {

	public static void main(String[] args) {

		AnnotationConfiguration config=new AnnotationConfiguration();
		config.addAnnotatedClass(Student.class);
		config.addAnnotatedClass(Address.class);
		config.configure();
		
		new SchemaExport(config).create(true, true);
		
		
		
		SessionFactory sessionFactory= config.buildSessionFactory();
		
		
		Session  session= sessionFactory.openSession();
		
		session.beginTransaction();
		
		Address address=new Address(1001, "23/5", "North Avvenue", "Pune", "Maharastra");
		
		Address address1=new Address(1002, "23/5", "South Avvenue", "Hyderabad", "AP");
		
		
		Student student=new Student(1, "Tom", "Jerry", address);
		Student student1=new Student(11, "Helen", "Rock", address1);
		
		session.save(student);
		session.save(student1);
		session.save(address);
		session.save(address1);
		session.getTransaction().commit();
		session.close();
		
		
	}

}
