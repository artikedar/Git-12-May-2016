package org.cap;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class CalendarDemo {

	public static void main(String[] args) {
		
		Calendar calendar=new GregorianCalendar();
		
		//GregorianCalendar calendar2=new GregorianCalendar();
		
		System.out.println(calendar);
		
		//Calendar calendar=new GregorianCalendar();
		
		System.out.println(calendar.get(Calendar.DATE));
		System.out.println(calendar.get(Calendar.YEAR));
		System.out.println(calendar.get(Calendar.MONTH));
		System.out.println(calendar.get(Calendar.DAY_OF_MONTH));
		System.out.println(calendar.get(Calendar.DAY_OF_WEEK));
		
		
		
		
	}

}
