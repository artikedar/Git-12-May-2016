package org.capgemini.demo;

public class TestClass {

	public static void main(String[] args) {
		Child child=new Child("Tom");

	}

}
