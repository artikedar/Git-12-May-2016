package org.capgemini.demo;

public class PrintString implements Runnable{

	private String myStr;
	
	public PrintString(String myStr){
		this.myStr=myStr;
	}
	
	@Override
	public void run(){
		
		for(int i=0;i<myStr.length();i++){
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(Thread.currentThread().getName()+"-->"+ myStr.substring(0, i));
		}
	}
}
