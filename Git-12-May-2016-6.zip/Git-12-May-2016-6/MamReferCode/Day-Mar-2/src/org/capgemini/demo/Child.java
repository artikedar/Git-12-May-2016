package org.capgemini.demo;

public class Child extends Parent{

	public Child(String personName) {
		super(personName);
		
	}
	
	

}
