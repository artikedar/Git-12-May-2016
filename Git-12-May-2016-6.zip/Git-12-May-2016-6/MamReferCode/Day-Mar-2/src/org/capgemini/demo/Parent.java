package org.capgemini.demo;

public class Parent {
	
	String personName;
	
	public Parent(String personName){
		System.out.println("Parent Constructor");
		this.personName=personName;
	}

}
