package org.capgemini.demo;

public class MyThread implements Runnable{
	private int num;
	
	public MyThread(int num){
		this.num=num;
	}
	
	
	
	
	public void printTable(){
		
		for(int i=1;i<=20;i++)
			System.out.println( Thread.currentThread().getName() +"-->"+ i+"*"+num+"="+(i*num));
	}




	@Override
	public void run() {
		printTable();
		
	}

}
