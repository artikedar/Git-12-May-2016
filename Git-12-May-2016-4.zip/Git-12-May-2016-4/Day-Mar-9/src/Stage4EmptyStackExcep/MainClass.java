package Stage4EmptyStackExcep;

public class MainClass {

	public static void main(String[] args) {
		WareHouse wareHouse=new WareHouse();
		Producer producer=new Producer(wareHouse);
		Consumer consumer=new Consumer(wareHouse);
		
		Thread t1=new Thread(producer);
		Thread t2=new Thread(consumer);
		Thread t3=new Thread(consumer);
		Thread t4=new Thread(consumer);
		Thread t5=new Thread(consumer);
		
		t1.start();
		t2.start();
		t3.start();
		t4.start();
		t5.start();
		
		

	}

}
