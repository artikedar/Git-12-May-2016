package Stage5RemovedEmptyStackExcep;

public class MainClass {

	public static void main(String[] args) {
		WareHouse wareHouse=new WareHouse();
		Producer producer=new Producer(wareHouse);
		Consumer consumer=new Consumer(wareHouse);
		
		Thread t1=new Thread(producer);
		//Thread t6=new Thread(producer);
		//Thread t7=new Thread(producer);
		//Thread t8=new Thread(producer);
		Thread t2=new Thread(consumer);
		Thread t3=new Thread(consumer);
		Thread t4=new Thread(consumer);
		Thread t5=new Thread(consumer);
		
		t1.start();
		t2.start();
		try {
			t2.join();
		} catch (InterruptedException e) {
		
			e.printStackTrace();
		}
		t3.start();
		try {
			t3.join();
		} catch (InterruptedException e) {
		
			e.printStackTrace();
		}
		t4.start();
		try {
			t4.join();
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		t5.start();
		try {
			t5.join();
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		
		

	}

}
