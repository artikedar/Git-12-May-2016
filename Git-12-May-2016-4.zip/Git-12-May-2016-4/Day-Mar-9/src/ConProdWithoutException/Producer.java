package ConProdWithoutException;

import java.util.Random;

public class Producer implements Runnable{

	WareHouse wh;
	
	public Producer(WareHouse wh) {
		this.wh=wh;
	}
	@Override
	public void run() {
		System.out.println("Stack is filling");
		while(true){
			int x=new Random().nextInt(500);
			
			System.out.println(x);
			wh.add(x);
			
		}
	
		
	}
}

