package ConProdWithoutException;

import java.util.Stack;

public class WareHouse {
	private Stack<Integer> stack=new Stack<Integer>();
	
	public synchronized void add(int x){
		if(stack.size()==10){
			try {
				wait();
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		}
		stack.push(x);
	}
	
	public synchronized int remove(){
		if(stack.isEmpty()){
			try {
				wait();
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		}
		
		
		
		int num=stack.pop();
		System.out.println(num);
		return stack.pop();
	}

}
