package Stage3;


import java.util.Random;

public class Producer implements Runnable{

	WareHouse wh;
	
	public Producer(WareHouse wh) {
		this.wh=wh;
	}
	@Override
	public void run() {
		
		while(true){
			System.out.println("Stack is filling");
			int x=new Random().nextInt(500);
			
			System.out.println("push-"+x);
			wh.add(x);
			
		}
	
		
	}
}
