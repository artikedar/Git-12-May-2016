package Stage3;

public class MainClass {

	public static void main(String[] args) {
		WareHouse wareHouse=new WareHouse();
		Producer producer=new Producer(wareHouse);
		Consumer consumer=new Consumer(wareHouse);
		
		Thread t1=new Thread(producer);
		Thread t2=new Thread(consumer);
		
		t1.start();
		t2.start();
		

	}

}
