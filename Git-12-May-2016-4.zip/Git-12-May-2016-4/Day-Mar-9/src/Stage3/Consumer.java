package Stage3;

public class Consumer implements Runnable{

	WareHouse wh;
	
	public Consumer(WareHouse wh) {
		this.wh=wh;
	}
	@Override
	public void run() {
		while(true){
			System.out.println("Stack is consuming");
			int num=wh.remove();
			System.out.println("pop-"+num);
			
		}
		
	}

}