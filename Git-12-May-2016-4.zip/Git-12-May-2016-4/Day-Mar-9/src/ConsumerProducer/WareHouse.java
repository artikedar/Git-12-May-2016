package ConsumerProducer;

import java.util.Stack;

public class WareHouse {
	private Stack<Integer> stack=new Stack<Integer>();
	
	public void add(int x){
		if(stack.size()==10){
			try {
				wait();
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		}
		stack.push(x);
	}
	
	public int remove(){
		if(stack.isEmpty()){
			try {
				wait();
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		}
		return stack.pop();
	}

}
