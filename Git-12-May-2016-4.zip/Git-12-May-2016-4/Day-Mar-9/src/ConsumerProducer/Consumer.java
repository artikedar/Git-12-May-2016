package ConsumerProducer;

public class Consumer implements Runnable{

	WareHouse wh;
	
	public Consumer(WareHouse wh) {
		this.wh=wh;
	}
	@Override
	public void run() {
		while(true){
			wh.remove();
		}
		
	}

}
