package ConsumerProducer;

import java.util.Random;

public class Producer implements Runnable{

	WareHouse wh;
	
	public Producer(WareHouse wh) {
		this.wh=wh;
	}
	@Override
	public void run() {
		while(true){
			int x=new Random().nextInt(500);
			wh.add(x);
					
		}
		
		
	}

}
