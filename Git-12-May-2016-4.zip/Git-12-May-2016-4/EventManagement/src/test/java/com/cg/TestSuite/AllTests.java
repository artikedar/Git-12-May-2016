package com.cg.TestSuite;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.cg.TestAdminDashBoard.TestAdmin;
import com.cg.TestBooking.BookingTestCases;
import com.cg.TestComment.CommentTest;
import com.cg.TestSearch.SearchTestCasesForCategory;
import com.cg.TestSearch.SearchTestCasesForDate;
import com.cg.TestSearch.SearchTestCasesForPerformer;
import com.cg.TestSearch.SearchTestCasesForPopularity;
import com.cg.TestSearch.SearchTestCasesForTitle;
import com.cg.TestSearch.SearchTestCasesForVenue;
import com.cg.TestSignUp.SignUpTest;
import com.cg.TestUserDashBoard.TestUser;
import com.cg.email.MailTest;

@RunWith(Suite.class)
@SuiteClasses({
	MailTest.class,
	TestAdmin.class,
	BookingTestCases.class,
	SearchTestCasesForCategory.class,
	SearchTestCasesForDate.class,
	SearchTestCasesForPerformer.class,
	SearchTestCasesForPopularity.class,
	SearchTestCasesForVenue.class,
	SearchTestCasesForTitle.class,
	TestUser.class,
	CommentTest.class,
	SignUpTest.class
	
})
public class AllTests {

}
