package com.cg.TestSearch;

import static org.junit.Assert.*;

import org.junit.Test;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.cg.ems.service.SearchService;
import com.cg.ems.service.SearchServiceImpl;

public class SearchTestCasesForVenue 
{
	GenericXmlApplicationContext ctx = new GenericXmlApplicationContext("beanConfig.xml");
	SearchService sserv = ctx.getBean("sservice",SearchServiceImpl.class);

	@Test
	public void displayEventsWithValidCityNameOnly()
	{
		sserv.findByCity("Mumbai");
	}
	@Test
	public void doNotDisplayEventForInvalidCityName()
	{
		assertFalse(sserv.findByCity("XYZ").size()>=1);
	}

	@Test
	public void doNotDisplayEventForNullCityName()
	{
		assertFalse(sserv.findByCity(null).size()>=1);
	}

}
