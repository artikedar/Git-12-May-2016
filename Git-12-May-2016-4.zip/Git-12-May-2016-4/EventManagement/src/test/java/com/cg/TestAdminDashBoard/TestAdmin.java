package com.cg.TestAdminDashBoard;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.cg.ems.pojo.EventVO;
import com.cg.ems.service.AdminService;
import com.cg.ems.service.AdminServiceImpl;

public class TestAdmin 
{
	GenericXmlApplicationContext ctx = new GenericXmlApplicationContext("beanConfig.xml");
	AdminService aserv=ctx.getBean("aservice",AdminServiceImpl.class);
	@Test
	public void eventWithInProgressStatusShouldBeDisplayedForApproval()
	{
		//aserv.approveEvent(1);
		List<EventVO> events=aserv.findApproveEvents();
		for(EventVO ev:events)
		{
			assertTrue(ev.getStatus().equalsIgnoreCase("In Progress"));
		}
		
	}
	

	@Test
	public void	doNotDisplayEventIfEventStatusIsRejected()
	{
		List<EventVO> events=aserv.findApproveEvents();
		for(EventVO ev:events)
		{
			assertFalse(ev.getStatus().equalsIgnoreCase("rejected"));
		}
		
	}		
	}
