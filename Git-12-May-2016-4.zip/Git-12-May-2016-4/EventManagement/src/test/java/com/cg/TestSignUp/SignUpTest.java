package com.cg.TestSignUp;

import org.junit.Test;


public class SignUpTest {

	


	@Test
	public void usernameshouldnotbenull(){
	
	}
	@Test
	public void passwordshouldnotbenull(){
		
		
	
	}
	@Test
	public void userNameShouldbeunique(){
		
	}
	@Test
	public void FirstNameShouldNotBenull(){
		
	}
	@Test
	public void LastNameShouldNotBeNull()
	{
	}
	@Test
	public void EmailShouldNotBeNull()
{

}
	
	@Test
	public void UserShouldContainValidPhoneno()
	{
		
	}

	@Test
	public void UserShouldContainValidEmail()
	{
		
	}
}
