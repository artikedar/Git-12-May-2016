package com.cg.ems.eventTests;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Test;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.cg.ems.exception.EventDetailsNullException;
import com.cg.ems.pojo.Address;
import com.cg.ems.pojo.Album;
import com.cg.ems.pojo.Category;
import com.cg.ems.pojo.Contact;
import com.cg.ems.pojo.Event;
import com.cg.ems.pojo.EventVO;
import com.cg.ems.pojo.Performer;
import com.cg.ems.pojo.PhotoCollection;
import com.cg.ems.pojo.Schedule;
import com.cg.ems.pojo.TicketType;
import com.cg.ems.pojo.User;
import com.cg.ems.service.EventService;
import com.cg.ems.service.EventServiceImpl;
import com.cg.ems.service.SearchService;
import com.cg.ems.service.SearchServiceImpl;


public class MainEvent {



	GenericXmlApplicationContext ctx = new GenericXmlApplicationContext("beanConfig.xml");
	EventService eServ = ctx.getBean("EventService",EventServiceImpl.class);
	SearchService sServ = ctx.getBean("sservice",SearchServiceImpl.class);
	
	
	@Test(expected=EventDetailsNullException.class)
	public void eventCannotBeCreatedAsEventDetailsAreNull() throws EventDetailsNullException{
				

		Event e= new Event();
		
		if(e.getEventName()==null)
		{
			throw new EventDetailsNullException();
		}
		else if(e.getCategory().getName()==null)
		{
			throw new EventDetailsNullException();			
		}
		else if(e.getAddress().getAddressLine()==null)
		{
			throw new EventDetailsNullException();			
		}
		else if(e.getAddress().getCity()==null)
		{
			throw new EventDetailsNullException();
			
		}
		else if(e.getDescription()==null)
		{
			throw new EventDetailsNullException();
		}
		else if(e.getDateStart()==null)
		{
			throw new EventDetailsNullException();
		}
		else if(e.getDateEnd()==null)
		{
			throw new EventDetailsNullException();
		}
		else if(e.getTickettype()==null) 
		{
			throw new EventDetailsNullException();			
		}
		else if(e.getAlbum().getAlbumName()==null)
		{
			throw new EventDetailsNullException();
		}
		else{
		for(Performer p:e.getPerformer())
		{
			if(p.getFirstName()==null || p.getLastName()==null)
			{
				throw new EventDetailsNullException();
			}
		}
		}
		if(e.getTickettype()!=null)
		{
		for(TicketType t:e.getTickettype())
		{
			if(t.getMaxCapacity()==0)
			{
				throw new EventDetailsNullException();
			}
		}
		}	
		
	}
	
		
	
	
	@Test
	public void eventSuccessfullyCreated() throws Exception{
		
		Event event = new Event();
		event.setEventName("Musiccc");
		Address ad=new Address();
		ad.setAddressLine("sghfshdgf");
		ad.setCity("sfg");
		ad.setCountry("India");
		PhotoCollection photo = new PhotoCollection();
		photo.setPhotoUrl("/Pictures/Sample Pictures/Desert.jpg");
		Album al=new Album();
		al.setAlbumName("AsdfNeww");
		Category cat=new Category();
		cat.setName("Music");
		Contact co=new Contact();
		co.setContactType("you");
		co.setValue("asd");
		Performer p= new Performer();
		p.setDescription("asd");
		p.setFirstName("asdfsdf");
		p.setLastName("Adsfsdf");
		p.setPhotoUrl("Asdfasdfd");
		
		TicketType ti=new TicketType();
		ti.setTicketType("new");
		ti.setMaxCapacity(100);
		ti.setPrice(100);
		ti.setAvailableSeats(400);
	
		Schedule sc = new Schedule();
		sc.setDate("2016-02-02");
		sc.setEndTime("12:12:52");
		sc.setStartTime("12:12:59");
		
	    event.setStatus("Approved");
	   
	    event.setDateStart("2016-02-02");
	    event.setDateEnd("2016-03-25");
	    event.setAddress(ad);
	    event.setSchedule(new HashSet<Schedule>());
	    event.getSchedule().add(sc);
	    event.setAlbum(al);
	    event.getAlbum().setPhotoCollection(new HashSet<PhotoCollection>());
	    event.getAlbum().getPhotoCollection().add(photo);
	    event.setPerformer(new HashSet<Performer>());
	    event.getPerformer().add(p);
	    event.setTickettype(new HashSet<TicketType>());
	    event.getTickettype().add(ti);
	    event.setContact(new HashSet<Contact>());
	    event.getContact().add(co);
event.setUserId(1);
	    event.setCategory(cat);

	
		
		
		
		
		
			System.out.println(	eServ.createEvent(event));
		
		
		
	}
	
	@Test
	public void twoEventShouldNotHaveSameNameAndSamePlace() throws Exception
	{
		Event event = new Event();
		event.setEventName("Musiccc");
		Address ad=new Address();
		ad.setAddressLine("sghfshdgf");
		ad.setCity("sfg");
		ad.setCountry("India");
		PhotoCollection photo = new PhotoCollection();
		photo.setPhotoUrl("/Pictures/Sample Pictures/Desert.jpg");
		Album al=new Album();
		al.setAlbumName("AsdfNeww");
		Category cat=new Category();
		cat.setName("Music");
		Contact co=new Contact();
		co.setContactType("you");
		co.setValue("asd");
		Performer p= new Performer();
		p.setDescription("asd");
		p.setFirstName("asdfsdf");
		p.setLastName("Adsfsdf");
		p.setPhotoUrl("Asdfasdfd");
		
		TicketType ti=new TicketType();
		ti.setTicketType("new");
		ti.setMaxCapacity(100);
		ti.setPrice(100);
		ti.setAvailableSeats(400);
	
		Schedule sc = new Schedule();
		sc.setDate("2016-02-02");
		sc.setEndTime("12:12:52");
		sc.setStartTime("12:12:59");
		
	    event.setStatus("Approved");
	   
	    event.setDateStart("2016-02-02");
	    event.setDateEnd("2016-03-25");
	    event.setAddress(ad);
	    event.setSchedule(new HashSet<Schedule>());
	    event.getSchedule().add(sc);
	    event.setAlbum(al);
	    event.getAlbum().setPhotoCollection(new HashSet<PhotoCollection>());
	    event.getAlbum().getPhotoCollection().add(photo);
	    event.setPerformer(new HashSet<Performer>());
	    event.getPerformer().add(p);
	    event.setTickettype(new HashSet<TicketType>());
	    event.getTickettype().add(ti);
	    event.setContact(new HashSet<Contact>());
	    event.getContact().add(co);
event.setUserId(1);
	    event.setCategory(cat);

		List<EventVO> ev=sServ.findByName("Bahare");
		for(EventVO event1:ev)
		{
		if(event1.getEventName().equalsIgnoreCase(event.getEventName()) )
		{
		
		}else{
			throw new Exception();
		}
		}
		
		
	}
	
		
	@Test(expected=Exception.class)
	public void modifyEventforvalideventId()throws Exception
	{

		Event event = new Event();
		event.setEventName("Musiccc");
		Address ad = new Address();
		ad.setAddressLine("sghfshdgf");
		ad.setCity("sfg");
		PhotoCollection photo = new PhotoCollection();
		photo.setPhotoUrl("vamsi");
		Album al = new Album();
		al.setAlbumName("AsdfNeww");
		Category cat = new Category();
		cat.setName("Music");
		Contact co = new Contact();
		co.setContactType("you");
		co.setValue("asd");
		Performer p = new Performer();
		p.setDescription("asd");
		p.setFirstName("asdfsdf");
		p.setLastName("Adsfsdf");
		p.setPhotoUrl("Asdfasdfd");
		TicketType ti = new TicketType();
		ti.setTicketType("new");
		ti.setMaxCapacity(100);
		ti.setPrice(100);
		Schedule sc = new Schedule();
		sc.setDate("2016-02-02");
		// event.setDeleteDate(null);
		sc.setEndTime("12:12:52");
		sc.setStartTime("12:12:59");
		User u = new User();
		u.setFirstName("sulochana");
		u.setLastName("hjdf");
		u.setPhoneNo("8712284121");
		u.setPhotoUrl("Hello");
		u.setUsername("vijaya");
		u.setEmail("vijaya.rao@capgmeini");
		event.setDateStart("2016-02-02");
		event.setDateEnd("2016-03-25");
		event.setAddress(ad);
		event.setSchedule(new HashSet<Schedule>());
		event.getSchedule().add(sc);
		event.setAlbum(al);
		event.getAlbum().setPhotoCollection(new HashSet<PhotoCollection>());
		event.getAlbum().getPhotoCollection().add(photo);
		event.setPerformer(new HashSet<Performer>());
		event.getPerformer().add(p);
		event.setTickettype(new HashSet<TicketType>());
		event.getTickettype().add(ti);
		event.setContact(new HashSet<Contact>());
		event.getContact().add(co);
		event.setStatus("Approved");
		event.setCategory(cat);

	
		
		Event ev = eServ.findEvent(131111);
		
		if(ev==null)
		{
			throw new Exception();
			
		}
		else
		{
			eServ.modifyEvent(13, event);
		}
		}
		
	
	@Test
	public void removeEventIfEventnameIsValid() throws Exception
	{
		
		List<EventVO> ev = sServ.findByName("sargam");
		
		for(EventVO ev1:ev)
		{
		if(ev1==null)
		{
			throw new Exception();
			
		}
		else
		{
			eServ.deleteEvent(ev1.getEventId());
		}
		
		}
		
		
		
	}
	

}
