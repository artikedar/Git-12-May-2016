package com.cg.email;

import static org.junit.Assert.*;

import org.junit.Test;

import static org.junit.Assert.*;

import org.junit.Test;

public class MailTest {

	@Test
	public void EmailIdDoesNotExist() {
		
	}
	@Test
	public void EmailSentSuccessfully(){
		
}
	}
