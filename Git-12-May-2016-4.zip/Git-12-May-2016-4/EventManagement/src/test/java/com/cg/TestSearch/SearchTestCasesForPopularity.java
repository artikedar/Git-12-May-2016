package com.cg.TestSearch;

import static org.junit.Assert.*;

import org.junit.Test;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.cg.ems.service.SearchService;
import com.cg.ems.service.SearchServiceImpl;

public class SearchTestCasesForPopularity {

	GenericXmlApplicationContext ctx = new GenericXmlApplicationContext("beanConfig.xml");
	SearchService sserv = ctx.getBean("sservice",SearchServiceImpl.class);
	
	@Test
	public void displayPopularEvent()
	{
		sserv.findByRating();
	}
	

}
