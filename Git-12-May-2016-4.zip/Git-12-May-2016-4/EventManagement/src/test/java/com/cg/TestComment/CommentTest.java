package com.cg.TestComment;

import static org.junit.Assert.*;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.cg.ems.pojo.Comment;
import com.cg.ems.pojo.Reply;
import com.cg.ems.pojo.User;
import com.cg.ems.service.CommentService;
import com.cg.ems.service.ReplyService;
import com.cg.ems.service.UserServiceInter;

public class CommentTest {
	
	@Autowired
	CommentService cservice;
	
	@Autowired
	UserServiceInter userService;
	
	@Autowired
	ReplyService rservice;
	
  
	@Test(expected = Exception.class)
	public void commentTextNull() throws Exception {
		Comment c = new Comment();
		User u = userService.getUserProfile(1);
		c.setEventId(1);
		c.setUser(u);
		c.setCommentText("");
		cservice.saveComment(c);
	
	}
	
	
	@Test(expected = Exception.class)
	public void replyTextNull() throws Exception {
		Reply r = new Reply();
		User u = userService.getUserProfile(1);
		r.setCommentId(1);
		r.setReplyText("");
		r.setUser(u);
		rservice.saveReply(r);
		
	}
	
}