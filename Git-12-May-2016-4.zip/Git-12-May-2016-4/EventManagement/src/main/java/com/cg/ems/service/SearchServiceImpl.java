package com.cg.ems.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ems.pojo.EventVO;
import com.cg.ems.repo.SearchRepo;
@Service(value="sservice")
public class SearchServiceImpl implements SearchService {

	@Autowired
	SearchRepo srepo;
	@Override
	public List<EventVO> findByPerformer(String firstName, String lastName) {
		List<EventVO> evo = srepo.searchByPerformer(firstName, lastName);
		for(EventVO ev:evo){
			ev.setPhotoCollections(srepo.photocollectionList(ev.getAlbumId()));
		}
		return evo;
	}
	@Override
	public List<EventVO> findByDate(String date) {
		// TODO Auto-generated method stub
		List<EventVO> evo = srepo.searchByDate(date);
		for(EventVO ev:evo){
			ev.setPhotoCollections(srepo.photocollectionList(ev.getAlbumId()));
		}
		return evo;
	}
	@Override
	public List<EventVO> findByRating() {
		// TODO Auto-generated method stub
		List<EventVO> evo = srepo.searchByRating();
		for(EventVO ev:evo){
			ev.setPhotoCollections(srepo.photocollectionList(ev.getAlbumId()));
		}
		return evo;
	}
	@Override
	public List<EventVO> findByCategory(String name) {
		// TODO Auto-generated method stub
		List<EventVO> evo = srepo.searchByCategory(name);
		for(EventVO ev:evo){
			ev.setPhotoCollections(srepo.photocollectionList(ev.getAlbumId()));
		}
		return evo;
	}
	@Override
	public List<EventVO> findByCity(String city) {
		// TODO Auto-generated method stub
		List<EventVO> evo = srepo.searchByCity(city);
		for(EventVO ev:evo){
			ev.setPhotoCollections(srepo.photocollectionList(ev.getAlbumId()));
		}
		return evo;
	}
	@Override
	public List<EventVO> findByName(String eventName) {
		// TODO Auto-generated method stub
		List<EventVO> evo = srepo.searchByName(eventName);
		System.out.println(srepo.searchByName(eventName));
		for(EventVO ev:evo){
			ev.setPhotoCollections(srepo.photocollectionList(ev.getAlbumId()));
		}
		return evo;
	}



}
