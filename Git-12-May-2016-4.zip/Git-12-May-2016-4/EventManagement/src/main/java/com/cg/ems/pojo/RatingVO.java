package com.cg.ems.pojo;

public class RatingVO {
 private int rname;
 private long rvalue;
public RatingVO(int rname, long rvalue) {
	super();
	this.rname = rname;
	this.rvalue = rvalue;
}

public int getRname() {
	return rname;
}

public long getRvalue() {
	return rvalue;
}

@Override
public String toString() {
	return "RatingVO [rname=" + rname + ", rvalue=" + rvalue + "]";
}
 
}
