package com.cg.ems.exception;

public class SeatsNotAvailableException extends Exception {

}
