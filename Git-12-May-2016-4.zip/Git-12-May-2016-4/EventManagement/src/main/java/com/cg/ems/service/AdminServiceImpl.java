package com.cg.ems.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ems.pojo.BookingVO;
import com.cg.ems.pojo.Event;
import com.cg.ems.pojo.EventVO;
import com.cg.ems.pojo.User;
import com.cg.ems.repo.AdminRepo;
@Service(value="aservice")
public class AdminServiceImpl implements AdminService {
	@Autowired
	AdminRepo adminRepo;
	@Override
	public List<EventVO> findApproveEvents() {
		// TODO Auto-generated method stub
		List<EventVO> evo = adminRepo.approveEvents();
		for(EventVO ev:evo){
			ev.setPhotoCollections(adminRepo.photocollectionList(ev.getAlbumId()));
		}
		return evo;
	}

	@Override
	public List<BookingVO> getAllTransaction() {
		// TODO Auto-generated method stub
		List<BookingVO> bol=adminRepo.BookingVoList();
		EventVO ev;
		for(BookingVO bo:bol){
			bo.setContact(adminRepo.contactList(bo.getEventId()));
			bo.setUser(adminRepo.userOfBooking(bo.getBookingId()));
			bo.setTickettype(adminRepo.tickettypeForBooking(bo.getTicketId()));
			ev=adminRepo.queryByEventId(bo.getEventId());
			System.out.println(ev);
			ev.setPhotoCollections(adminRepo.photocollectionList(ev.getAlbumId()));
			bo.setEventvo(ev);
			
		}
		return bol;
	}

	@Override
	public boolean approveEvent(int eventId) {
		// TODO Auto-generated method stub
		Event e = adminRepo.searchByEventId(eventId);
		e.setStatus("Approved");
		System.out.println(344555);
		adminRepo.save(e);
		return true;
	}

	@Override
	public boolean rejectEvent(int eventId) {
		// TODO Auto-generated method stub
		Event e = adminRepo.searchByEventId(eventId);
		e.setStatus("Reject");
		adminRepo.save(e);
		return true;
	}

	@Override
	public User getAdminDetails(int userId) {
		// TODO Auto-generated method stub
		return adminRepo.getAdminProfile(userId);
	}

	
}
