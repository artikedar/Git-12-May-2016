package com.cg.ems.service;

import java.util.List;

import com.cg.ems.exception.SeatsNotAvailableException;
import com.cg.ems.exception.UserNotLoggedInException;
import com.cg.ems.pojo.Booking;
import com.cg.ems.pojo.BookingVO;

public interface BookingService{
	

	public Booking processBooking(Booking booking) throws UserNotLoggedInException, SeatsNotAvailableException;
	
	public BookingVO finalizeBooking(int bookingId,String transactionId);
	
	
	public BookingVO getBookingObject(int bookingId);

	

}
