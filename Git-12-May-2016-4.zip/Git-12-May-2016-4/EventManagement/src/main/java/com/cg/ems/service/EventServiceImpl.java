package com.cg.ems.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.cg.ems.exception.EventDetailsNullException;
import com.cg.ems.pojo.Event;
import com.cg.ems.pojo.EventVO;
import com.cg.ems.repo.BookingRepo;
import com.cg.ems.repo.EventRepo;
import com.cg.ems.repo.EventVoRepo;
import com.cg.ems.repo.RatingRepo;
@Service(value="EventService")
public class EventServiceImpl implements EventService {
	@Autowired
	EventRepo eventRepo;
	@Autowired
	EventVoRepo eventVORepo;
	@Autowired
	BookingRepo brepo;
	@Autowired
	RatingRepo rrepo;

	@Override
	public Event createEvent(Event e) throws EventDetailsNullException {

		return eventRepo.save(e);
	}

	@Override
	public Event modifyEvent(int eventId,Event event) {
		// TODO Auto-generated method stub
System.out.println(event);
		Event ev = eventRepo.searchByEventId(eventId);
		Date date = new Date();
		ev.setDeleteDate( new java.sql.Timestamp(date.getTime()));
		System.out.println(ev.getDeleteDate());
		eventRepo.save(ev);
		
	
		event.setDeleteDate(null);
		
		return eventRepo.save(event);
	}

	@Override
	public boolean deleteEvent(int eventid) {
		// TODO Auto-generated method stub
		Event ev = eventRepo.searchByEventId(eventid);
		
	if(ev!=null)
		{
		Date date = new Date();
		java.sql.Timestamp currentTimestamp = new java.sql.Timestamp(
				date.getTime());
		ev.setDeleteDate(currentTimestamp);
		eventRepo.save(ev);
		return true;
	}
	return false;	
	}

	@Override
	public List<EventVO> SearchEventVo(int eventId) {
		// TODO Auto-generated method stub
		List<EventVO> evo = eventVORepo.queryByEventId(eventId);
		for (EventVO ev : evo) {
			ev.setPhotoCollections(eventVORepo.photocollectionList(ev.getAlbumId()));
		}
		return evo;
	}

	@Override
	public Event findEvent(int eventid) {
		System.out.println(eventRepo.searchByEventId(eventid));
		return eventRepo.searchByEventId(eventid);
	}
	
	@Override
	public List<String> allCategory(){
		return eventRepo.listOfCategory();
	}
	
	@Override
	public List<String> allCity(){
		return eventRepo.listOfCity();
	}
	
	@Override
	public List<String> allEvents(){
		return eventRepo.listOfEventName();
	}
	
	@Override
	public List<String> allPerformers(){
		return eventRepo.listOfPerformers();
	}
	
	@Override
	public List<EventVO> popularEvents(){
		List<EventVO> evo = eventVORepo.popularEvent(new PageRequest(0, 4));
		for (EventVO ev : evo) {
			ev.setPhotoCollections(eventVORepo.photocollectionList(ev.getAlbumId()));
		}
		return evo;
	}
	
	@Override
	public List<EventVO> upcomingEventList(){
		List<EventVO> evo = eventVORepo.upcomingEvent(new PageRequest(0, 4));
		for (EventVO ev : evo) {
			ev.setPhotoCollections(eventVORepo.photocollectionList(ev.getAlbumId()));
		}
		return evo;
	}

}
