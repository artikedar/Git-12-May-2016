package com.cg.ems.service;

import java.util.List;
import com.cg.ems.exception.EventDetailsNullException;
import com.cg.ems.pojo.Event;
import com.cg.ems.pojo.EventVO;


public interface EventService {
    	
	public Event createEvent(Event e) throws EventDetailsNullException;

	
//	public String deleteEvent(int id);
public Event findEvent(int eventid);

	
	boolean deleteEvent(int eventid);
	public List<String> allCategory();
	List<String> allCity();
	List<String> allEvents();
	List<String> allPerformers();
	Event modifyEvent(int eventId, Event event);
	List<EventVO> upcomingEventList();

	List<EventVO> popularEvents();


	List<EventVO> SearchEventVo(int eventId);
	
}
