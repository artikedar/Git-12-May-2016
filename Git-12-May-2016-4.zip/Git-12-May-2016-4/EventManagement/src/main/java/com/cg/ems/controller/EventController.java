package com.cg.ems.controller;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ems.pojo.Address;
import com.cg.ems.pojo.Album;
import com.cg.ems.pojo.Category;
import com.cg.ems.pojo.Contact;
import com.cg.ems.pojo.Event;
import com.cg.ems.pojo.Performer;
import com.cg.ems.pojo.PhotoCollection;
import com.cg.ems.pojo.Schedule;
import com.cg.ems.pojo.TicketType;
import com.cg.ems.service.EventService;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController

public class EventController {

	@Autowired
	EventService eventService;

	@RequestMapping(value="/createEvent",method=RequestMethod.POST,consumes="application/json",produces="application/json")
	@JsonCreator
	public @ResponseBody boolean createEvent(@RequestBody String eventString) throws Exception{



		System.out.println(eventString);
		ObjectMapper mapper = new ObjectMapper();
		Event events=mapper.readValue(eventString, Event.class);
		System.out.println(events);
		if( eventService.createEvent(events)!=null)
			return true;

		return false;
	}

	@RequestMapping(value="/findEvent")
	public Event findEvent(int eventId){
		return eventService.findEvent(eventId); 
	}
	@RequestMapping(value="/modifyEvent",method=RequestMethod.POST,consumes="application/json",produces="application/json")
	@JsonCreator
	public @ResponseBody boolean modifyEvent(int eventId,@RequestBody String event) throws Exception{
		System.out.println(event);
		System.out.println(eventId);
		try{
			ObjectMapper mapper = new ObjectMapper();
			Event events=mapper.readValue(event, Event.class);
			Event eventss=new Event();
			eventss.setEventName(events.getEventName());
			eventss.setDateStart(events.getDateStart());
			eventss.setDateEnd(events.getDateEnd());
			eventss.setCategory(events.getCategory());
			Category cc=new Category();
			cc.setName(events.getCategory().getName());
			eventss.setCategory(cc);

			eventss.setAvgRating(events.getAvgRating());

			Address ad = new Address();
			ad.setAddressLine(events.getAddress().getAddressLine());
			ad.setCity(events.getAddress().getCity());
			ad.setCountry(events.getAddress().getCountry());
			eventss.setAddress(ad);
			Set<PhotoCollection> photos=new HashSet<PhotoCollection>();
			PhotoCollection photo = new PhotoCollection();

			for(PhotoCollection p:events.getAlbum().getPhotoCollection()){
				photo.setPhotoUrl(p.getPhotoUrl());
				photos.add(photo);
			}

			Album al = new Album();
			al.setAlbumName(events.getAlbum().getAlbumName());
			al.setPhotoCollection(photos);
			eventss.setAlbum(al);

			eventss.setDescription(events.getDescription());
			eventss.setUserId(events.getUserId());
			eventss.setStatus(events.getStatus());



			Set<Contact> contacts=new HashSet<Contact>();
			Contact co = new Contact();
			for(Contact c:events.getContact()){
				co.setContactType(c.getContactType());
				co.setValue(c.getValue());
				contacts.add(co);
			}
			eventss.setContact(contacts);

			Set<Performer> performers=new HashSet<Performer>();
			Performer prf = new Performer();
			for(Performer p:events.getPerformer()){
				prf.setFirstName(p.getFirstName());
				prf.setLastName(p.getLastName());
				prf.setDescription(p.getDescription());
				prf.setPhotoUrl(p.getPhotoUrl());
				performers.add(prf);
			}
			eventss.setPerformer(performers);

			Set<Schedule> schedules=new HashSet<Schedule>();
			Schedule sch = new Schedule();
			for(Schedule s:events.getSchedule()){
				sch.setDate(s.getDate());
				sch.setStartTime(s.getStartTime());
				sch.setEndTime(s.getEndTime());
				schedules.add(sch);
			}
			eventss.setSchedule(schedules);

			Set<TicketType> TicketTypes=new HashSet<TicketType>();
			TicketType tt = new TicketType();
			for(TicketType t:events.getTickettype()){
				tt.setAvailableSeats(t.getAvailableSeats());
				tt.setMaxCapacity(t.getMaxCapacity());
				tt.setPrice(t.getMaxCapacity());
				tt.setTicketType(t.getTicketType());
				TicketTypes.add(tt);
			}
			eventss.setTickettype(TicketTypes);

			return true;
		}
		catch(Exception e){
			return false;
		}
	} 

	@RequestMapping(value="/deleteEvent")
	public boolean deleteEvent(int eventId){
		return eventService.deleteEvent(eventId);
	}
	/*Event event = new Event();
	event.setEventName("Musiccc");
	Address ad = new Address();
	ad.setAddressLine("sghfshdgf");
	ad.setCity("sfg");
	PhotoCollection photo = new PhotoCollection();
	photo.setPhotoUrl("vamsi");
	Album al = new Album();
	al.setAlbumName("AsdfNeww");
	Category cat = new Category();
	cat.setName("Music");
	Contact co = new Contact();
	co.setContactType("you");
	co.setValue("asd");
	Performer p = new Performer();
	p.setDescription("asd");
	p.setFirstName("asdfsdf");
	p.setLastName("Adsfsdf");
	p.setPhotoUrl("Asdfasdfd");
	TicketType ti = new TicketType();
	ti.setTicketType("new");
	ti.setMaxCapacity(100);
	ti.setPrice(100);
	Schedule sc = new Schedule();

	sc.setDate("2016-02-02");
	// event.setDeleteDate(null);
	sc.setEndTime("12:12:52");
	sc.setStartTime("12:12:59");
	User u = new User();
	u.setFirstName("sulochana");
	u.setLastName("hjdf");
	u.setPhoneNo("8712284121");
	u.setPhotoUrl("Hello");
	u.setUsername("vijaya");
	u.setEmail("vijaya.rao@capgmeini");
	event.setDateStart("2016-02-02");
	event.setDateEnd("2016-03-25");
	event.setAddress(ad);
	event.setSchedule(new HashSet<Schedule>());
	event.getSchedule().add(sc);
	event.setAlbum(al);
	event.getAlbum().setPhotoCollection(new HashSet<PhotoCollection>());
	event.getAlbum().getPhotoCollection().add(photo);
	event.setPerformer(new HashSet<Performer>());
	event.getPerformer().add(p);
	event.setTickettype(new HashSet<TicketType>());
	event.getTickettype().add(ti);
	event.setContact(new HashSet<Contact>());
	event.getContact().add(co);
	event.setUser(u);
	event.setStatus("Approved");
	event.setCategory(cat);*/

}
