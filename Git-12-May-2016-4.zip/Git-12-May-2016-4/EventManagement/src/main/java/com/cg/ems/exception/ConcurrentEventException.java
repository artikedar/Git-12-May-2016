package com.cg.ems.exception;

public class ConcurrentEventException extends Exception{

}
