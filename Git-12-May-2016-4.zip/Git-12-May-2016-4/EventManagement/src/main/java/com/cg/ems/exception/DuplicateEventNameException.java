package com.cg.ems.exception;

public class DuplicateEventNameException extends Exception{

}
