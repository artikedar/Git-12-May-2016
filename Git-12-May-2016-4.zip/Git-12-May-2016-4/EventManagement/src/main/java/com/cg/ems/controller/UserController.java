package com.cg.ems.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ems.pojo.BookingVO;
import com.cg.ems.pojo.EventVO;
import com.cg.ems.pojo.User;
import com.cg.ems.service.UserServiceInter;

@RestController
public class UserController{

	@Autowired
	UserServiceInter uservice;
	@RequestMapping(value="/udetails")
	public User findUserProfile(int userId)
	{
		
		return uservice.getUserProfile(userId);
	}
	
	
	
	@RequestMapping(value="/ubookings")
	public List<BookingVO> userBookings(int userId)
	{
		return uservice.getUserBookedEvents(userId); 
	}
	

	@RequestMapping(value="/uevents")
	public List<EventVO> userEvents(int userId)
	{
		return uservice.getUserAddedEvents(userId);
	}
	

}
