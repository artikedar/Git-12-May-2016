package com.cg.ems.pojo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.codec.binary.Base64;

@Entity
@Table(name="photo_collection")
public class PhotoCollection {
	 @Id
	   @GeneratedValue(strategy=GenerationType.AUTO)
	 @Column(name="photo_collection_id")
private int photoCollectionId;
	 
/*//@ManyToOne
//@JoinColumn(name="album_id")
//private Album photoAlbum;
*/
@Column(name="photo_url")
private	String photoUrl;

@Column(name="album_id",insertable=false,updatable=false)
private int albumId;	

public String getPhotoUrl() {
	
//File file = new File(photoUrl);
/*	String photoUrl1=photoUrl;
	try {
		
		
		FileInputStream imageInFile = new FileInputStream(file);
		byte imageData[] = new byte[(int)file.length()];
		imageInFile.read(imageData);
		
		
		// * Converting a Base64 String into Image byte array 
		 photoUrl1 = encodeImage(imageData);
		
		
		System.out.println(photoUrl1);
		
		 
		
		imageInFile.close();
		
		System.out.println("Image Successfully Manipulated!");
	} catch (FileNotFoundException e) {
		System.out.println("Image not found" + e);
	} catch (IOException ioe) {
		System.out.println("Exception while reading the Image " + ioe);
	}
*/
	
	
	return photoUrl;
}
public int getAlbumId() {
	return albumId;
}
public void setAlbumId(int albumId) {
	this.albumId = albumId;
}
static int i=1;
public void setPhotoUrl(String photoUrl) {
	String path="D:/Photos/Images";
	if(photoUrl.startsWith("data")){
	try {
		
		
		
		String data=photoUrl;
		
		String[] data1=data.split("base64,");
		
		// * Converting a Base64 String into Image byte array 
		 
		byte[] imageByteArray = decodeImage(data1[1]);
		
		
		// * Write a image byte array into file system  
		 
		
		photoUrl=path+"image"+i+++".jpg";
		FileOutputStream imageOutFile = new FileOutputStream(photoUrl);
		imageOutFile.write(imageByteArray);
		
		
		imageOutFile.close();
		System.out.println("Image Successfully Manipulated!");
	} catch (FileNotFoundException e) {
		System.out.println("Image not found" + e);
	} catch (IOException ioe) {
		System.out.println("Exception while reading the Image " + ioe);
	}
	}
	this.photoUrl = photoUrl;
}
public int getPhotoCollectionId() {
	return photoCollectionId;
}
public void setPhotoCollectionId(int photoCollectionId) {
	this.photoCollectionId = photoCollectionId;
}
/*public Album getPhotoAlbum() {
	return photoAlbum;
}
public void setPhotoAlbum(Album album) {
	this.photoAlbum = album;
}*/

/**
 * Encodes the byte array into base64 string
 * @param imageByteArray - byte array
 * @return String a {@link java.lang.String}
 */
public static String encodeImage(byte[] imageByteArray){		
	return Base64.encodeBase64URLSafeString(imageByteArray);		
}

/**
 * Decodes the base64 string into byte array
 * @param imageDataString - a {@link java.lang.String} 
 * @return byte array
 */
public static byte[] decodeImage(String imageDataString) {		
	return Base64.decodeBase64(imageDataString);
}

	
	
}
