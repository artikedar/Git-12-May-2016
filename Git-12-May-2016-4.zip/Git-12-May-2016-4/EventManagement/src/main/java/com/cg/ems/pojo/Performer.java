package com.cg.ems.pojo;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

import org.apache.commons.codec.binary.Base64;

@Entity
public class Performer {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="performer_id",unique = true, nullable = false)
	private int performerId;
	
	@Column(name="first_name")
	private String firstName;
	
	@Column(name="last_name")
	private String lastName;
	
	private String description;
	
	@Column(name="photo_url")
	private String photoUrl;
	
	@ManyToMany(mappedBy = "performer", fetch=FetchType.LAZY)
	private Set<Event> events;
	
	
	public int getPerformerId() {
		return performerId;
	}
	public void setPerformerId(int performerId) {
		this.performerId = performerId;
	}
	
	
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPhotoUrl() {
		return photoUrl;
	}
	static int i=1;
	public void setPhotoUrl(String photoUrl) {
		
		String path="D:/Photos/Imagess";
		if(photoUrl.startsWith("data")){
		try {
			
			
			
			String data=photoUrl;
			String[] data1=data.split("base64,");
			
			// * Converting a Base64 String into Image byte array 
			 
			byte[] imageByteArray = decodeImage(data1[1]);
			
			
			// * Write a image byte array into file system  
			 
			
			photoUrl=path+"image"+i+++".jpg";
			FileOutputStream imageOutFile = new FileOutputStream(photoUrl);
			imageOutFile.write(imageByteArray);
			
			
			imageOutFile.close();
			System.out.println(photoUrl);
			System.out.println("Image Successfully Manipulated!");
		} catch (FileNotFoundException e) {
			System.out.println("Image not found" + e);
		} catch (IOException ioe) {
			System.out.println("Exception while reading the Image " + ioe);
		}
		
		}
		this.photoUrl = photoUrl;
	}
	
	
	/**
	 * Decodes the base64 string into byte array
	 * @param imageDataString - a {@link java.lang.String} 
	 * @return byte array
	 */
	public static byte[] decodeImage(String imageDataString) {		
		return Base64.decodeBase64(imageDataString);
	}
	
	
	
}
