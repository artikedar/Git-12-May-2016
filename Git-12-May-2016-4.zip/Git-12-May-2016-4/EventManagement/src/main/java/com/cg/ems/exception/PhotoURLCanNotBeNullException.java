package com.cg.ems.exception;

public class PhotoURLCanNotBeNullException extends Exception{

}
