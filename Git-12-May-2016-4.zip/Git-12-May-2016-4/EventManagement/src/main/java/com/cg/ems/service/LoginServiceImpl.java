package com.cg.ems.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ems.pojo.Loginn;
import com.cg.ems.repo.LoginRepo;

@Service(value="loginService")
public class LoginServiceImpl implements LoginServiceInter {

	@Autowired
	LoginRepo repo;

	@Override
	public Loginn saveLogin(Loginn l) throws Exception {
		if(l.getPassWord() == null)
			throw new Exception();
		if(l.getUserName()== null)
			throw new Exception();
		
	
	  return repo.save(l);
		
	
	}

	@Override
	public boolean savePassword(int id, String password) {
		Loginn l = repo.findOne(id);
		System.out.println(l);
		if(l == null)
			return false;
		else{
			l.setPassWord(password);
			repo.save(l);
			return true;
			
		}	
		
	}

}
