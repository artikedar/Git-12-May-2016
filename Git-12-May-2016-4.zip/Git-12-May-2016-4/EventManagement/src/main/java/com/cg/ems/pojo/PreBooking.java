package com.cg.ems.pojo;

public class PreBooking {


	private int merchantId;
	private int eventId;
	private int  userId;
	private int ticketId;
	private int noOfTickets;


	public int getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}
	public int getEventId() {
		return eventId;
	}
	public void setEventId(int eventId) {
		this.eventId = eventId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getTicketId() {
		return ticketId;
	}
	public void setTicketId(int ticketId) {
		this.ticketId = ticketId;
	}
	public int getNoOfTickets() {
		return noOfTickets;
	}
	public void setNoOfTickets(int noOfTickets) {
		this.noOfTickets = noOfTickets;
	}


	@Override
	public String toString() {
		return "PreBooking [merchantId=" + merchantId + ", eventId=" + eventId
				+ ", userId=" + userId + ", ticketId=" + ticketId
				+ ", noOfTickets=" + noOfTickets + "]";
	}


}
