
package com.cg.ems.pojo;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;



@Entity
public class Booking {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="booking_id")
	private int bookingId;
	
	@Column(name="event_id")
	private int eventId;
	
	@Column(name="user_id")
	private int userId;
	
	@Column(name="ticket_id")
	private int ticketId;
	
	@Column(name="transaction_id")
	private String transactionId;
	
	@Column(name="no_of_tickets")
	private int noOfTickets;
	
	@Column(name="booking_status")
	private String bookingStatus;
	
	@Column(name="total_amount")
	private float totalAmount;


	public int getBookingId() {
		return bookingId;
	}


	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}


	public int getEventId() {
		return eventId;
	}


	public void setEventId(int eventId) {
		this.eventId = eventId;
	}


	public int getUserId() {
		return userId;
	}


	public void setUserId(int userId) {
		this.userId = userId;
	}


	public int getTicketId() {
		return ticketId;
	}


	public void setTicketId(int ticketId) {
		this.ticketId = ticketId;
	}


	public String getTransactionId() {
		return transactionId;
	}


	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}


	public int getNoOfTickets() {
		return noOfTickets;
	}


	public void setNoOfTickets(int noOfTickets) {
		this.noOfTickets = noOfTickets;
	}


	public String getBookingStatus() {
		return bookingStatus;
	}


	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}


	public float getTotalAmount() {
		return totalAmount;
	}


	public void setTotalAmount(float totalAmount) {
		this.totalAmount = totalAmount;
	}


	@Override
	public String toString() {
		return "Booking [bookingId=" + bookingId + ", eventId=" + eventId
				+ ", userId=" + userId + ", ticketId=" + ticketId
				+ ", transactionId=" + transactionId + ", noOfTickets="
				+ noOfTickets + ", bookingStatus=" + bookingStatus
				+ ", totalAmount=" + totalAmount + "]";
	}
	
	

	
	
	
	




}
