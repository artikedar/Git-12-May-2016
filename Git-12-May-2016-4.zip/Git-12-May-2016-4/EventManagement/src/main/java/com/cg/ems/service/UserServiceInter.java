package com.cg.ems.service;

import java.util.List;

import com.cg.ems.pojo.BookingVO;
import com.cg.ems.pojo.Event;
import com.cg.ems.pojo.EventVO;
import com.cg.ems.pojo.User;

public interface UserServiceInter {
	
	public User getUserProfile(int id);
 public List<EventVO> getUserAddedEvents(int id);
 public List<BookingVO> getUserBookedEvents(int id);
 

}
