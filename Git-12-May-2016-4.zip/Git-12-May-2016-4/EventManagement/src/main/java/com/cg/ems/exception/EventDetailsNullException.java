package com.cg.ems.exception;

public class EventDetailsNullException extends Exception{

}
