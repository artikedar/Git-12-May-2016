package com.cg.ems.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cg.ems.pojo.Loginn;
import com.cg.ems.pojo.User;
import com.cg.ems.pojo.UserLogin;
import com.cg.ems.pojo.UserRole;
import com.cg.ems.service.LoginServiceInter;
import com.cg.ems.service.UserRoleServiceInter;
import com.cg.ems.service.UserServiceInterForSignUp;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
public class SignUpController {
	@Autowired
	UserServiceInterForSignUp uservice ;
	@Autowired
	LoginServiceInter lservice;
	@Autowired 
	UserRoleServiceInter urservice;



	@RequestMapping(value="/signUp",method = RequestMethod.POST,consumes="application/json", produces="application/json")
	@JsonCreator	
	public  @ResponseBody boolean addUser(@RequestBody String userlogin) throws Exception{
		ObjectMapper mapper=new ObjectMapper();
		UserLogin ul = mapper.readValue(userlogin, UserLogin.class);

		System.out.println(ul.toString());
		User u = new User();
		u.setFirstName(ul.getFirst_name());
		u.setLastName(ul.getLast_name());
		u.setPhoneNo(ul.getPhone_no());
		u.setUsername(ul.getUsername());
		u.setEmail(ul.getEmail());
		
		Loginn l = new Loginn();
		l.setUserName(ul.getUsername());
		l.setPassWord(ul.getPassword());

		System.out.println(u);
		System.out.println(l.toString());


		UserRole ur =new UserRole();
		ur.setRoleId(1);
		
		u = uservice.register(u);

		if(u == null )
			throw new Exception();
		else{		
			lservice.saveLogin(l);
			ur.setUserId(l.getLoginId());
			urservice.saveRole(ur);
		}

		return true;

	}
	
	@RequestMapping(value="/changePassWord")
	public @ResponseBody boolean changePassword(int user_id , String password){
		if( lservice.savePassword(user_id, password))
			return true;
		else
			return false;
	}

}
