package com.cg.ems.pojo;

import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;


@Entity
public class Reply {
	/*public Comment getComment() {
		return comment;
	}
	public void setComment(Comment comment) {
		this.comment = comment;
	}*/
	public Timestamp getLastUpdate() {
		return lastUpdate;
	}
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="reply_id")
	private int replyId;
	
	@ManyToOne
	@JoinColumn(name="user_id")
	private User user;
	
	/*@ManyToOne(cascade=CascadeType.MERGE)
	@JoinColumn(name="comment_id")
	private Comment comment;*/
	@Column(name="delete_date",insertable=false,updatable=true,nullable=true)
	private Timestamp delete_date;
	public Timestamp getDelete_date() {
		return delete_date;
	}
	public void setDelete_date(Timestamp delete_date) {
		this.delete_date = delete_date;
	}
	
	@Column(name="comment_id")
	private int commentId;
	
	public int getCommentId() {
		return commentId;
	}
	public void setCommentId(int commentId) {
		this.commentId = commentId;
	}
	@Column(name="reply_text")
	private String replyText;	
	
	@Column(name="last_update")
	private Timestamp lastUpdate;
	
	
	public int getReplyId() {
		return replyId;
	}
	public void setReplyId(int replyId) {
		this.replyId = replyId;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	
	public String getReplyText() {
		return replyText;
	}
	public void setReplyText(String replyText) {
		this.replyText = replyText;
	}
	public Timestamp getLast_update() {
		return lastUpdate;
	}
	public void setLastUpdate(Timestamp lastUpdate) {
		this.lastUpdate = lastUpdate;
	}
	@Override
	public String toString() {
		return "Reply [replyId=" + replyId + ", user=" + user + ", comment_id="
				+  ", replyText=" + replyText + ", lastUpdate="
				+ lastUpdate + "]";
	}
}
