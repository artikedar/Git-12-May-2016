package com.cg.ems.pojo;

import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.IndexColumn;
@Entity
public class Album {
	 @Id
	
	@GeneratedValue(strategy=GenerationType.AUTO)
	 @Column(name="album_id")
	private int albumId;
	 
	 @OneToOne(mappedBy = "album",fetch=FetchType.LAZY)
	 private Event event;
	 
    @Column(name="album_name")
	private String albumName;
    @OneToMany(fetch=FetchType.LAZY,cascade=CascadeType.ALL)
	@JoinColumn(name="album_id",nullable = false)
	private Set<PhotoCollection> photoCollection;
	 
	public int getAlbumId() {
		return albumId;
	}

	public void setAlbumId(int albumId) {
		this.albumId = albumId;
	}

	public String getAlbumName() {
		return albumName;
	}

	public void setAlbumName(String albumName) {
		this.albumName = albumName;
	}

	public Set<PhotoCollection> getPhotoCollection() {
		return photoCollection;
	}

	public void setPhotoCollection(Set<PhotoCollection> photoCollection) {
		this.photoCollection = photoCollection;
	}

/*<<<<<<< .mine
	public Event getEvent() {
		return event;
	}
=======
>>>>>>> .r33
*/
	
}
