package com.cg.main;


import java.util.HashSet;

import org.springframework.context.support.GenericXmlApplicationContext;

import com.cg.ems.exception.EventDetailsNullException;
import com.cg.ems.pojo.Address;
import com.cg.ems.pojo.Album;
import com.cg.ems.pojo.Category;
import com.cg.ems.pojo.Contact;
import com.cg.ems.pojo.Event;
import com.cg.ems.pojo.Performer;
import com.cg.ems.pojo.PhotoCollection;
import com.cg.ems.pojo.Schedule;
import com.cg.ems.pojo.TicketType;
import com.cg.ems.pojo.User;
import com.cg.ems.service.AdminService;
import com.cg.ems.service.AdminServiceImpl;
import com.cg.ems.service.BookingService;
import com.cg.ems.service.BookingServiceImpl;
import com.cg.ems.service.EventService;
import com.cg.ems.service.EventServiceImpl;
import com.cg.ems.service.RatingService;
import com.cg.ems.service.RatingServiceImpl;
import com.cg.ems.service.SearchService;
import com.cg.ems.service.SearchServiceImpl;
import com.cg.ems.service.UserServiceInter;
import com.cg.ems.service.UserServiceImpl;

public class Client {
	
	public static void main(String[] args) throws EventDetailsNullException {


	GenericXmlApplicationContext ctx = new GenericXmlApplicationContext("beanConfig.xml");
	EventService eServ = ctx.getBean("EventService",EventServiceImpl.class);
	BookingService bServ = ctx.getBean("bookingService",BookingServiceImpl.class);
	SearchService sserv = ctx.getBean("sservice",SearchServiceImpl.class);
	AdminService aserv=ctx.getBean("aservice",AdminServiceImpl.class);
	UserServiceInter userv=ctx.getBean("userService",UserServiceImpl.class);
	RatingService rserv=ctx.getBean("ratingService",RatingServiceImpl.class);
	Event event = new Event();
	event.setEventName("Music Event");
	Address ad=new Address();
	ad.setAddressLine("Talwade");
	ad.setCity("Not Pune");
	ad.setCountry("India");
	PhotoCollection photo = new PhotoCollection();
	photo.setPhotoUrl("D:/photo/image1.jpg");
	Album al=new Album();
	al.setAlbumName("Music Event");
	Category cat=new Category();
	cat.setName("Classical Music");
	Contact co=new Contact();
	co.setContactType("email");
	co.setValue("myemail@email.com");
	Performer p= new Performer();
	p.setDescription("I am performer");
	p.setFirstName("Pandit");
	p.setLastName("Shankar");
	p.setPhotoUrl("D:/photo/image1.jpg");
	TicketType ti=new TicketType();
	ti.setTicketType("Platinum");
	ti.setMaxCapacity(100);
	ti.setPrice(100);
	Schedule sc = new Schedule();
	sc.setDate("2016-02-02");
//	event.setDeleteDate(null);
	sc.setEndTime("12:12:52");
	sc.setStartTime("12:14:59");
	User u= new User();
    u.setFirstName("sulochana");
    u.setLastName("hjdf");
    u.setPhoneNo("8712284121");
    u.setPhotoUrl("D:/photo/image1.jpg");
    u.setUsername("vijaya");
    u.setEmail("vijaya.rao@capgmeini");
 event.setDateStart("2016-02-02");
event.setDateEnd("2016-03-25");
    event.setAddress(ad);
    event.setSchedule(new HashSet<Schedule>());
    event.getSchedule().add(sc);
    event.setAlbum(al);
    event.getAlbum().setPhotoCollection(new HashSet<PhotoCollection>());
    event.getAlbum().getPhotoCollection().add(photo);
    event.setPerformer(new HashSet<Performer>());
    event.getPerformer().add(p);
    event.setTickettype(new HashSet<TicketType>());
    event.getTickettype().add(ti);
    event.setContact(new HashSet<Contact>());
    event.getContact().add(co);
   
    event.setCategory(cat);
event.setStatus("Approved");
  //System.out.println( eServ.createEvent(event));
   // System.out.println(eServ.modifyEvent(16));
//System.out.println(eServ.findEvent(1));
	//System.out.println(eServ.deleteEvent(14));
//System.out.println(eServ.SearchEventVo());
    //System.out.println(eServ.Ratingcollection());
    //System.out.println(eServ.ChangeRating());
 //   System.out.println(eServ.searchBooking());
//System.out.println(bServ.searchBooking());
	//System.out.println(eServ.findEvent(2));
  //  System.out.println(sserv.findByPerformer("asd", "Adsf"));
    //System.out.println(sserv.findByDate("2016-01-23"));
  //  System.out.println(sserv.findByRating());
   // System.out.println(sserv.findByCategory("Music"));
    //System.out.println(sserv.findByCity("f"));
 // System.out.println(aserv.findApproveEvents());
    //System.out.println(aserv.getAllTransaction());
    //System.out.println(aserv.approveEvent(3));
   // System.out.println(aserv.rejectEvent(4));
   //System.out.println(userv.getUserProfile(1));
   // System.out.println(userv.getUserEvents(8));
  //  System.out.println(aserv);
//   System.out.println(aserv.approveEvent(3).getEventName());
  System.out.println(rserv.Ratingcollection(1));
 //   System.out.println(userv.getUserBookedEvents(8));
   
	}
}
