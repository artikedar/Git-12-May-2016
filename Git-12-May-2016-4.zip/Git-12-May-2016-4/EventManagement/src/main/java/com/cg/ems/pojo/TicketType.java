package com.cg.ems.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="ticket_type")
public class TicketType {
	 @Id
	    @GeneratedValue(strategy=GenerationType.AUTO)
	 @Column(name="ticket_id")
	private int ticketId;
	
	@Column(name="ticket_type")
	private String ticketType;
	@Column(name="max_capacity")
	private int maxCapacity;
	private float price;
	@Column(name="available_seats")
	private int availableSeats;
	
	

	
	public int getTicketId() {
		return ticketId;
	}

	public void setTicketId(int ticketId) {
		this.ticketId = ticketId;
	}

	

	

	public String getTicketType() {
		return ticketType;
	}

	public void setTicketType(String ticketType) {
		this.ticketType = ticketType;
	}

	public int getMaxCapacity() {
		return maxCapacity;
	}

	public void setMaxCapacity(int maxCapacity) {
		this.maxCapacity = maxCapacity;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public int getAvailableSeats() {
		return availableSeats;
	}

	public void setAvailableSeats(int availableSeats) {
		this.availableSeats = availableSeats;
	}

	@Override
	public String toString() {
		return "TicketType [ticketId=" + ticketId + ", ticketType="
				+ ticketType + ", maxCapacity=" + maxCapacity + ", price="
				+ price + ", availableSeats=" + availableSeats + "]";
	}

	
	
	
}