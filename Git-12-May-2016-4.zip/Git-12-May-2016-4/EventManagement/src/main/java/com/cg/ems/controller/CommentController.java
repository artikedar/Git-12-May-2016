package com.cg.ems.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ems.pojo.Comment;
import com.cg.ems.pojo.Reply;
import com.cg.ems.pojo.User;
import com.cg.ems.service.CommentService;
import com.cg.ems.service.ReplyService;

@RestController
public class CommentController {
	@Autowired
	 CommentService cserv;
	
	@Autowired
	ReplyService rserv;
	
	@RequestMapping(value="/findComment")
	public List<Comment> viewComment(int eventId) throws Exception{
		 
	         return cserv.getAll(eventId);
		 //System.out.println(cserv.findComment());
	
		 //System.out.println(cserv.deleteComment(1));
		}
	
	@RequestMapping(value="/deleteComment")
	public String deleteComment(int commentId , int userId) throws Exception{
		 
	         return cserv.deleteComment(commentId,userId);
		 
		}
	
	
	@RequestMapping(value="/addComment")
	public Comment addComment(int userId,int eventId,String text) throws Exception{
		User u1 = cserv.findUser(userId);
		Comment c = new Comment();
		 c.setCommentText(text);
		 c.setEventId(eventId);
		 //c.setDelete_date(new Timestamp(0));
		c.setUser(u1);
		return cserv.saveComment(c);
		
		}
	
	@RequestMapping(value="/addReply")
	public Reply addReply(int userId,int commentId,String text) throws Exception{
		User u1 = cserv.findUser(userId);
		Reply r = new Reply();
		r.setReplyText(text);
		 r.setCommentId(commentId);
		 r.setUser(u1);
		return rserv.saveReply(r);
		
		}
	

}
