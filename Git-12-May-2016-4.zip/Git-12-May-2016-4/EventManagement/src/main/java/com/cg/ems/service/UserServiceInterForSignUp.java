package com.cg.ems.service;

import com.cg.ems.pojo.User;

public interface UserServiceInterForSignUp {
	User register(User u) throws Exception;
}
