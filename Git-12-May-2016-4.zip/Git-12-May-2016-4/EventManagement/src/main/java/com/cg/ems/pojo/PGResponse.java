package com.cg.ems.pojo;

public class PGResponse {


	private int bookingId;
	private String transactionId;
	private float totalAmount;



	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public float getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(float totalAmount) {
		this.totalAmount = totalAmount;
	}



	@Override
	public String toString() {
		return "PGResponse [bookingId=" + bookingId + ", transactionId="
				+ transactionId + ", totalAmount=" + totalAmount + "]";
	}

}
