package com.cg.ems.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ems.pojo.Event;
import com.cg.ems.pojo.Rating;
import com.cg.ems.pojo.RatingVO;
import com.cg.ems.repo.EventRepo;
import com.cg.ems.repo.RatingRepo;
@Service(value="ratingService")
public class RatingServiceImpl implements RatingService{
	@Autowired
	EventRepo eventRepo;
	@Autowired
	RatingRepo rrepo;
	@Override
	public List<RatingVO> Ratingcollection(int eventId) {
		// TODO Auto-generated method stub
		return rrepo.searchRatings(eventId);
	}

	@Override
	public boolean ChangeRating(int eventId) {
		// TODO Auto-generated method stub
		float f= rrepo.updateRating(eventId);
		Event e = eventRepo.searchByEventId(eventId);
		e.setAvgRating(f);
		eventRepo.save(e);
		return true;
	
	}

	@Override
	public boolean saveRating(Rating rating) {
		// TODO Auto-generated method stub
		rrepo.save(rating);
		return ChangeRating(rating.getEventId());
	}
}
