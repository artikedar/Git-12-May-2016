package com.cg.ems.pdf;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.ems.pojo.BookingVO;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

public class PdfController extends AbstractITextPdfView{
	 @Override
	    protected void buildPdfDocument(Map<String, Object> model, Document doc,
	            PdfWriter writer, HttpServletRequest request, HttpServletResponse response)
	            throws Exception {
	        // get data model which is passed by the Spring container
	        BookingVO booking = (BookingVO) model.get("command");

	        PdfPTable pdfTable = new PdfPTable(1);
            PdfPCell cell1 = new PdfPCell(new Phrase("INVOICE"));
            cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            pdfTable.addCell(cell1);
            
            
            PdfPTable pdf = new PdfPTable(2);
            cell1 = new PdfPCell(new Phrase(""));
            cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            pdf.addCell(cell1);
            
            
            cell1 = new PdfPCell(new Phrase(""));
            cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            pdf.addCell(cell1);

            pdf.setHeaderRows(1);
            pdf.addCell("Name:");
            pdf.addCell(""+booking.getUser().getFirstName()+" "+booking.getUser().getLastName());
            pdf.addCell("Event:");
            pdf.addCell(""+booking.getEventvo().getEventName());
            pdf.addCell("Venue:");
            pdf.addCell(""+booking.getEventvo().getAddressLine()+ ", "+booking.getEventvo().getCity());
            pdf.addCell("Timing:");
            pdf.addCell(""+booking.getEventvo().getDateStart()+"::"+booking.getEventvo().getDateEnd());
            pdf.addCell("No. of tickets booked:");
            pdf.addCell(""+booking.getNoOfTickets());
            pdf.addCell("Total Amount:");
            pdf.addCell(""+booking.getTotalAmount());
            pdf.addCell("Traction id:");
            pdf.addCell(""+booking.getTransactionId());
           
         

           
	        doc.add(pdfTable);
	        doc.add(pdf);
	         
	    }
	 
	

}

