package com.cg.ems.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.ems.pojo.Event;

public interface EventRepo extends JpaRepository<Event, Integer>{

	
	public Event findEventByEventId(int eventid);
    
	
	@Query(value="select e from Event e JOIN FETCH e.address JOIN FETCH e.category JOIN FETCH e.album JOIN FETCH e.album.photoCollection  JOIN FETCH e.schedule JOIN FETCH e.contact JOIN FETCH e.tickettype JOIN FETCH e.performer where e.eventId=? and e.dateStart > now() and  (e.deleteDate=0 or e.deleteDate=null)")
	public Event searchByEventId(int eventId);
	

	
//    @Query(value="select new com.cg.demo.VO.EventVObjects(eventId,eventName,dateStart,dateEnd,status,avgRating) from Event e where e.eventId=1")
//    public EventVO findEventVOById(@Param(value="eventId") int id);

/*	@Query(value="Select AVG(r.value) from Rating r where r.eventId=? ")
	public float updateRating(int eventId);*/
	
	
	@Query(value="SELECT distinct(c.name) from com.cg.ems.pojo.Category c ")
	public List<String> listOfCategory();
	
	@Query(value="SELECT distinct(a.city) from com.cg.ems.pojo.Address a")
	public List<String> listOfCity();
	
	@Query(value="SELECT distinct(e.eventName) from Event e where e.dateStart > now() and e.status='Approved' and (e.deleteDate=0 or e.deleteDate=null)")
	public List<String> listOfEventName();
	@Query(value="SELECT Distinct p.firstName,p.lastName from Performer p")
	public List<String> listOfPerformers();
	

}
