package com.cg.ems.pojo;

import java.util.List;

public class BookingVO {
	
	private User user;
	private EventVO eventvo;
	private TicketType tickettype;
	public TicketType getTickettype() {
		return tickettype;
	}
	public void setTickettype(TicketType tickettype) {
		this.tickettype = tickettype;
	}
	//private String typename;
	private int noOfTickets;
	private int bookingId;
	private int userId;
	private int eventId;
	private int ticketId;
	private float totalAmount;
	private String transactionId;
	private String bookingStatus;
	//private int ticketPrice;
	private List<Contact> contact;
	public BookingVO(int noOfTickets, float totalAmount, String transactionId,
			String bookingStatus,int eventId,int userId,int bookingId,int ticketId) {
		super();
		//this.user = user;
	   
		this.noOfTickets = noOfTickets;
		this.totalAmount = totalAmount;
		this.transactionId = transactionId;
		this.bookingStatus = bookingStatus;
		this.eventId=eventId;
		this.bookingId=bookingId;
		this.userId=userId;
		this.ticketId=ticketId;
		
	}
	public void setUser(User user) {
		this.user = user;
	}
	public void setEventvo(EventVO eventvo) {
		this.eventvo = eventvo;
	}

	public void setContact(List<Contact> contact) {
		this.contact = contact;
	}
	
	public int getBookingId() {
		return bookingId;
	}
	public int getUserId() {
		return userId;
	}
	public int getEventId() {
		return eventId;
	}
	
	public int getTicketId() {
		return ticketId;
	}
	
	public User getUser() {
		return user;
	}
	public EventVO getEventvo() {
		return eventvo;
	}
	public int getNoOfTickets() {
		return noOfTickets;
	}
	public float getTotalAmount() {
		return totalAmount;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public String getBookingStatus() {
		return bookingStatus;
	}
	public List<Contact> getContact() {
		return contact;
	}
	@Override
	public String toString() {
		return "BookingVO [user=" + user + ", eventvo=" + eventvo
				+ ", tickettype=" + tickettype + ", noOfTickets=" + noOfTickets
				+ ", bookingId=" + bookingId + ", totalAmount=" + totalAmount
				+ ", transactionId=" + transactionId + ", bookingStatus="
				+ bookingStatus + ", contact=" + contact + "]";
	}

	
//	public BookingVO(List<Contact> contact) {
//		super();
//		this.contact = contact;
//	}
//	
//
//	public BookingVO(EventVO eventvo) {
//		super();
//		this.eventvo = eventvo;
//	}
//
//	@Override
//	public String toString() {
//		return "bookingVO [user=" + user + ", eventvo=" + eventvo
//				+ ", typename=" + typename + ", noOfTickets=" + noOfTickets
//				+ ", totalAmount=" + totalAmount + ", transactionId="
//				+ transactionId + ", bookingStatus=" + bookingStatus
//				+ ", ticketPrice=" + ticketPrice + ", contact=" + contact + "]";
//	}
	
	
	

}
