package com.cg.ems.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ems.pojo.User;
import com.cg.ems.repo.UserRepoForSigunUp;

@Service(value="userSignUpService")
public class UserServcieImplForSignUp implements UserServiceInterForSignUp {

	@Autowired
	UserRepoForSigunUp repo ;
	
	@Override
	public User register(User u) throws Exception {
		if(u.getUsername() == null)
			throw new Exception();	
		
		if(u.getFirstName()== null)
			throw new Exception();	
		
		if(u.getLastName() == null)
			throw new Exception();	
		if(u.getEmail()== null)
			throw new Exception();	
		
	
		
		User u1=repo.findByUserName(u.getUsername());
		if(u1==null){
			return repo.save(u);
			
		}else
			return null;	
	}

}
