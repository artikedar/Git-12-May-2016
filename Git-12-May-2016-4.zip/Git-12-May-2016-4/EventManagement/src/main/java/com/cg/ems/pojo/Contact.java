package com.cg.ems.pojo;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
public class Contact {
	 @Id
	 @Column(name="contact_id")
	 @GeneratedValue(strategy=GenerationType.AUTO)
	private int contactId;

	 @Column(name="contact_type")
	private String contactType;
	
	private String value;
	
	@Column(name="event_id",insertable=false,updatable=false)
	private int eventid;	
	
	public int getEventid() {
		return eventid;
	}
	public void setEventid(int eventid) {
		this.eventid = eventid;
	}
	public int getContactId() {
		return contactId;
	}
	public void setContactId(int contactId) {
		this.contactId = contactId;
	}
	public String getContactType() {
		return contactType;
	}
	public void setContactType(String contactType) {
		this.contactType = contactType;
	}
	
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	@Override
	public String toString() {
		return "Contact [contactId=" + contactId + ", contactType="
				+ contactType + ", value=" + value + "Eeventid"+eventid+"]";
	}
	
	
	

	
}
