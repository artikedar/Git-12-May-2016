import java.util.LinkedList;
import java.util.List;

public class LinkedListDemo {
	public static void main(String args[]){
		
		LinkedList<Integer> lst=new LinkedList<>();
		
		lst.add(12);
		lst.add(40);
		lst.add(60);
		lst.add(80);
		lst.add(90);
		
		System.out.println(lst);
		lst.removeFirst();
		System.out.println(lst);
		lst.addFirst(45);
		System.out.println(lst);
		lst.addLast(600);
		System.out.println(lst);
		System.out.println(lst.getFirst());
		System.out.println(lst.getLast());
		lst.offer(798);
		System.out.println(lst);
		lst.offerFirst(12344);
		System.out.println(lst);
		lst.offerLast(56789);
		System.out.println(lst);
		System.out.println(lst.peek());
		System.out.println(lst.peekFirst());
		System.out.println(lst.peekLast());
		lst.poll();
		System.out.println(lst);
		lst.pollFirst();
		System.out.println(lst);
		lst.pollLast();
		System.out.println(lst);
		System.out.println(lst.pop());
		System.out.println(lst);
		lst.push(12);
		System.out.println(lst);
		lst.add(90);
		System.out.println(lst);
		lst.removeFirstOccurrence(90);
		System.out.println(lst);
		lst.add(90);
		System.out.println(lst);
		lst.removeLastOccurrence(90);
		lst.remove();
		System.out.println(lst);
	
		
		
	
		
	}
}
