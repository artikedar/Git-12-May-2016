import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import java.util.ListIterator;

public class MethodsDemo {
	public static void main(String[] args){
		List<String> mylst=new ArrayList<String>();
		List<Integer> mylst1=new ArrayList<Integer>();
		List<String> mylst2=new ArrayList<String>();
		
		mylst.add("arti");
		mylst.add("kedar");
		mylst.add("vijay");
		mylst.add("vikas");
		mylst.add("jerry");
		mylst.add("tom");
		
		mylst2.add("hemant");
		mylst2.add("kedar");
		mylst2.add("vikram");
		mylst2.add("rashmi");
		mylst2.add("jerry");
		mylst2.add("tom");
		
		System.out.println("Size is: "+mylst.size());
		System.out.println("Element at index 3 is: "+mylst.get(3));
		System.out.println("Is the list empty: "+mylst.isEmpty());
		System.out.println("Is the list contains vikas? "+mylst.contains("vikas"));
		System.out.println(mylst.addAll(mylst));
		System.out.println(mylst);
		Iterator<String> itr=mylst.iterator();
		while(itr.hasNext()){
			String str=itr.next();
			if(str.equals("vijay")){
				itr.remove();
			}
		}
		System.out.println(mylst);
		System.out.println(mylst.addAll(mylst2));
		mylst.add("george");
		System.out.println(mylst);
		mylst.clear();
		System.out.println(mylst);
		mylst.add("arti");
		mylst.add("kedar");
		mylst.add("vijay");
		mylst.add("vikas");
		mylst.add("jerry");
		mylst.add("tom");
		System.out.println(mylst);
		mylst.containsAll(mylst2);
		System.out.println(mylst.containsAll(mylst2));
		System.out.println(mylst.indexOf("arti"));
		System.out.println(mylst.lastIndexOf("jerry"));
		System.out.println(mylst.listIterator());
		mylst.listIterator();
		mylst.remove(1);
		System.out.println(mylst);
		System.out.println(mylst.removeAll(mylst));
		System.out.println(mylst.retainAll(mylst2));
		mylst.add("arti");
		mylst.add("kedar");
		mylst.add("vijay");
		mylst.add("vikas");
		mylst.add("jerry");
		mylst.add("tom");
		System.out.println(mylst);
		mylst.set(0,"kedar");
		System.out.println(mylst);
		System.out.println(mylst.subList(0, 3));
		mylst.toArray();
		System.out.println(mylst);
		
	}
}
