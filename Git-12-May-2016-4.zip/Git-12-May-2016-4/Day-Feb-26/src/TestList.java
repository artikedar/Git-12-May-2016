import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class TestList {
	public static void main(String[] args){
		List<String> mylst=new ArrayList<String>();
		List<Integer> mylst1=new ArrayList<Integer>();
		
		mylst.add("arti");
		mylst.add("kedar");
		mylst.add("vijay");
		mylst.add("vikas");
		mylst.add("jerry");
		mylst.add("tom");

		
		/*for(String str:mylst){
			System.out.println(str);
		}*/
		
		mylst1.add(1234);
		mylst1.add(5678);
		mylst1.add(15);
		mylst1.add(100);
		mylst1.add(2000);
		mylst1.add(5698);
		mylst1.add(0000);
		
		/*for(Integer str1:mylst1){
			System.out.println(str1);
		}*/
		
		
		/*Iterator<String> itr=mylst.iterator();
			while(itr.hasNext()){
				String str=itr.next();
				if(str.equals("vijay"))
					itr.remove();
				System.out.println(str);
			}
			System.out.println(mylst);*/
			
		/*Iterator<Integer> itr1=mylst1.iterator();
		while(itr1.hasNext()){
			System.out.println(itr1.next());
		}*/
			
		ListIterator<String> litr=mylst.listIterator();
			while (litr.hasNext()){
				System.out.print(litr.next()+"--->");	
				}
			while (litr.hasPrevious()){
				System.out.print(litr.previous()+"--->");	
				}
			
			
			/*ListIterator<Integer> litr1=mylst1.listIterator();
			while (litr1.hasNext()){
				System.out.print(litr1.next()+"--->");*/
				
			
	}
}
