import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;
import java.util.TreeSet;

public class Test {

	public static void main(String[] args) {
		List lst=new ArrayList();
		
		lst.add("Pune");
		lst.add("Chennai");
		lst.add("Hyderabad");
		lst.add("Mumbai");
		lst.add("Banglore");
		lst.add(1);
		lst.add(3.14f);
		
		
		ListIterator it=lst.listIterator();
		it.next();
		it.previous();
		it.hasPrevious();
		it.next();
		it.next();
		it.previous();
		it.next();
		it.previous();
	
		
		System.out.println(it.next());
	}
	
}
