
public class MainClass {

	public static void main(String[] args){
		SynchronizationDemo temp=new SynchronizationDemo();
		
		Thread t1=new Thread(){
			public void run(){
				
				temp.printString("capgemini");
			}
		};
		
		Thread t2=new Thread(){
			public void run(){
				
				temp.printString("welcome");
			}
		};
		
		t1.start();
		t2.start();
		
		
		}
	}
	

