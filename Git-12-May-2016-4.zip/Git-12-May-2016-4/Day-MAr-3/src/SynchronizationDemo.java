
public class SynchronizationDemo {

	public synchronized void printString(String str){
		for(int i=0;i<=str.length();i++){
			System.out.println(str.substring(0, i));
		}
		
		
	}
}
