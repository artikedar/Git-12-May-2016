package org.capgemini.demo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class login
 */
public class login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		String userName=request.getParameter("uname");
		String password=request.getParameter("upwd");
		out.println("UserName: "+ userName+"<br>");
		out.println("Password: "+ password+ "<br>");
		
		/*if(userName.equals("arti")&&password.equals("1234")){
			response.sendRedirect("pages/success.html");
		}
		else
			response.sendRedirect("pages/login");
			
		*/
		//JDBC
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Class loaded");
			//Make a Connection
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "Pass1234");
			//Create Statement
			Statement stat=con.createStatement();
			//Execute Query
			ResultSet rs=stat.executeQuery("SELECT * FROM user_details");
			//Process The Result
			while(rs.next()){
				
				if((userName.equals(rs.getString(1)))&&(password.equals(rs.getString(2)))){
				/*System.out.println(rs.getString(1));
				System.out.println(rs.getString(2));*/
				response.sendRedirect("pages/success.html");
				}
				else
					response.sendRedirect("pages/index.html");
			}
			con.close();
			
		} catch (ClassNotFoundException e  ) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (SQLException e ) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
	}

}
