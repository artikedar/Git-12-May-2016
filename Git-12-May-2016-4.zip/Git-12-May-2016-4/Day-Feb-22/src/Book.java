
public class Book {
	
	private String publisherName;
	private String publishingDate;
	public Book(){};
	public Book(String publisherName,String publishingDate){ //Constructor
		super();
		this.publisherName=publisherName;
		this.publishingDate=publishingDate;
	}
	
		public String getPublisherName() {
		return publisherName;
	}
	public void setPublisherName(String publisherName) {
		this.publisherName = publisherName;
	}
	public String getPublishingDate() {
		return publishingDate;
	}
	public void setPublishingDate(String publishingDate) {
		this.publishingDate = publishingDate;
	}
	public static void main(String[] args){
		@Publisher(publisherName="Arti",publishingDate="22-Feb-2016")
		Book book=new Book("Tata Publisher","29-Feb-2016");
		System.out.println(book.publisherName + book.publishingDate);
	}
		
}
