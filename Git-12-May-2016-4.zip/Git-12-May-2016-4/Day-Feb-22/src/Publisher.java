import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.Date;


@Documented
@Target({ElementType.LOCAL_VARIABLE,ElementType.FIELD,ElementType.METHOD})//at what place 
@Retention(RetentionPolicy.RUNTIME)//at what time
public @interface Publisher {
	
	String publisherName() default "Arti";
	String publishingDate() default "22-Feb-2016";
	
}
