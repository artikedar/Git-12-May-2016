
public class Demo {

	public static void main(String args[]) {
		try{
		
		if(args.length==2){
			int num1=Integer.parseInt(args[2]);
			int num2=Integer.parseInt(args[1]);
			int ans=num1/num2;
			System.out.println(ans);
		}
		}catch(NumberFormatException|ArithmeticException|ArrayIndexOutOfBoundsException ex){
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}catch (Exception e){
			System.out.println(e.getMessage());
		}
		
		System.out.println("Program Completed");
	}

}
