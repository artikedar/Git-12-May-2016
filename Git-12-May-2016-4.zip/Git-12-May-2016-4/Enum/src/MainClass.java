
public class MainClass {
	public static void main(String[] args){
		Customer customer=new Customer();
		customer.getCustomerDetails();
		customer.chooseCustomerType();
		customer.printCustomerDetails();
		
	}
}
