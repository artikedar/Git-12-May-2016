import java.util.Scanner;

public class Customer {
	public int custId;
	public String custName;
	private CustomerType CustomerType;
	CustomerType ct=CustomerType;
	

	
	public void getCustomerDetails(){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Customer Id: ");
		custId=sc.nextInt();
		System.out.println("Enter Customer Name: ");
		custName=sc.next();
			
	}
	public void chooseCustomerType(){
		Scanner sc=new Scanner(System.in);
		System.out.println("1.Silver");
		System.out.println("2.Gold");
		System.out.println("3.Diamond");
		System.out.println("4.Platinum");
		System.out.println("Enter Your choice");
		int choice=sc.nextInt();
		
		switch(choice){
		case 1:
			ct=CustomerType.SILVER;
			break;
		case 2:
			ct=CustomerType.GOLD;
			break;
		case 3:
			ct=CustomerType.DIAMOND;
			break;
		case 4:
			ct=CustomerType.PLATINUM;
			break;
		}
	}
	
	public void printCustomerDetails(){
		System.out.println("Customer Id \tCustomer Name \tCustomer Type ");
		System.out.println(custId+"\t"+custName+"\t"+ct+"\t"+ct.getMinValue()+"-"+ct.getMaxValue());
	}

}
