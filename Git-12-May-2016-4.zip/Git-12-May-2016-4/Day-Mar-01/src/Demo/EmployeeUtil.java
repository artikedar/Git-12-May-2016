package Demo;

public class EmployeeUtil <T extends Employee>{
	private T empobj;

	
	public T getEmpobj() {
		return empobj;
	}
	
	public void printClass(){
		System.out.println(empobj.getClass().getName());
		}
	
	public void compareSalary(Employee emo){
		if(empobj.getSalary()==emp.getSalary)
			System.out.println("Equal");
		else
			System.out.println("Unequal");
		
	}

	
	
	
	

}
