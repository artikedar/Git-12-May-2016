package Demo;

public class CTSEmployee extends Employee{
	public CTSEmployee(){
		super();
	}
	

}
