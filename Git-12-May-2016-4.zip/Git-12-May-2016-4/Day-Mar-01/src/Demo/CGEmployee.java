package Demo;

public class CGEmployee extends Employee{
	public CGEmployee(){
		super();
	}
	

}
