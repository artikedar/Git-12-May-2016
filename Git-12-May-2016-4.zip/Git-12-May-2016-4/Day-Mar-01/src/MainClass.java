
public class MainClass {

	public static void main(String[] args) {
		Circle<Integer,String> circle=new Circle<Integer,String>(23,"Tom");
		circle.showInfo();

	}

}
