
public class MyThread extends Thread{

	static int i=0;
	public synchronized void run(){
		for(;i<10;i++){
		
			System.out.println("i= "+i+"---->"+this.getName());
			
		}
	}
	
}
