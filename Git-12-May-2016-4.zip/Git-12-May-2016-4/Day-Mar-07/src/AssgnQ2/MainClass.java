package AssgnQ2;


public class MainClass {

	public static void main(String[] args) {
		ThreadDemo t1=new ThreadDemo(1);
		ThreadDemo t2=new ThreadDemo(0);
		
		
		t1.start();
		t2.start();
	
		
	}

}
