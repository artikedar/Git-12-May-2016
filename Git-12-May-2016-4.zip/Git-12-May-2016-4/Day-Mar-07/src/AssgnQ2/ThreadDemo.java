package AssgnQ2;

public class ThreadDemo extends Thread{
	static Object lock = new Object();
    static int n;
    int even;
    
   ThreadDemo(int r) {
        this.even = r;
    }
	public synchronized void run(){
		 try {
	            synchronized (lock) {
	                for (;;) {
	                	System.out.println((n & 1));
	                    while ((n & 1) != even) {
	                        lock.wait();
	                    }
	                    n++;
	                    lock.notify();
	                    if (n > 10) {
	                        break;
	                    }
	                    System.out.println(n+" Printed By "+this.getName());
	                }
	            }
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
	    }
}
