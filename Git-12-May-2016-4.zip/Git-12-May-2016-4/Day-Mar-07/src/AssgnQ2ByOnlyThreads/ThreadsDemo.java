package AssgnQ2ByOnlyThreads;

public class ThreadsDemo extends Thread{

	static int i=0;
	public void run(){
		for(;i<10;i++){
		synchronized(ThreadsDemo.class){
		
				System.out.println(i+" Printed By "+this.getName());
			}
		}
	}
}
