package AssgnQ2ByOnlyThreads;

public class MainClass {

	public static void main(String[] args) {
		ThreadsDemo t1=new ThreadsDemo();
		ThreadsDemo t2=new ThreadsDemo();
		ThreadsDemo t3=new ThreadsDemo();
		ThreadsDemo t4=new ThreadsDemo();
		
		t1.start();
		t2.start();
		t3.start();
		t4.start();

	}

}
