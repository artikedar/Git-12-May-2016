package AssgnQ2ByJoin;

public class ThreadDemo2 extends Thread{
	static int num;
	
	public synchronized void run(){
		for(int i=0;i<6;i++){
			System.out.println((num++)+" Printed By "+this.getName());
			//num++;
			try{
				Thread.sleep(500);
			}catch(Exception e){
				System.out.println(e);
			
			}
		}
	}
	

}
