package AssgnQ2ByJoin;

public class MainClass {
	
	public static void main(String[] args){
		ThreadDemo2 t1=new ThreadDemo2();
		ThreadDemo2 t2=new ThreadDemo2();
		
		t1.start();
		t2.start();
		
		try{
			t1.join();
			t2.join();
		}catch(Exception e){
			System.out.println(e);
		}
	}
	
	
	

}
