
public class ValidationEmp{
	
	public static boolean isValidSalary(double salary) throws InvalidSalaryException{
	
			if(salary>=2000||salary<=50000){
				return(true);
			}
			else{
				throw new InvalidSalaryException("Invalid Salary");	
			}
			
		
	}
		
	}


