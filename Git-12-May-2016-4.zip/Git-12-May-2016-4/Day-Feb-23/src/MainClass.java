import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		Double salary=0.0;
		Scanner sc=new Scanner(System.in);
		Employee emp=new Employee();
		System.out.println("Enter Employee Id: ");
		int eid=sc.nextInt();
		emp.setEmpId(eid);
		System.out.println("Enter Employee Name: ");
		String empName=sc.next();
		emp.setFirstName(empName);
		System.out.println("Enter Salary: ");
		salary=sc.nextDouble();
		boolean flag=false;
		try {
			flag=ValidationEmp.isValidSalary(salary);
		} catch (InvalidSalaryException e) {
			
			e.printStackTrace();
		}
		
			emp.setSalary(salary);	
		
		
		
		
		

	}

}
