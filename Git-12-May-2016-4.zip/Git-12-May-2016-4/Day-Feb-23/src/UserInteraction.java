import java.util.Scanner;

public class UserInteraction {
		
	public Account getAccDetails(){
		int accId;
		String accName;
		String openDate;
		String city;
		String state;
		String pinCode;
		String balance;
		int doorNo;
		String stName;
		boolean flag;
		Account acc=new Account();
		Scanner sc=new Scanner(System.in);
		
		do{
		System.out.println("Enter Account No: ");
		accId=sc.nextInt();
		String s=Integer.toString(accId);
		flag=Validation.isValidAccId(s);
		if (!flag)
			System.out.println("Invalid Account No. Please Enter Valid Account No");
		else
			System.out.println("Valid Account No");
		}while(!flag);
		
		do{
			System.out.println("Enter Account Name: ");
			accName=sc.next();
			flag=Validation.isValidAccName(accName);
			if (!flag)
				System.out.println("Invalid Account Name. Please Enter Valid Account Name");
			else
				System.out.println("Valid Account Name");
			}while(!flag);
		
		do{
			System.out.println("Enter Open Date: ");
			openDate=sc.next();
			flag=Validation.isValidOpenDate(openDate);
			if (!flag)
				System.out.println("Invalid Open Date. Please Enter Valid Open Date");
			else
				System.out.println("Valid Open Date");
			}while(!flag);
		
		do{
			System.out.println("Enter Account Balance: ");
			balance=sc.next();
			flag=Validation.isValidBalance(balance);
			if (!flag)
				System.out.println("Invalid Account Balance. Please Enter Valid Account Balance");
			else
				System.out.println("Valid Account Balance");
			}while(!flag);
		
		do{
			System.out.println("Enter Door No. : ");
			doorNo=sc.nextInt();
			String s2=Integer.toString(doorNo);
			flag=Validation.isValidS2(s2);
			if (!flag)
				System.out.println("Invalid Door No. Please Enter Valid Door No.");
			else
				System.out.println("Valid Door No.");
			}while(!flag);
		
		do{
			System.out.println("Enter Street Name: ");
			stName=sc.next();
			flag=Validation.isValidStName(stName);
			if (!flag)
				System.out.println("Invalid Street Name. Please Enter Valid Street Name");
			else
				System.out.println("Valid street Name");
			}while(!flag);
		
		do{
			System.out.println("Enter City: ");
			city=sc.next();
			flag=Validation.isValidCity(city);
			if (!flag)
				System.out.println("Invalid City. Please Enter Valid City");
			else
				System.out.println("Valid City");
			}while(!flag);
		
		do{
			System.out.println("Enter State: ");
			state=sc.next();
			flag=Validation.isValidState(state);
			if (!flag)
				System.out.println("Invalid State. Please Enter Valid State");
			else
				System.out.println("Valid State");
			}while(!flag);
		
		do{
			System.out.println("Enter Pin Code: ");
			pinCode=sc.next();
			flag=Validation.isValidPinCode(pinCode);
			if (!flag)
				System.out.println("Invalid Pin Code. Please Enter Valid Pin Code");
			else
				System.out.println("Valid Pin Code");
			}while(!flag);
		
		
			return acc;
		}
}
