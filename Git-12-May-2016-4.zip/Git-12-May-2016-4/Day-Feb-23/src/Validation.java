
public class Validation {
	
	public static boolean isValidAccId(String s){
	return s.matches("\\d{15}");
	}
	
	public static boolean isValidAccName(String accName){
	return accName.matches("\\d[a-z|A-Z]");
	}
	
	public static boolean isValidOpenDate(String openDate){
	return openDate.matches("[0123]\\d{1}-(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)-[12][890]\\d{2}");
	}
	
	public static boolean isValidBalance(String balance){
	return balance.matches("\\d[^0-4|0-4|0-4]");
	}
	
	public static boolean isValidS2(String s2){
	return s2.matches("\\d{3}");
	}
	
	public static boolean isValidStName(String stName){
	return stName.matches("\\w+{a-z|A-Z}");
	}
	
	public static boolean isValidCity(String city){
	return city.matches("[A-Z]\\w+{a-z}");
	}
	
	public static boolean isValidState(String state){
	return state.matches("[A-Z]\\w+{a-z}");
	}
	
	public static boolean isValidPinCode(String pinCode){ 
	return pinCode.matches("\\d{6}");
	}
}