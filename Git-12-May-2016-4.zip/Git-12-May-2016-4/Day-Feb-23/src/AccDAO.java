
public class AccDAO {
	Account acc=new Account();

	public static Account saveAccount(Account acc){
		String a[] = null;
		for(int i=0;i<a.length;i++){
			a[i]=
		}
		
		return acc;
		

	}
	
	

}
