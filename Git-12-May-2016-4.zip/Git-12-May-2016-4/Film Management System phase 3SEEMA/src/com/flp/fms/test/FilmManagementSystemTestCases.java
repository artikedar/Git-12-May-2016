package com.flp.fms.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Test;

import com.flp.fms.dao.FilmDaoImplForDatabase;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;

public class FilmManagementSystemTestCases {

	ActorServiceImpl actorservice= new ActorServiceImpl();
	FilmServiceImpl filmservice=new FilmServiceImpl();
	FilmDaoImplForDatabase filmDao=new FilmDaoImplForDatabase();
	/*@Test
	public void testGetLanguages() {
		
		List<Language> languages=new ArrayList<>();
		languages.add(new Language(1, "Marathi"));
		languages.add(new Language(2, "Hindi"));
		languages.add(new Language(3, "English"));
		languages.add(new Language(4, "Corien"));
		languages.add(new Language(5, "Japanis"));
		languages.add(new Language(6, "Telgu"));
		languages.add(new Language(7, "French"));
		//languages.add(new Language(8, "German"));
		List<Language> language=filmDao.getLanguages();
		assertEquals(languages, language);
		
	}
	
	@Test
	public void testGetLanguagesIfNotSame() {
		
		List<Language> languages1=new ArrayList<>();
		languages1.add(new Language(1, "Marathi"));
		languages1.add(new Language(2, "Hindi"));
		languages1.add(new Language(3, "English"));
		languages1.add(new Language(4, "Corien"));
		languages1.add(new Language(5, "Japanis"));
		languages1.add(new Language(6, "Telgu"));
		languages1.add(new Language(7, "French"));
		languages1.add(new Language(8, "German"));
		List<Language> languages=filmDao.getLanguages();
		assertNotEquals(languages1, languages);
		
	}
	
	

	@Test
	public void testGetActors(){
		
		
		Set<Actor> actors=new HashSet<>();
		Actor actor=new Actor(1,"ShahRukh", "Khan");
		Actor actor1=new Actor(2,"Salman", "Khan");
		Actor actor2=new Actor(3,"Deepika", "Padukon");
		Actor actor3=new Actor(4,"Katrina", "Kapoor");
		Actor actor4=new Actor(5,"Priynka", "Chopra");
		Actor actor5=new Actor(6,"Ranbir", "Singh");
		Actor actor6=new Actor(7,"Ranvir", "Kapoor");
		Actor actor7=new Actor(8,"Kajol", "Devgan");
		
		
		actors.add(actor);
		actors.add(actor1);
		actors.add(actor2);
		actors.add(actor3);
		actors.add(actor4);
		actors.add(actor5);
		actors.add(actor6);
		actors.add(actor7);
		
		
		assertEquals(actors, actorservice.getActors());
	}
	
	@Test
	public void testGetActorsIfNotSame(){
		
		
		Set<Actor> actors=new HashSet<>();
		Actor actor=new Actor(1,"ShahRukh", "Khan");
		Actor actor1=new Actor(2,"Salman", "Khan");
		Actor actor2=new Actor(3,"Deepika", "Padukon");
		Actor actor3=new Actor(4,"Katrina", "Kapoor");
		Actor actor4=new Actor(5,"Priynka", "Chopra");
		Actor actor5=new Actor(6,"Ranbir", "Singh");
		actors.add(actor);
		actors.add(actor1);
		actors.add(actor2);
		actors.add(actor3);
		actors.add(actor4);
		actors.add(actor5);
		
		assertNotEquals(actors, actorservice.getActors());
	}
	
	@Test
	public void testActorObjectNull(){
		
		Actor actor=null;
		assertEquals(actor,null);
		
	}
	
	@Test
	public void testGetCategorys(){
		
		List<Category> category=new ArrayList<>();
		category.add(new Category(1,"Action"));
		category.add(new Category(2,"Animation"));
		category.add(new Category(3,"Cartoon"));
		category.add(new Category(4,"Classic"));
		category.add(new Category(5,"Comedy"));
		category.add(new Category(6,"Documentry"));
		category.add(new Category(7,"Drama"));
		category.add(new Category(8,"Family"));
		category.add(new Category(9,"Games"));
		category.add(new Category(10,"Horror"));
		category.add(new Category(11,"Sci-Fi"));
		category.add(new Category(12,"Sports"));
		assertEquals(category, filmservice.getCategory());
		
	}
	
	@Test
	public void testGetCategorysIfNotSame(){
		
		List<Category> category=new ArrayList<>();
		category.add(new Category(1,"Action"));
		category.add(new Category(2,"Animation"));
		category.add(new Category(3,"Cartoon"));
		category.add(new Category(4,"Classic"));
		category.add(new Category(5,"Comedy"));
		category.add(new Category(6,"Documentry"));
		category.add(new Category(7,"Drama"));
		category.add(new Category(8,"Family"));
		category.add(new Category(9,"Games"));
		category.add(new Category(10,"Horror"));
		category.add(new Category(11,"Sci-Fi"));
		category.add(new Category(12,"Sports"));
		category.add(new Category(13,"Romantic"));
		assertNotEquals(category, filmservice.getCategory());
		
	}
	
	@Test
	public void testForAddFilm(){
		Film film=new Film();
		film.setTitle("Kung Fu Panda");
		film.setDescription("Cartoo");
		Date release_Year=new Date("23-Apr-2013");
		film.setRelease_Year(release_Year);
		
		Language lang=new Language();
    	lang.setLanguage_Id(1);
		film.setOriginal_Langauges(lang);
		
		Date d1=new Date("13-apr-2017");
		film.setRental_Duration(d1);
		film.setLength(11);
		film.setReplacement_Cost(1111);
		film.setRating(2);
		film.setSpecial_Features("asdfg");
		
		Category category=new Category();
		category.setCategory_Id(1);
		film.setCategory(category);
		
		List<Language> langs=new ArrayList<>();
		Language lang1=new Language();
		lang1.setLanguage_Id(2);
		langs.add(lang);
    	langs.add(lang1);
		film.setLanguages(langs);
	
		Set<Actor> actors=new HashSet<>();
		Actor actor1=new Actor();
		actor1.setActor_Id(1);
		Actor actor2=new Actor();
    	actor2.setActor_Id(2);
		actors.add(actor1);
		actors.add(actor2);
    	film.setActors(actors);
		assertEquals(film,filmDao.addFilm(film));
		
		
		
		
	}*/
	
/*	@Test
	public void testForAddActor(){
		
		Actor actor=new Actor();
		actor.setActor_First_Name("Amitabh");
		actor.setActor_Last_Name("Bacchan");
		assertEquals(1,actorservice.addActor(actor));
		
	}*/
	@Test
	public void testForSearchActorNotSame(){
		
		Actor actor=new Actor();
		actor.setActor_First_Name("Amitabh");
		actor.setActor_Last_Name("Bacchan");
		assertNotEquals(actor,actorservice.searchActorByID(8));
		
	}
	
	
	
	public void testForSearchActor(){
		
		Actor actor=new Actor();
		actor.setActor_First_Name("Shahrukh");
		actor.setActor_Last_Name("Khan");
		assertNotEquals(actor,actorservice.searchActorByID(1));
		
	}
	
	
	/*
	@Test
	public void testForDeleteActor(){
		
		assertEquals(1,actorservice.removeActor(8) );
		
	}
	
	@Test
	public void testForDeleteFilm(){
		
		Film film=new Film();
		film.setTitle("Kung Fu Panda");
		film.setDescription("Cartoo");
		Date release_Year=new Date("23-Apr-2013");
		film.setRelease_Year(release_Year);
		
		Language lang=new Language();
    	lang.setLanguage_Id(1);
		film.setOriginal_Langauges(lang);
		
		Date d1=new Date("13-apr-2017");
		film.setRental_Duration(d1);
		film.setLength(11);
		film.setReplacement_Cost(1111);
		film.setRating(2);
		film.setSpecial_Features("asdfg");
		
		Category category=new Category();
		category.setCategory_Id(1);
		film.setCategory(category);
		
		List<Language> langs=new ArrayList<>();
		Language lang1=new Language();
		lang1.setLanguage_Id(2);
		langs.add(lang);
    	langs.add(lang1);
		film.setLanguages(langs);
	
		Set<Actor> actors=new HashSet<>();
		Actor actor1=new Actor();
		actor1.setActor_Id(1);
		Actor actor2=new Actor();
    	actor2.setActor_Id(2);
		actors.add(actor1);
		actors.add(actor2);
    	film.setActors(actors);
		assertEquals(2,filmDao.removeFilm(9));
		
		
	}*/
	
	
	/*@Test
	public void testForSearchFilm(){
		List<Film> filmList=new ArrayList<>();
		Film film=new Film();
		film.setFilmId(3);
		film.setTitle("Kung Fu Panda");
		film.setDescription("Cartoo");
		Date release_Year=new Date("23-Apr-2013");
		film.setRelease_Year(release_Year);
		
		Language lang=new Language();
    	lang.setLanguage_Id(1);
		film.setOriginal_Langauges(lang);
		
		Date d1=new Date("13-apr-2017");
		film.setRental_Duration(d1);
		film.setLength(11);
		film.setReplacement_Cost(1111);
		film.setRating(2);
		film.setSpecial_Features("asdfg");
		
		Category category=new Category();
		category.setCategory_Id(1);
		film.setCategory(category);
		
		List<Language> langs=new ArrayList<>();
		Language lang1=new Language();
		lang1.setLanguage_Id(2);
		langs.add(lang);
    	langs.add(lang1);
		film.setLanguages(langs);
	
		Set<Actor> actors=new HashSet<>();
		Actor actor1=new Actor();
		actor1.setActor_Id(1);
		Actor actor2=new Actor();
    	actor2.setActor_Id(2);
		actors.add(actor1);
		actors.add(actor2);
    	film.setActors(actors);
		 filmList.add(film);
		 assertEquals(filmList, filmservice.searchFilm(film));
	}
	
	
	
	@Test
	public void testForUpdateFilm(){
		
		List<Film> filmList=new ArrayList<>();
		Film film=new Film();
		film.setFilmId(3);
		film.setTitle("Kung Fu Panda3");
		film.setDescription("Cartoon");
		Date release_Year=new Date("23-Apr-2013");
		film.setRelease_Year(release_Year);
		
		Language lang=new Language();
    	lang.setLanguage_Id(1);
		film.setOriginal_Langauges(lang);
		
		Date d1=new Date("13-apr-2017");
		film.setRental_Duration(d1);
		film.setLength(11);
		film.setReplacement_Cost(1341);
		film.setRating(2);
		film.setSpecial_Features("asdfg");
		
		Category category=new Category();
		category.setCategory_Id(1);
		film.setCategory(category);
		
		List<Language> langs=new ArrayList<>();
		Language lang1=new Language();
		lang1.setLanguage_Id(2);
		langs.add(lang);
    	langs.add(lang1);
		film.setLanguages(langs);
	
		Set<Actor> actors=new HashSet<>();
		Actor actor1=new Actor();
		actor1.setActor_Id(1);
		Actor actor2=new Actor();
    	actor2.setActor_Id(2);
		actors.add(actor1);
		actors.add(actor2);
    	film.setActors(actors);
		
		assertEquals(1, filmservice.updateFilm(3,film));
		
		
	}*/
	
	/*@Test
	public void testForFilmObjectIsNull()
	{
		Film film=null;
		assertNull(film);
		
	}*/
	
	

	
	
	
	
}
