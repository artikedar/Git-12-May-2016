package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.service.ActorServiceImpl;


public class UpdateActorServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		int actorId=Integer.parseInt(request.getParameter("id"));
		System.out.println(actorId);
		ActorServiceImpl actorService=new ActorServiceImpl();
		Actor actor=actorService.searchActorByID(actorId);
		
		
		out.print("<html>");
		out.print("<head>");
		out.print("<script type='text/javascript' src='scripts/validate.js'></script>"
				+ " <link rel='stylesheet' type='text/css' href='css/mystyles.css'>");
		out.print("</head>");
		
		out.print("<body>");
		out.print("<form name='actor' method='post' action='ModifyActorServlet2'>");
		out.print("<h1 align='center'>Fill The Details of Actor</h1>");
		out.println("<center> "
				+ "<table>"
				+ "<tr>"
				+ "<td><label>First Name</label></td>"
				+ "<td>:</td>"
				+ "<td><input type='text' name='aFName' onmouseout='return validateDetails()' value='"+actor.getActor_First_Name()+"'>"
				+ "<div id='fNameErr'></div>"
				+ "</td>"
				+ "</tr>");
		out.println("<tr>"
				+ "<td><label>Last Name</label></td>"
				+ "<td>:</td>"
				+ "<td><input type='text' name='aLName' onmouseout='return validateDetails()' value='"+actor.getActor_Last_Name()+"'>"
				+ "<div id='lNameErr'></div>"
				+ "</td>"
				+ "</tr>"
				+ " <tr><td><input type='hidden' name='actor_id' value='"+actorId+"'");
		
		out.print("<tr><td></td>"
				+ "<td><input type='submit' value='Submit'</td>"
				+ "</tr>");
				
		out.print("</table>"
				+ "</center>"
				+ "</body>"
				+ "</html");
		
	}

}
