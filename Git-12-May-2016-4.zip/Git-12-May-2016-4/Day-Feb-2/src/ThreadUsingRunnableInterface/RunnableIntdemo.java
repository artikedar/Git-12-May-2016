package ThreadUsingRunnableInterface;

import java.util.Scanner;

public class RunnableIntdemo implements Runnable{
	private int num;
	private int ans;
	
	
	public RunnableIntdemo(int num){
		super();
		this.num = num;
	}

	public void printTable(){
	
		for(int i=1;i<=num;i++)
		{
			ans=i*num;
			System.out.println(i+"*"+num+"="+ans);
		}
		
	}
	
	@Override
	public void run() {
		
		printTable();
		
	}
	
	
	
}
