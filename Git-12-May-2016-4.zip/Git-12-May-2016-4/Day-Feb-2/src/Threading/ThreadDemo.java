package Threading;

public class ThreadDemo extends Thread{
	private String str;
	//private String str2;
	
	
	
	public ThreadDemo(String str) {
		super();
		this.str = str;
	}



	@Override
	public void run() {
		for(int i=0;i<=str.length();i++){
			System.out.println(str.substring(0,i));
		}
		
	}
	

}
