package Threading;

public class MainClass {
	public static void main(String[] args){
		
		ThreadDemo t1=new ThreadDemo("capgemini");
		
		t1.start();
		
		
		
	}
}
