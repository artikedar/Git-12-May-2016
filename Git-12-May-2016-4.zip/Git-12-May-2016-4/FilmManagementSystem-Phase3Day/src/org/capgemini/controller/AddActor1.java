package org.capgemini.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.PrintWriter;

/**
 * Servlet implementation class AddActor1
 */
public class AddActor1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		
		
		out.print("<html>");
		out.print("<head>");
		out.print("<script type='text/javascript' src='scripts/validate.js'></script>"
				+ " <link rel='stylesheet' type='text/css' href='css/MyStyle.css'>");
		out.print("</head>");
		
		out.print("<body>");
		out.print("<form name='actor' method='post' action='AddActor_2'>");
		
		out.println("<center> "
				+ "<table>"
				+"<th>Create New Actor</th> "
				+ "<tr>"
				+ "<td><label>First Name</label></td>"
				+ "<td><input type='text' name='ActorFirstname' onmouseout='return validateDetails()'>"
				+ "<div id='fNameErr'></div>"
				+ "</td>"
				+ "</tr>");
		out.println("<tr>"
				+ "<td><label>Last Name</label></td>"
				+ "<td><input type='text' name='ActorLastName' onmouseout='return validateDetails()'>"
				+ "<div id='lNameErr'></div>"
				+ "</td>"
				+ "</tr>");
		
		out.print("<tr><td></td>"
				+ "<td><input type='submit' value='Submit'</td>"
				+ "</tr>");
				
		out.print("</table>"
				+ "</center>"
				+ "</body>"
				+ "</html");
	}

}
