package org.capgemini.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.PrintWriter;

/**
 * Servlet implementation class AddActor1
 */
public class AddActor1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		
		//Display the Form to Create New Actor 
		out.println("<html>");
		out.print("<body>");
		out.print("<form name='actor' method='post' action='AddActor_2'>");
		
		out.println( "<table>"
				+"<tr><b>Create New Actor</b></tr> "
				+ "<tr>"
				+ "<td><label>First Name</label></td>"
				+ "<td><input type='text' name='ActorFirstname' onmouseout='return validateDetails()'>"
				+ "<div id='fNameErr'></div>"
				+ "</td>"
				+ "</tr>");
		out.println("<tr>"
				+ "<td><label>Last Name</label></td>"
				+ "<td><input type='text' name='ActorLastName' onmouseout='return validateDetails()'>"
				+ "<div id='lNameErr'></div>"
				+ "</td>"
				+ "</tr>");
		
		out.print("<tr><td></td>"
				+ "<td><input type='submit' value='Submit'</td>"
				+ "</tr>");
				
		out.print("</table>"
				+ "</center>"
				+ "</body>"
				+ "</html");
	}

}
