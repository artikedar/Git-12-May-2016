package org.capgemini.demo;

import java.util.Scanner;

public class Student {
	private int studentId,size;
	private double fees;
	private String firstName, lastName;
	
public void getStudentDetails(){
	

	
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Student Id: ");
	studentId=sc.nextInt();
	
	System.out.println("Enter First Name: ");
	firstName=sc.next();
	
	System.out.println("Enter Last Name: ");
	lastName=sc.next();
	
	System.out.println("Enter Fees: ");
	fees=sc.nextDouble();
	
}

public void printStudentDetails(){

	System.out.println(studentId + "\t" + firstName + "\t" + lastName + "\t" + fees);
	
}

public double getFees(){
	return fees;
}


	
	
	
	
}
