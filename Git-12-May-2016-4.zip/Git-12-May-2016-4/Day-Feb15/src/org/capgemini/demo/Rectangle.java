package org.capgemini.demo;

import java.util.Scanner;

public class Rectangle {
	public double length, width, area;
	public String colour;
	
public double set_Length(){
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter length: ");
	length=sc.nextDouble();
	return length;
}

public double set_Width(){
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter width: ");
	width=sc.nextDouble();
	return width;
}

public double find_Area(){
	area=length*width;
	System.out.println(area);
	return area;
	                         
}
public String set_Colour(){
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter colour: ");
	colour=sc.next();
	return colour;
}
public void compare(Rectangle r, Rectangle r1){
	if( (r.area == r1.area) && ( (r.colour).equals(r1.colour) )   )
		System.out.println("Matching Rectangles");
		else
			System.out.println("Non Matching Rectangles");
	}
	
}

	
	
	
	



