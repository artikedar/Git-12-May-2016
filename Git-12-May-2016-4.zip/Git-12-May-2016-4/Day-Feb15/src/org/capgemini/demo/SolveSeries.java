package org.capgemini.demo;

import java.util.Scanner;

public class SolveSeries {

	public int i, num;
	public double sum;

	
public void getInput(){
	Scanner sc=new Scanner(System.in);

	System.out.println("Enter Number: ");
	num=sc.nextInt();
	
}
	
public long findPower(long power){
	power=1;
	for(i=1;i<=num;i++){
		power=num*power;
	}
	System.out.println(power);
	return power;
}

public double sumOfSeries(){
	
	for(i=1;i<=num;i++)	
	sum=sum + ((double)(findPower(i))/(double)(findFactorial(i)));
	
	System.out.println(sum);
	
	return sum;
	
	
}


public long findFactorial(long fact){
	
	fact=1; 
	for(i=1;i<=num;i++){
		
		fact=fact*i; 
	}
	System.out.println(fact);
	return fact;
}


	
	
}
