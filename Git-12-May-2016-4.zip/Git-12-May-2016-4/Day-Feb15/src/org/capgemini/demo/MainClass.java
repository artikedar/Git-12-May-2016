package org.capgemini.demo;

public class MainClass {

	public static void main(String args[]){
		Rectangle r= new Rectangle();
		r.set_Length();
		r.set_Width();
		r.find_Area();
		r.set_Colour();
		Rectangle r1= new Rectangle();
		r1.set_Length();
		r1.set_Width();
		r1.find_Area();
		r1.set_Colour();
		r.compare(r,r1);
		
	
		
		
	}
		
		
		
		             
	
	
}