package org.capgemini.demo;

import java.util.Scanner;

public class Person {

	public int empId, java, c, cpp, total;
	public String firstName;
	public String lastName;
	public String address;
	public float average;


public void getpersondetails(){ 
	Scanner sc=new Scanner(System.in);
	
	System.out.println("Enter Employee Id: ");
	empId=sc.nextInt();

	System.out.println("Enter First Name: ");
	firstName=sc.next();
	
	System.out.println("Enter Last Name: ");
	lastName=sc.next();
	
	System.out.println("Enter Address: ");
	address=sc.next();
	
	System.out.println("Enter Java Marks: ");
	java=sc.nextInt();
	
	System.out.println("Enter C Marks: ");
	c=sc.nextInt();
	
	System.out.println("Enter CPP Marks: ");
	cpp=sc.nextInt();
	
}

public void calculation(){
	
	total= c + cpp + java;
	average= total/3;
}


public void printpersondetails(){ 
	
	System.out.println(empId);
	
	System.out.println(firstName);
	
	System.out.println(lastName);
	
	System.out.println(address);
	
	System.out.println(java);
	
	System.out.println(c);
	
	System.out.println(cpp);
	
	System.out.println("Total is: " + total);
	
	System.out.println("Average is: " + average);
	
	
	
}
	
	
	
	
}
