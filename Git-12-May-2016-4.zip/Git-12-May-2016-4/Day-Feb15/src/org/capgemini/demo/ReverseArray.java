package org.capgemini.demo;

import java.util.Scanner;

public class ReverseArray {
	int myArray [];
	
public void initializeArray (int size){
	myArray= new int[size];
	}
public void getArrayElements(){
	Scanner sc=new Scanner(System.in);
	System.out.println("What is Array Size? ");
	int size=sc.nextInt();
	initializeArray(size);
	System.out.println("Enter Array Elements: ");
		for(int i=0; i<myArray.length; i++){
		myArray[i]=sc.nextInt();
		}
	
	}
public void printArrayElements(){
	for(int i=0; i<myArray.length; i++){
		System.out.println(myArray[i]);
		}
	}
public void reverseArray(){
	for(int i=myArray.length-1; i>=0; i--){
		
			System.out.println(myArray[i]);
		}
	
	}

}
