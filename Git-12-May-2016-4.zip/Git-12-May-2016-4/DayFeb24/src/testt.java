

	public class testt {
		static int m1(String s, int i){
			System.out.println(s+i);
			return i;
		}
		
		public static void main(String[] args){
		int i=0,j=0,k=0;
			do  while (m1("i",++i)<2)
				System.out.print("k"+ ++k);
		while(m1("j",++j)<2);
		}
		}
	
