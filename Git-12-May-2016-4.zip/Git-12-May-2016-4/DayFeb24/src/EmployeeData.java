import java.io.File;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Scanner;

public class EmployeeData {
	public static void main(String[] args){
		
		File file=new File("D:\\Users\\akedar\\Documents\\Java\\File\\FormatOutDemo.txt");
		FileOutputStream fout=null;
		DataOutputStream dout=null;
		FileInputStream fin=null;
		DataInputStream din=null;
		String choice,choice1,choice2;
		Scanner sc=new Scanner(System.in);
		/*int empId;
		String empName;
		double salary;
		boolean isPermanent;
		char gender;
		Scanner sc=new Scanner(System.in);*/
		
		//Write data into File
		
		try{
		
		do{
			fout=new FileOutputStream(file,true);
			dout=new DataOutputStream(fout);
		System.out.println("Enter Emp Id: ");
		int empId=sc.nextInt();
		dout.writeInt(empId);
		
		System.out.println("Enter Emp Name: ");
		String empName=sc.next();
		dout.writeUTF(empName);
		
		System.out.println("Enter gender: ");
		String gender=sc.next();
		char str=gender.charAt(0); 
		dout.writeChar(str);
		
		System.out.println("Enter Salary: ");
		double salary=sc.nextDouble();
		dout.writeDouble(salary);
		
		System.out.println("Is Permanent? :");
		String isPermanent=sc.next();
		dout.writeUTF(isPermanent);
		
		System.out.println("Wish to continue? [y|n]");
		choice=sc.next();
		}while(choice.charAt(0)=='Y' || choice.charAt(0)=='y');	
		
		
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				//fin.close();
				//din.close();
				fout.close();
				dout.close();	
			} catch (Exception e2) {
				e2.printStackTrace();
			}
			
		}
		
		
		//Read data from the File
		
		try {
			fin=new FileInputStream(file);
			din=new DataInputStream(fin);
			
			
			int size=(int) file.length();
			while(size>=0)
			{
			int empId=din.readInt();	
			char gender=din.readChar();
			Double salary=din.readDouble();
			Boolean isPermanent=din.readBoolean();
			String empName=din.readLine();
			System.out.println(empId + "\n" + gender+"\n"+ salary+ "\n"+ isPermanent+ "\n"+ empName);
			size--;
			}
	} catch (Exception e) {
		e.printStackTrace();
	}finally {
		try {
			fin.close();
			din.close();				
		} catch (Exception e2) {
			e2.printStackTrace();
		}
		
	}

	}
}
