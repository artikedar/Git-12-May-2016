
public class D {
	
	
	
	
	public static void main(String[] args) {
		A c1=new C();
		//B c2=new C();
		C c2=new C();
		//D d1=new D();
		//d1.m1(c1);
		//d1.m1(c2);
		c1.m1(c2);
	}
}