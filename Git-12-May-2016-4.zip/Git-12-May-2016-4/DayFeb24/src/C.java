
public class C extends B{
	void m1(C c){System.out.println("C");}}
