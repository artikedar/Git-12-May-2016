import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class ReverseFile {
	public static void main(String[] args){
		File file=new File("D:\\Users\\akedar\\Documents\\Java\\File\\Demo.txt");
		FileReader fileReader=null;
		try {
			fileReader=new FileReader(file);
			long size=file.length();
			while(size>=0){
			System.out.print((char)fileReader.read());
			size--;
			}
			
						
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally{
			
			try {
				fileReader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		
	}
}
