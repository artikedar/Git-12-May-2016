
public class A {void m1(A a){System.out.println("A");}


