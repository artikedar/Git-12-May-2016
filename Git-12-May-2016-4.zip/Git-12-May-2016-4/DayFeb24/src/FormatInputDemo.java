import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;



public class FormatInputDemo {
	public static void main(String[] args){
	
		File file=new File("D:\\Users\\akedar\\Documents\\Java\\File\\FormatOutDemo.txt");
		FileInputStream fin=null;
		DataInputStream din=null;
		
		
		try {
			fin=new FileInputStream(file);
			din=new DataInputStream(fin);
			
			int empId=din.readInt();
			char gender=din.readChar();
			Double salary=din.readDouble();
			Boolean isPermanent=din.readBoolean();
			String empName=din.readLine();
			
			System.out.println("Employee Id: " + empId + "\nGender: " + gender+"\nSalary"+ salary+ "\nis Peramanent?"+ isPermanent+ "\nemployee Name"+ empName);
	} catch (Exception e) {
		e.printStackTrace();
	}finally {
		try {
			fin.close();
			din.close();				
		} catch (Exception e2) {
			e2.printStackTrace();
		}
		
	}
	}
}

