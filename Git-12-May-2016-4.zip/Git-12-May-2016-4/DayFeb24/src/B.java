
public class B extends A{
	void m1(B b){System.out.println("B");
}
