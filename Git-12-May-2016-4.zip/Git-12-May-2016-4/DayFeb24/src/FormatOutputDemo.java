import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;

public class FormatOutputDemo {
	public static void main(String[] args){
		
		int empId=1001;
		String empName="Arti";
		double salary= 12000;
		boolean isPermanent=true;
		char gender='f';
		
		File file=new File("D:\\Users\\akedar\\Documents\\Java\\File\\FormatOutDemo.txt");
		FileOutputStream fout=null;
		DataOutputStream dout=null;
		
		try {
			fout=new FileOutputStream(file);
			dout=new DataOutputStream(fout);
			
			dout.writeInt(empId);
			dout.writeChar(gender);
			dout.writeDouble(salary);
			dout.writeBoolean(isPermanent);
			dout.writeUTF(empName);
			
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				fout.close();
				dout.close();				
			} catch (Exception e2) {
				e2.printStackTrace();
			}
			
		}
		
		
		
		
	}
}
