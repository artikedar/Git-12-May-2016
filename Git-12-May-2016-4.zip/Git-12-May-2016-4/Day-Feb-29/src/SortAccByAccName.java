import java.util.Comparator;

public class SortAccByAccName implements Comparator<Account>{

	@Override
	public int compare(Account o1, Account o2) {
		if(o1.getAccType().compareTo(o2.getAccType())>0)
			return 1;
		else if(o1.getAccType().compareTo(o2.getAccType())<0)
			return -1;
		else 
			return 0;
	}
	

}
