import java.util.Comparator;

public class SortAccByBal implements Comparator<Account>{

	@Override
	public int compare(Account o1, Account o2) {
		if(o1.getOpenBalance()>o2.getOpenBalance())
			return 1;
		else if(o1.getOpenBalance()<o2.getOpenBalance())
			return -1;
		else 
			return 0;
	}
	

}
