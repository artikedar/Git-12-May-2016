import java.util.Scanner;

public class UserInteraction {
	String accName;
	String openDate;
	String accType;
	double openBalance;
	int accId;
	
	public Account getAccountDetails(){
		Account acc=new Account();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Account Name: ");
		accName=sc.next();
		System.out.println("Enter Account Type: ");
		accType=sc.next();
		System.out.println("Enter open Date: ");
		openDate=sc.next();
		System.out.println("Enter Open Balance: ");
		openBalance=sc.nextDouble();
		
		return acc;

	}
	
	
}
