
public interface DAO {
	public void createAccount();
	public void listAllAccount();
	public void deleteAccount();
	public void searchAccount();
	public void updateAccount();
	public void sort(int accId,String accName,String accType,String openDate,double OpenBalance);
}
