
public class Account {
	private String accName;
	private String openDate;
	private String accType;
	private double openBalance;
	private int accId;
	

		//No Argument Constructor
		public Account(){};
		
		//Argument Constructor
		public Account(int accid,String accName,String openDate,Double openBalance,String accType){
			this.accId=accId;
			this.accName=accName;
			this.accType=accType;
			this.openBalance=openBalance;
			this.openDate=openDate;
		}
			
		//Getters and Setters
		public String getAccName() {
			return accName;
		}

		public void setAccName(String accName) {
			this.accName = accName;
		}

		public String getOpenDate() {
			return openDate;
		}

		public void setOpenDate(String openDate) {
			this.openDate = openDate;
		}

		public String getAccType() {
			return accType;
		}

		public void setAccType(String accType) {
			this.accType = accType;
		}

		public double getOpenBalance() {
			return openBalance;
		}

		public void setOpenBalance(double openBalance) {
			this.openBalance = openBalance;
		}

		public int getAccId() {
			return accId;
		}

		public void setAccId(int accId) {
			this.accId = accId;
		}
		
		//toString Method
		@Override
		public String toString() {
			return "Account [accName=" + accName + ", openDate=" + openDate + ", accType=" + accType + ", openBalance="
					+ openBalance + ", accId=" + accId + "]";
		}
		
		
}
