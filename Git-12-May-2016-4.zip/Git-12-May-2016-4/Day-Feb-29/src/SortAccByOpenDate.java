import java.util.Comparator;

public class SortAccByOpenDate implements Comparator<Account>{

	@Override
	public int compare(Account o1, Account o2) {
		if(o1.getOpenDate().compareTo(o2.getOpenDate())>0)
			return 1;
		else if(o2.getOpenDate().compareTo(o2.getOpenDate())<0)
			return -1;
		else
			return 0;
	}
	

}
