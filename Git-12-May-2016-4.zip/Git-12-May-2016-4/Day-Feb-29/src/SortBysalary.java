import java.util.Comparator;

public class SortBysalary implements Comparator<Employee>{

	@Override
	public int compare(Employee salary, Employee salary1) {
		if(salary.getSalary()>(salary1.getSalary()))
			return 1;
		else if(salary.getSalary()<(salary1.getSalary()))
			return -1;
		else
			return 0;
	}
	

}
