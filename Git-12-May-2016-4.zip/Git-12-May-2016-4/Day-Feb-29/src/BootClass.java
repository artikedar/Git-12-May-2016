import java.util.Collections;
import java.util.Scanner;

public class BootClass {
	public static void main(String[] args){
		UserInteraction userInteraction=new UserInteraction();
		
		int option;
		int option1;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("1.Create Account");
		System.out.println("2.Delete account");
		System.out.println("3.List All Account");
		System.out.println("4.Search Account");
		System.out.println("5.Update Account");
		System.out.println("6.Sort Account by:");
		System.out.println("Enter Your Option:");
		option=sc.nextInt();
		
		switch (option){
		
		case 1: 
			userInteraction.getAccountDetails();
			break;
			
		case 2:
			
			break;
			
		case 3:
			
			break;
			
		case 4:
			
			break;
			
		case 5:
			
			break;
			
		case 6:
			System.out.println("1.Sort by Account Name");
			System.out.println("2.Sort by Open Date");
			System.out.println("3.Sort by Balance");
			System.out.println("Enter your option");
			option1=sc.nextInt();
			
			switch (option1){
			case 1:
				Collections.sort(list);
				break;
				
			case 2:
				
				break;
				
			case 3:
				
				break;
			}
			break;
		}
	}
	
	
}
