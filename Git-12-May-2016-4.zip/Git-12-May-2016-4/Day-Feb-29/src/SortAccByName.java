import java.util.Comparator;

public class SortAccByName implements Comparator<Account>{

	@Override
	public int compare(Account accName1, Account accName2) {
		if(accName1.getAccName().compareTo(accName2.getAccName())>0)
			return 1;
		else if(accName1.getAccName().compareTo(accName2.getAccName())<0)
			return -1;
		else
			return 0;
	}
	

}
