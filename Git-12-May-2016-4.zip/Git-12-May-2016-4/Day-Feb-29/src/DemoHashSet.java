import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;

public class DemoHashSet{
	public static void main(String[] args){
		
		ArrayList<Employee> set=new ArrayList<>();
		
		
		set.add(new Employee(10,"Arti","Kedar",20000));
		set.add(new Employee(10,"Arti","Kedar",18000));
		set.add(new Employee(30,"Shubs","Mad",2000));
		set.add(new Employee(40,"Seema","Man",1230));
		set.add(new Employee(50,"Pranjali","Dhor",4570));
		set.add(new Employee(60,"Harshal","Sol",8562));
		set.add(new Employee(70,"Rashmi","Kedar",23780));
		set.add(new Employee(80,"Riddhi","Thak",20900));
		set.add(new Employee(90,"Anish","Thakre",20500));
		set.add(new Employee(100,"Vikram","Thakres",20760));
	
		String choice;
		do{
		
		Scanner sc=new Scanner(System.in);
		System.out.println("1. Sort by Employee Id");
		System.out.println("2. Sort by Employee First Name");
		System.out.println("3. Sort by Employee Last Name");
		System.out.println("4. Sort by Employee salary");
		System.out.println("Enter your option");
		int option=sc.nextInt();
		switch (option){
		case 1: 
			Collections.sort(set);
			break;
		case 2:
			Collections.sort(set,new SortbyfName());
			break;
			
		case 3:
			Collections.sort(set,new SortBylName());
			break;
			
		case 4:
			Collections.sort(set,new SortBysalary());
			
			break;
		}
		
		
Iterator<Employee> itr=set.iterator();
		
		while(itr.hasNext()){
			
			System.out.println(itr.next());
		}
		System.out.println("Wish to continue? [y/n]");
		choice=sc.next();
	}while(choice.charAt(0)=='Y'||choice.charAt(0)=='y');
	}
}
