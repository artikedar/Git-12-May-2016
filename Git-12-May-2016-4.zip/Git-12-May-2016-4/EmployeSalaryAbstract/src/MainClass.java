import java.util.Scanner;

public class MainClass {
public static void main(String[] args){
	int option=0;
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter Option:");
	option=sc.nextInt();
	if(option==1){
	WeeklySalaryEmployee emp= new WeeklySalaryEmployee();
	emp.getemployee();
	emp.printEmployee();
	emp.calculateSalary();
	}
	else if(option==2){
		MonthlySalaryEmployee emp2=new MonthlySalaryEmployee();
		emp2.getemployee();
		emp2.printEmployee();
		emp2.calculateSalary();
	}
	else
		System.out.println("Enter a Valid Option");
	
}
}
