import java.util.Scanner;

public class MonthlySalaryEmployee extends Employee{
	int no_Of_Days;
	double salaryPerDay,salary;
public void calculateSalary(){
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter No. Of Days: ");
	no_Of_Days=sc.nextInt();
	System.out.println("Enter Salary Per Day: ");
	salaryPerDay=sc.nextDouble();
	salary=no_Of_Days*salaryPerDay;
	System.out.println("Salary: "+salary);
}
}
