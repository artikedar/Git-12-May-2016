import java.util.Scanner;

abstract public class Employee {
	public int kinId;
	public String firstName, lastName;
	
public void getemployee(){
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Employee KIN ID: ");
	kinId=sc.nextInt();
	System.out.println("Enter Employee First Name: ");
	firstName=sc.next();
	System.out.println("Enter Employee Last Name: ");
	lastName=sc.next();
	}
public void printEmployee(){
	System.out.println("First Name: " + firstName +"\nLast Name: " +lastName +"\nKIN ID: " +kinId );
}
public abstract void calculateSalary();
	
	
	

}
