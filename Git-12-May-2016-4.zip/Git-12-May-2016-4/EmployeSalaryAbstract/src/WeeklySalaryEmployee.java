import java.util.Scanner;

public class WeeklySalaryEmployee extends Employee{
	double salary, wagesPerHour;
	int hour;
public void calculateSalary(){
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Wages Per Hour: ");
	wagesPerHour=sc.nextDouble();
	System.out.println("Enter No. of Hours:");
	hour=sc.nextInt();
	
	salary=wagesPerHour*hour;
	System.out.println("Salary: "+salary);
}
}
