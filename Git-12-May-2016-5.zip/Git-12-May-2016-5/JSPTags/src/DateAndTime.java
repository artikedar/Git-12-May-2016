import java.io.IOException;
import java.io.StringWriter;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import sun.java2d.pipe.SpanShapeRenderer.Simple;

public class DateAndTime extends SimpleTagSupport{

	private String myTag;
	
	public String getMyTag() {
		return myTag;
	}


	public void setMyTag(String myTag) {
		this.myTag = myTag;
	}

	
	@Override
	public void doTag() throws JspException, IOException {
		JspWriter out=getJspContext().getOut();
		StringWriter str=new StringWriter();
		getJspBody().invoke(str);
		
		if(myTag==null){
			myTag="";
		}
		out.println("Hello! Today's Date and time is"+myTag+str);
		
	}
	

}
