
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class JDBCPractice {

	public static void main(String[] args) {
		
		//Load the Driver
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Class loaded");
		} catch (ClassNotFoundException e) {
		
			e.printStackTrace();
		}
	
		try {
			
			//Make a Connection
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdata", "root", "Pass1234");
			//Create Statement
			Statement stat=con.createStatement();
			//Execute Query
			ResultSet rs=stat.executeQuery("SELECT * FROM student_details");
			//Process The Result
			while(rs.next()){
				
				System.out.println(rs.getString(1));
			}
			con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
