import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.*;

public class MathTest {

	/*1. Year is divisible by 4.
	 *2. Year is not divisible by 4.
	 *3. Year is divisible by 100 and 400.
	 *4. Year is not divisible by 100 but not by 400.
	 *5. Negative values are not excepted. 
	 */
	
	//1. Year is divisible by 4.
	@Test
	public void testIsYearDivisibleByFour() {
		Math mt=new Math();
		assertTrue(mt.leapYear(2000));
	}
	
	//2. Year is not divisible by 4.
	@Test
	public void testIsNotYearDivisibleByFour() {
		Math mt=new Math();
		assertFalse(mt.leapYear(1987));
		
		
	}

	//3. Year is divisible by 100 and 400.
	@Test
	public void testIsYearDivisibleByHundredAndFourHundred() {
		Math mt=new Math();
		assertTrue(mt.leapYear(1600));
	}
	
	//4. Year is not divisible by 100 but not by 400.
	@Test
	public void testIsYearDivisibleByHundredButNotByFouHundred() {
		Math mt=new Math();
		assertTrue(mt.leapYear(1600));
	}
	
	//5. Negative values are not accepted. 
	@Test(expected=java.lang.RuntimeException.class)
	public void testIsYearANegativeValue(){
		Math mt=new Math();
		assertFalse(mt.leapYear(-2014));
		
	}
}
