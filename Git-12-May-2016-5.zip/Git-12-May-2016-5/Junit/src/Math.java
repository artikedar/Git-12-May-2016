
public class Math {
	

	public boolean leapYear(long x){
		boolean result=false;
		if(x<0){
			throw new RuntimeException();}
		else{
			if(x%4==0)
				result=true;
			else if(((x%100)==(0))&((x%400)==(0)))
				result=true;
			else if(!((x%100)==(0))&((x%400)==(0)))
				result=false;
			else if(!(x%4==0))
				result=false;
			}
		
		
		return result;
	}
}
