package org.oca.test2;

public class Test2 {

	/*public void typeExclamation(){
		System.out.println("!");
	}*/
}
