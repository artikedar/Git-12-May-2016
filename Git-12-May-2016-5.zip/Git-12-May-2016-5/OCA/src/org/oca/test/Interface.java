package org.oca.test;

public interface Interface {

	public void tellItLikeItIs();
}
