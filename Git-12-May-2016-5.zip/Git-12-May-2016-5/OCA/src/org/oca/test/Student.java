package org.oca.test;

public class Student extends Exception{

	public Student(String message){
		super(message);
		System.out.println(message);
	}

}
