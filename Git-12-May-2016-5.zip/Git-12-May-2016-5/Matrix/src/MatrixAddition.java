import java.util.Scanner;
public class MatrixAddition {
public static void main(String[] args){
	int[][] myArr1=new int[3][3];
	int[][] myArr2=new int[3][3];
	int[][] ans=new int[3][3];
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Array1 Elements: ");
	for(int i=0;i<3;i++){
		for(int j=0;j<3;j++){
			myArr1[i][j]=sc.nextInt();
		}
	}
	for(int i=0;i<3;i++){
		for(int j=0;j<3;j++){
			System.out.println(myArr1[i][j]);
		}
	}
	
	System.out.println("Enter Array2 Elements: ");
	for(int i=0;i<3;i++){
		for(int j=0;j<3;j++){
			myArr2[i][j]=sc.nextInt();
		}
	}
	for(int i=0;i<3;i++){
		for(int j=0;j<3;j++){
			System.out.println(myArr2[i][j]);
		}
	}
	
	System.out.println("Addition Answer is: ");
	for(int i=0;i<3;i++){
		for(int j=0;j<3;j++){
			ans[i][j]=myArr1[i][j]+myArr2[i][j];
			System.out.println(ans[i][j]);
		}
	}
}

}
