package org.capgemini.pojo;

public class customer {

	private int customer_id; 
	private String customer_email; 
	private String customer_password;
	private String customer_firstname; 
	private String customer_lastname;
	private String customer_city; 
	private String customer_state; 
	private String customer_pincode;
	private String customer_emailverified; 
	private String customer_regdate;
	private String customer_verificationcode;
	private String customer_phone;
	private String customer_country;
	private String customer_address;
}
