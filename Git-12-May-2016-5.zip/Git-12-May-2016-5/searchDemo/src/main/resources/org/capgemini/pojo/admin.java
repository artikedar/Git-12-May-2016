package org.capgemini.pojo;

public class admin {

}
