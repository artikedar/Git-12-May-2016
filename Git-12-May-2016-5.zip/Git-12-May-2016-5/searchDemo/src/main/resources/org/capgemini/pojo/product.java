package org.capgemini.pojo;

public class product {

}
