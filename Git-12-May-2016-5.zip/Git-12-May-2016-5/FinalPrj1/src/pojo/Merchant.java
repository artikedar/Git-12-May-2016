package pojo;

public class Merchant {

	
}
