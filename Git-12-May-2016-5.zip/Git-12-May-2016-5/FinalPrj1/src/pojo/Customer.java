package pojo;

import java.util.Date;

public class Customer {

	
	private int customer_id;
	private String customer_email;
	private String customer_password;
	private String customer_firstname;
	private String customer_lastname;
	private String customer_city;
	private String customer_state;
	private double customer_pincode;
	private String customer_emailverified;
	private Date customer_regdate;
	private double customer_verificationcode;
	private double customer_phone;
	private String customer_country;
	private String customer_address;
	

	//No Argument Constructor
	public Customer(){}
	
	//Full Argument Constructor
	public Customer(int customer_id, String customer_email, String customer_password, String customer_firstname,
			String customer_lastname, String customer_city, String customer_state, double customer_pincode,
			String customer_emailverified, Date customer_regdate, double customer_verificationcode,
			double customer_phone, String customer_country, String customer_address) {
		super();
		this.customer_id = customer_id;
		this.customer_email = customer_email;
		this.customer_password = customer_password;
		this.customer_firstname = customer_firstname;
		this.customer_lastname = customer_lastname;
		this.customer_city = customer_city;
		this.customer_state = customer_state;
		this.customer_pincode = customer_pincode;
		this.customer_emailverified = customer_emailverified;
		this.customer_regdate = customer_regdate;
		this.customer_verificationcode = customer_verificationcode;
		this.customer_phone = customer_phone;
		this.customer_country = customer_country;
		this.customer_address = customer_address;
	}

	
	//Getters And Setters
	public int getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}
	public String getCustomer_email() {
		return customer_email;
	}
	public void setCustomer_email(String customer_email) {
		this.customer_email = customer_email;
	}
	public String getCustomer_password() {
		return customer_password;
	}
	public void setCustomer_password(String customer_password) {
		this.customer_password = customer_password;
	}
	public String getCustomer_firstname() {
		return customer_firstname;
	}
	public void setCustomer_firstname(String customer_firstname) {
		this.customer_firstname = customer_firstname;
	}
	public String getCustomer_lastname() {
		return customer_lastname;
	}
	public void setCustomer_lastname(String customer_lastname) {
		this.customer_lastname = customer_lastname;
	}
	public String getCustomer_city() {
		return customer_city;
	}
	public void setCustomer_city(String customer_city) {
		this.customer_city = customer_city;
	}
	public String getCustomer_state() {
		return customer_state;
	}
	public void setCustomer_state(String customer_state) {
		this.customer_state = customer_state;
	}
	public double getCustomer_pincode() {
		return customer_pincode;
	}
	public void setCustomer_pincode(double customer_pincode) {
		this.customer_pincode = customer_pincode;
	}
	public String getCustomer_emailverified() {
		return customer_emailverified;
	}
	public void setCustomer_emailverified(String customer_emailverified) {
		this.customer_emailverified = customer_emailverified;
	}
	public Date getCustomer_regdate() {
		return customer_regdate;
	}
	public void setCustomer_regdate(Date customer_regdate) {
		this.customer_regdate = customer_regdate;
	}
	public double getCustomer_verificationcode() {
		return customer_verificationcode;
	}
	public void setCustomer_verificationcode(double customer_verificationcode) {
		this.customer_verificationcode = customer_verificationcode;
	}
	public double getCustomer_phone() {
		return customer_phone;
	}
	public void setCustomer_phone(double customer_phone) {
		this.customer_phone = customer_phone;
	}
	public String getCustomer_country() {
		return customer_country;
	}
	public void setCustomer_country(String customer_country) {
		this.customer_country = customer_country;
	}
	public String getCustomer_address() {
		return customer_address;
	}
	public void setCustomer_address(String customer_address) {
		this.customer_address = customer_address;
	}
	
	
	//toString Method
	@Override
	public String toString() {
		return "Customer [customer_id=" + customer_id + ", customer_email=" + customer_email + ", customer_password="
				+ customer_password + ", customer_firstname=" + customer_firstname + ", customer_lastname="
				+ customer_lastname + ", customer_city=" + customer_city + ", customer_state=" + customer_state
				+ ", customer_pincode=" + customer_pincode + ", customer_emailverified=" + customer_emailverified
				+ ", customer_regdate=" + customer_regdate + ", customer_verificationcode=" + customer_verificationcode
				+ ", customer_phone=" + customer_phone + ", customer_country=" + customer_country
				+ ", customer_address=" + customer_address + "]";
	}
	
	
}
