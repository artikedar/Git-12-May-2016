package pojo;

public class Admin {

	private int admin_id;
	private String admin_first_name;
	private String admin_last_name;
	private double admin_mobile_number;
	private String admin_email_id;
	private String admin_password;		
	
	//No Argument Constructor
	public Admin(){}
	
	
	//Argument Constructor
	public Admin(int admin_id, String admin_first_name, String admin_last_name, double admin_mobile_number,
			String admin_email_id, String admin_password) {
		super();
		this.admin_id = admin_id;
		this.admin_first_name = admin_first_name;
		this.admin_last_name = admin_last_name;
		this.admin_mobile_number = admin_mobile_number;
		this.admin_email_id = admin_email_id;
		this.admin_password = admin_password;
	}
	
	//Getters And Setters
	public int getAdmin_id() {
		return admin_id;
	}
	public void setAdmin_id(int admin_id) {
		this.admin_id = admin_id;
	}
	public String getAdmin_first_name() {
		return admin_first_name;
	}
	public void setAdmin_first_name(String admin_first_name) {
		this.admin_first_name = admin_first_name;
	}
	public String getAdmin_last_name() {
		return admin_last_name;
	}
	public void setAdmin_last_name(String admin_last_name) {
		this.admin_last_name = admin_last_name;
	}
	public double getAdmin_mobile_number() {
		return admin_mobile_number;
	}
	public void setAdmin_mobile_number(double admin_mobile_number) {
		this.admin_mobile_number = admin_mobile_number;
	}
	public String getAdmin_email_id() {
		return admin_email_id;
	}
	public void setAdmin_email_id(String admin_email_id) {
		this.admin_email_id = admin_email_id;
	}
	public String getAdmin_password() {
		return admin_password;
	}
	public void setAdmin_password(String admin_password) {
		this.admin_password = admin_password;
	}
	
	//toString Method
		@Override
		public String toString() {
			return "Admin [admin_id=" + admin_id + ", admin_first_name=" + admin_first_name + ", admin_last_name="
					+ admin_last_name + ", admin_mobile_number=" + admin_mobile_number + ", admin_email_id="
					+ admin_email_id + ", admin_password=" + admin_password + "]";
		}
		
	
	
}
