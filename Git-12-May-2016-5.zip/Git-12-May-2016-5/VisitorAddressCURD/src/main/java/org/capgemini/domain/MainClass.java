package org.capgemini.domain;

import java.applet.AppletContext;
import java.util.List;

import org.capgemini.dao.VisitorDaoImpl;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
	
		ApplicationContext context=new ClassPathXmlApplicationContext("jdbcBean.xml");
		
		VisitorDaoImpl visitorDao=(VisitorDaoImpl) context.getBean("jdbcTemp");
			
		/*
		Address address=new Address(1, 404, 50, "Pune", "Maharashtra");
		Address address1=new Address(2, 405, 60, "Pune", "Maharashtra");
		Address address2=new Address(3, 406, 20, "Pune", "Maharashtra");
		Address address3=new Address(4, 407, 30, "Pune", "Maharashtra");
		Address address4=new Address(5, 408, 10, "Pune", "Maharashtra");
		Address address5=new Address(6, 409, 80, "Pune", "Maharashtra");
		
		Visitor visitor=new Visitor(101, "Arti",address);
		Visitor visitor1=new Visitor(201, "Pranjali",address1);
		Visitor visitor2=new Visitor(301, "Harshal",address2);
		Visitor visitor3=new Visitor(401, "Seema",address3);
		Visitor visitor4=new Visitor(501, "Shubhangi",address4);
		Visitor visitor5=new Visitor(601, "Komal",address5);
		
		
		visitorDao.createVisitor(visitor);
		visitorDao.createVisitor(visitor1);
		visitorDao.createVisitor(visitor2);
		visitorDao.createVisitor(visitor3);
		visitorDao.createVisitor(visitor4);
		visitorDao.createVisitor(visitor5);
		*/
		
		List<Visitor> visitors=visitorDao.getAllVisitor();
		
		for(Visitor vis:visitors)
			System.out.println(vis);
		
		
		
		
		
		
		
		
		
		
		

	}

}
