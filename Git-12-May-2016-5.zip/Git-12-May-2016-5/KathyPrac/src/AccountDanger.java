
public class AccountDanger implements Runnable{
	public static void main(String[] args){
		AccountDanger r=new AccountDanger();
		Thread one=new Thread(r);
		Thread two=new Thread(r);
		one.setName("Fred");
		two.setName("Lucy");
		one.start();
		two.start();
	}
	
	public void run(){
		for(int x=0;x<5;x++){
			makeWithdrawal(10);
			if()
		}
	}

}
