import java.util.Locale.LanguageRange;
import java.util.Scanner;

public class charAt {
	public void main(String[] args){

			String string;
			char letter;
			int pos;
			Scanner sc=new Scanner(System.in);

			System.out.println("Enter String: ");
			string=sc.next();
			System.out.println("Enter Position: ");
			pos=sc.nextInt();
			letter=charAt(pos);
			System.out.println("Alphabet at 4th position is: "+letter);
		

	}
		
	
}
