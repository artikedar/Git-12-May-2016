package org.capgemini.demo;

public class Rectangle extends Shape{
	public void draw(){
		System.out.println("Rectangle Class Draw ");
	}
}
