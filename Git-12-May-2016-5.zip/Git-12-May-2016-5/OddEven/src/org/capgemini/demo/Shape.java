package org.capgemini.demo;

public class Shape {
	public void draw(){
		System.out.println("Shape Class Draw ");
	}
	
}
