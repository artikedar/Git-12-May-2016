package org.capgemini.demo;

public class Triangle extends Shape{
	public void draw(){
		System.out.println("Triangle Class Draw ");
	}
}
