package org.capgemini.demo;
import java.util.Scanner;
public class OddEvenSeries{
	int num=1,num1=2;
	int length;

	public int getLength(){
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Length");
		length=sc.nextInt();
		return length;
		
	}

	public void findOdd(){
		for(int i=0;i<3;i++){
			System.out.print(num+" " );
			num=num+2;
		}
	}
	public void findEven(){
		for(int i=0;i<3;i++){
			System.out.print(num1+" " );
			num1=num1+2;
		}
	}

	}

