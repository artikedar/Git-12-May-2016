package org.capgemini.demo;

public class Example {
	static int count;
	int num;
	static{
		System.out.println("Static Block");
	}
	{
	System.out.println("Normal Block");
	}
public void example(){
	System.out.println("Constructor");
}
}
	
