package org.capgemini.demo;

public class MainRestore {
	Example ex=new Example();
}
