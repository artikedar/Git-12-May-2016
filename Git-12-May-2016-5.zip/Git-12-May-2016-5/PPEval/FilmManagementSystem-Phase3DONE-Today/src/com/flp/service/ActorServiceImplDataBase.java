package com.flp.service;

import java.util.Set;

import com.flp.fms.dao.ActorDaoImplForDataBase;
import com.flp.fms.dao.IActorDao;
import com.flp.fms.pojo.Actor;

public class ActorServiceImplDataBase implements IActorService{

	private IActorDao actorDao=new ActorDaoImplForDataBase();
	@Override
	public Set<Actor> getActors() {
		// TODO Auto-generated method stub
		return actorDao.getActors();
	}
	@Override
	public int addActor(Actor actor) {
		// TODO Auto-generated method stub
		return actorDao.addActor(actor);
	}
	@Override
	public int removeActor(int id) {
		// TODO Auto-generated method stub
		return actorDao.removeActor(id);
	}
	@Override
	public Actor searchActorById(int id) {
		// TODO Auto-generated method stub
		return actorDao.searchActorById(id);
	}
	@Override
	public int updateActor(Actor actor, int id) {
		// TODO Auto-generated method stub
		return actorDao.updateActor(actor,id);
	}

	

}
