package org.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.service.FilmServiceImpl;
import com.flp.service.IFilmService;

/**
 * Servlet implementation class FilmSearch
 */
public class FilmSearch extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IFilmService filmService=new FilmServiceImpl();
		List<Film> films=new ArrayList<>();
		films=filmService.getAllFilms();
		Actor actor=new Actor();
		Film film=new Film();
		
		int serFilmId=Integer.parseInt(request.getParameter("filmId"));
		String title=request.getParameter("filmTilte");
		if(serFilmId!=0)
		{
			film.setFilm_ID(serFilmId);
			
		}
		if(title!=null)
		{
			film.setTitle(title);
		}
		
		String[] actorNew=request.getParameterValues("actor");
		if(Integer.parseInt(request.getParameter("actor"))>0)
		{
		Set<Actor> actorList=new HashSet<>();
		for(String actor2:actorNew)
		{
			Actor actor3=new Actor();
			int actNew=Integer.parseInt(actor2);
			actor3.setActor_Id(actNew);		
			actorList.add(actor3);
		}
		film.setActors(actorList);
		}
		String[] otherLanguages=request.getParameterValues("orgLang");
		if(Integer.parseInt(request.getParameter("orgLang"))>0)
		{
		List<Language> langList=new ArrayList<>();
		for(String langs:otherLanguages){
			Language langOther=new Language();
			langOther.setLanguage_Id(Integer.parseInt(langs));
			langList.add(langOther);
				                                                                                       
		}
		film.setLanguages(langList);
		}
		filmService.searchFilm(film);
		
		
		
	
		
		//Print the Found Film
		PrintWriter out=response.getWriter();
		out.println("<html>"
				+ "<h4>Got following Results</h4>"
				+ "<head>Search Results</head>"
				+ "<body>"
				+ "<table border='1'>"
				
				+ "<tr>"
				+ "<th>FilmId</th>"
				+ "<th>Title</th>"
				+ "<th>Description</th>"
				+ "<th>Release Year</th>"
				+ "<th>Original Language</th>"
				+ "<th>Rental Duration</th>"
				+ "<th>Length</th>"
				+ "<th>Replacement Cost</th>"
				+ "<th>Rating</th>"
				+ "<th>Special Features</th>"
				+ "<th>Category</th>"
				+ "<th>List of Actors</th>"
				+ "<th>List of Other Languages</th>"
				+ "</tr>");
				
				
		for(Film allFilms:films){
			
			out.println(
					
			"<tr>"
			+"<td>"+allFilms.getFilm_ID()+"</td>"
			+"<td>"+allFilms.getTitle()+"</td>"
			+"<td>"+allFilms.getDescription()+"</td>"
			+"<td>"+allFilms.getReleaseYear()+"</td>"
			
			
			+"<td>"+(allFilms.getOriginalLanguage()).getName()+"</td>"
			
			
			
			+"<td>"+allFilms.getRentalDuration()+"</td>"
			+"<td>"+allFilms.getLength()+"</td>"
			+"<td>"+allFilms.getReplacementCost()+"</td>"
			+"<td>"+allFilms.getRatings()+"</td>"
			+"<td>"+allFilms.getSpecialFeatures()+"</td>"
			+"<td>"+(allFilms.getCategory()).getName()+"</td>");
			
			Set<Actor> act=allFilms.getActors();
			out.println("<td>");
			for(Actor actors:act){
				String actor2=actors.getFirst_Name()+actors.getLast_Name();
				out.println(actor2); 
			}
			out.println("</td>");
			
			List<Language> langs=allFilms.getLanguages();
			out.println("<td>");
			for(Language otherLan:langs){
				String lang=otherLan.getName();
				out.println(lang); 
			}
			out.println("</td>");
			
			out.println(
			
			 "</tr>");
		}
		
		out.println(		
		"</table>"
		+ "</body>"
		+ "</html>");

		
	}

}
