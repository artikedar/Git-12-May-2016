
public interface Shape {

	
}
