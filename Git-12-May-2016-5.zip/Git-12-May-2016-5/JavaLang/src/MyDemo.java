import java.util.Scanner;

public class MyDemo {
	public static void main(String[] args){
		String str1="Tom";
		String str2="Tom";
		String myStr=new String("Tom");
		System.out.println(str1==str2);

		System.out.println(str1.equals(str2));
		System.out.println(str1.equals(myStr));
	
	}
	

}
