package org.capstore.service;

import java.util.List;

import org.capstore.domain.Brand;
import org.capstore.domain.Merchant;
import org.capstore.domain.Stock;
import org.capstore.domain.Sub_category;

public interface ProductService {

	
	public List<Brand> getAllBrands();
	
	public List<Merchant> getAllMerchants();
	public List<Sub_category> getAllSub_category();
	public List<Stock> getAllStock();
}
