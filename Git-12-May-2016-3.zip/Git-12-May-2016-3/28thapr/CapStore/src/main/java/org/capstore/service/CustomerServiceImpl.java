package org.capstore.service;

public class CustomerServiceImpl implements CustomerServiceInterface {

	@Override
	public void search() {
		

		System.out.print("hello");
	}

}
