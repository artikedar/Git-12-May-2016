package org.capstore.controller;

import java.security.Provider.Service;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloController {

	Service service;
	
	
	@RequestMapping("/hello")
	public ModelAndView sayHello(){
		String message="Hello Spring MVC";
		servic
		return new ModelAndView("helloPage","msg",message);
	}
}
