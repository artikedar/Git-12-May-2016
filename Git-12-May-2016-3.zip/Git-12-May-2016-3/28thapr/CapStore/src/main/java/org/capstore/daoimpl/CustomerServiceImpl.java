package org.capstore.daoimpl;

import org.capstore.service.CustomerServiceInterface;

public class CustomerServiceImpl  implements CustomerServiceInterface{
	public void search()
	{
		System.out.print("hello");
	}

}
