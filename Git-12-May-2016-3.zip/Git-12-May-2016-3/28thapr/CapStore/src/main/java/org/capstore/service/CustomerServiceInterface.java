package org.capstore.service;

public interface CustomerServiceInterface {

	
	public void search();
}
