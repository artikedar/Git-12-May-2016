import java.util.Scanner;

public class Address{
	private int doorNo;
	private String streetName, city, state, pinCode;
	private Address address;
	
	Scanner sc= new Scanner(System.in);

/*public Address(){
	doorNo=404;
	streetName="Barlinge Marg";
	city="Pune";
	state="Maharashtra";
	pinCode=411021;
}*/
	
public void Get_Address(){
	System.out.println("Enter Door No.: ");
	doorNo=sc.nextInt();
	
	System.out.println("Enter Street Name: ");
	streetName=sc.next();
	
	System.out.println("Enter City: ");
	city=sc.next();
	
	System.out.println("Enter State: ");
	state=sc.next();
	
	System.out.println("Enter Pin Code: ");
	pinCode=sc.next();
	
	
}

public void Print_Address(){
	
	System.out.println(doorNo +","+streetName+","+city+"\n"+state+"-"+pinCode);
	
}
	
	
	
	
}
