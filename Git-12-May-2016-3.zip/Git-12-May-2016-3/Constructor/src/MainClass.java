
public class MainClass {

	public static void main(String[] args) {
		Customer customer=new Customer();
		customer.Get_CustomerDetails();
		customer.Print_CustomerDetails();
		

	}

}
