import java.util.Scanner;

public class Customer {
	private int custId;
	private double regFees;
	private String custName;
	private Address address;
	
/*public Customer(){

	custId=1002;
	regFees=50000;
	custName="Tom";
}*/

public Customer(){
	address= new Address();
	
}
	
public void Get_CustomerDetails(){
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Customer Id: ");
	custId=sc.nextInt();
	
	System.out.println("Enter Customer Name: ");
	custName=sc.next();
	
	System.out.println("Enter Registration Fees: ");
	regFees=sc.nextDouble();
	
	//address=new Address();
	address.Get_Address();
}

public void Print_CustomerDetails(){
	
	System.out.println(custId+"\t"+custName+"\t"+regFees);
	
	address.Print_Address();
}



}

