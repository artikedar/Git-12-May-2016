package com.flp.fms.dao;

import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public interface IFilmDao {
	
	public List<Language> getLanguages();

	public List<Category> getCategories();
	
	public void addFilm(Film film);
	
	public List<Film> getAllFilms();
	
	public int removeFilm(int id);

	public List<Film> searchFilm(Film film);

	public Film updateFilm(int id);
	
	public int updatedFilm(int id, Film film);
	
	

	
	
}
