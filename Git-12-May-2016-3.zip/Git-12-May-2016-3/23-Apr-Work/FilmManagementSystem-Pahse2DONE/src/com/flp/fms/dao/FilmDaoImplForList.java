package com.flp.fms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.view.UserInteraction;


public class FilmDaoImplForList implements IFilmDao{
	
	private Map<Integer, Film> film_Repository=new HashMap<>();
	
	public Connection getConnection(){
		Connection connection=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/filmdb", "root", "Pass1234");
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return connection;
	}
	
	@Override
	public List<Language> getLanguages() {
			List<Language> languages=new ArrayList<>();
			Connection con=getConnection();
			String sql="SELECT * FROM languages";
						
			try {
				 Statement stm=con.createStatement();
				 ResultSet rs=stm.executeQuery(sql);
				 while(rs.next())
				 {
				Language language=new Language();
				language.setLanguage_Id(rs.getInt(1));
				language.setName(rs.getString(2));
				
				languages.add(language);
				 }
				
				
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			
			
			
			
			/*languages.add(new Language(1, "English"));
			languages.add(new Language(2, "Hindi"));
			languages.add(new Language(3, "Marathi"));
			languages.add(new Language(4, "Tamil"));
			languages.add(new Language(5, "Telegu"));
		*/
			return languages;
			}

	@Override
	public List<Category> getCategories() {
		List<Category> categories=new ArrayList<>();
		Connection con=getConnection();
		String sql="SELECT * FROM category";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			while(rs.next()){
			Category category=new Category();
			category.setCategory_Id(rs.getInt(1));
			category.setName(rs.getString(2));
			categories.add(category);
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		/*categories.add(new Category(1, "Horror"));
		categories.add(new Category(2, "Comedy"));
		categories.add(new Category(3, "Romance"));
		categories.add(new Category(4, "Drama"));
		categories.add(new Category(5, "Action"));
		categories.add(new Category(6, "Documentry"));*/
		
		return categories;
	}

	@Override
	public void addFilm(Film film) {
		
			Connection con=getConnection();
			String sql="insert into film(title,description,releaseYear,originalLanguage,rentalduration,length,replacementCost,rating,specialFeatures,category)"+"values(?,?,?,?,?,?,?,?,?,?)";
			
			try {
				PreparedStatement pst=con.prepareStatement(sql);
				pst.setString(1, film.getTitle());
				pst.setString(2,film.getDescription());
				pst.setDate(3,new Date(film.getReleaseYear().getTime()));
				pst.setInt(4,(film.getOriginalLanguage()).getLanguage_Id());
				pst.setDate(5, new Date(film.getRentalDuration().getTime()));
				pst.setInt(6, film.getLength());
				pst.setDouble(7, film.getReplacementCost());
				pst.setInt(8, film.getRatings());
				pst.setString(9, film.getSpecialFeatures());
				pst.setInt(10, film.getCategory().getCategory_Id());
				
				int count=pst.executeUpdate();
				
				System.out.println(count);
				
				if(count>0){
					//insert into third party tables
					
					//Getting Film Id
					int filmId=0;
					String sqlFilmId="select * from film order by filmId desc limit 1";
					PreparedStatement pst2=con.prepareStatement(sqlFilmId);
					ResultSet rs2=pst2.executeQuery();
					while(rs2.next()){
						filmId=rs2.getInt(1);
					}
					
					//Inserting into Actor table
					String sqlActorAdd="insert into film_actors(filmId,actorId) values(?,?)";
					pst=con.prepareStatement(sqlActorAdd);
					
					Set<Actor> actors=film.getActors();
					for(Actor act:actors){
						pst.setInt(1, filmId);
						pst.setInt(2, act.getActor_Id());
						
						count=pst.executeUpdate();
					}
					
					//Inserting into Languages table
					String sqllanguageAdd="insert into film_languages(filmId,languageId) values(?,?)";
					pst=con.prepareStatement(sqllanguageAdd);
					
					List<Language> languages=film.getLanguages();
					for(Language lang:languages){
						pst.setInt(1, filmId);
						pst.setInt(2, lang.getLanguage_Id());
						
						count=pst.executeUpdate();
						
					}
							
				}
								
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
	/*	film_Repository.put(film.getFilm_ID(), film);*/
		}

	@Override
	public List<Film> getAllFilms() {
		List<Film> films=new ArrayList<>();
		Connection con=getConnection();
		String sqlGetFilm="select * from film";
		try {
			PreparedStatement pst4=con.prepareStatement(sqlGetFilm);
			ResultSet rs=pst4.executeQuery();
			
			/*Statement stm=con.createStatement();
			ResultSet rs=stm.executeQuery(sqlGetFilm);*/
			
			while(rs.next()){
				Film film1=new Film();
				
				//Get FilmId
				film1.setFilm_ID(rs.getInt(1));
				
				//Get Film Title
				film1.setTitle(rs.getString(2));
				
				//Get Film Description
				film1.setDescription(rs.getString(3));
				
				//Get Release Year
				film1.setReleaseYear(rs.getDate(4).valueOf(rs.getDate(4).toString()));
				
				//Get Original Language
				/*int orgLangId=rs.getInt(5);
				Language lang=getLanguages(orgLangId);*/
				
				//Get Rental Duration
				film1.setRentalDuration(rs.getDate(6).valueOf(rs.getDate(6).toString()));
				
				//Get Length
				film1.setLength(rs.getInt(7));
				
				//Get Replacement Cost
				film1.setReplacementCost(rs.getDouble(8));
				
				//Get Ratings
				film1.setRatings(rs.getInt(9));
			
				//Get special Features
				film1.setSpecialFeatures(rs.getString(10));
				
				//Get Category
				int categoryId=rs.getInt(11);
				Category category=getCategory(categoryId);
				film1.setCategory(category);
				//films.add(film1);
				
				
				
				
				/*film1.setCategory(rs.getString(11));*/
				
				//Get List of Actors
				Set<Actor> actors=new HashSet<>();
				List<Integer> actorId=getActorIds(film1.getFilm_ID());
				for(Integer actor:actorId){
					actors.add(getActors(actor));
				}
				film1.setActors(actors);
				//films.add(film1);
				
				//Get Original Language
				int langID=rs.getInt(5);
				Language lang=getOriginalLanguage(langID);
				film1.setOriginalLanguage(lang);
				//films.add(film1);
				
				
				
				//Get List Other LAnguages
				List<Language> otherLangName=new ArrayList<>();
				List<Integer> otherLangId=getLanguageId(film1.getFilm_ID());
				for(Integer langId:otherLangId){
					
					otherLangName.add(getOriginalLanguage(langId));
				}
				film1.setLanguages(otherLangName);
				films.add(film1);
				
				//System.out.println(films);
				
				
			
				
				/*String sqlCategoryAdd="select * from category where            "
				*/
				
				
				
			}
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
				
		
		return films;
	}
	
	
	

	//Method to Get the first name and Last Name of Actors
	private Actor getActors(int actor){
		Actor act=new Actor();
		Connection con=getConnection();
		String sqlGetActors="select * from actors where actorId=?";
		
		try {
			PreparedStatement pst=con.prepareStatement(sqlGetActors);
			pst.setInt(1, actor);
			ResultSet rs=pst.executeQuery();
			while(rs.next()){
				act.setFirst_Name(rs.getString(2));
				act.setLast_Name(rs.getString(3));
				
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return act;
		
	}
	
	
	//Method to Get the IDs of Actors
	private List<Integer> getActorIds(int filmId1){
		List<Integer> actorIds=new ArrayList<>();
		Connection con=getConnection();
		String sqlActorIds="select * from film_actors where filmId=?";
		try {
			PreparedStatement pst=con.prepareStatement(sqlActorIds);
			pst.setInt(1, filmId1);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next()){
				actorIds.add(rs.getInt(2));
			}
			
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
		
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return actorIds;
		
	}
	
	//Method to Get Language Ids
	private List<Integer> getLanguageId(int filmId1){
		List<Integer> langId=new ArrayList<>();
		Connection con=getConnection();
		String sqlLangId="select * from film_languages where filmId=?";
		
		try {
			PreparedStatement pst=con.prepareStatement(sqlLangId);
			pst.setInt(1, filmId1);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next()){
				langId.add(rs.getInt(2));
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return langId;
		
		
	}
	
	//Method to GetLanguages
	private Language getOriginalLanguage(int langId){
		Language lang1=new Language();
		Connection con=getConnection();
		String sqlOrgLang="select * from languages where LangId=?";
		
		try {
			PreparedStatement pst=con.prepareStatement(sqlOrgLang);
			pst.setInt(1, langId);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next()){
				lang1.setName(rs.getString(2));
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lang1;
		
	}

	//Method to get Category
	private Category getCategory(int categoryID){
		Category cat=new Category();
		Connection con=getConnection();
		String sqlGetCategory="select * from category where categoryId=?";
		try {
			PreparedStatement pst=con.prepareStatement(sqlGetCategory);
			pst.setInt(1, categoryID);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next()){
				cat.setName(rs.getString(2));
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		try {
			con.close();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return cat;
		
	}

	@Override
	public int removeFilm(Film film) {
		int count=0;
		System.out.println(film);
		int id=film.getFilm_ID();
		int rating=film.getRatings();
		String title=film.getTitle();
		
		if(id!=0)
		{
		Connection con=getConnection();
		String sqlDeleteFromFilm="delete from film where filmId=?";
		String sqlDeleteFromFilmLang="delete from film_languages where filmId IN(select 'film_languages'.filmId from film where filmId=?);";
		String sqlDeleteFromFilmAct="delete from film_actors where filmId IN(select 'film_actors'.filmId from film where filmId=?);";
		
		try {
			PreparedStatement pst=con.prepareStatement(sqlDeleteFromFilm);
			pst.setInt(1, id);
			count=pst.executeUpdate();
			
			PreparedStatement pst2=con.prepareStatement(sqlDeleteFromFilmLang);
			pst.setInt(1, id);
			count=pst.executeUpdate();
			
			PreparedStatement pst3=con.prepareStatement(sqlDeleteFromFilmAct);
			pst.setInt(1, id);
			count=pst.executeUpdate();
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		}
		if(rating!=0){
			Connection con=getConnection();
			String sqlDeleteFromFilm="delete from film where rating=?";
			String sqlDeleteFromFilmLang="delete from film_languages where filmId IN(select 'film_languages'.filmId from film where rating=?)";
			String sqlDeleteFromFilmAct="delete from film_actors where filmId IN(select 'film_actors'.filmId from film where rating=?);";
			
			try {
				PreparedStatement pst=con.prepareStatement(sqlDeleteFromFilm);
				pst.setInt(9, rating);
				count=pst.executeUpdate();
				
				PreparedStatement pst2=con.prepareStatement(sqlDeleteFromFilmLang);
				pst.setInt(1, id);
				count=pst.executeUpdate();
				
				PreparedStatement pst3=con.prepareStatement(sqlDeleteFromFilmAct);
				pst.setInt(1, id);
				count=pst.executeUpdate();
				
				
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
		
		if(title!=null){
			Connection con=getConnection();
			String sqlDeleteFromFilm="delete from film where title=?";
			String sqlDeleteFromFilmLang="delete from film_languages where filmId IN(select 'film_languages'.filmId from film where title=?)";
			String sqlDeleteFromFilmAct="delete from film_actors where filmId IN(select 'film_actors'.filmId from film where title=?);";
			
			try {
				PreparedStatement pst=con.prepareStatement(sqlDeleteFromFilm);
				pst.setString(2, title);
				count=pst.executeUpdate();
				
				PreparedStatement pst2=con.prepareStatement(sqlDeleteFromFilmLang);
				pst.setInt(1, id);
				count=pst.executeUpdate();
				
				PreparedStatement pst3=con.prepareStatement(sqlDeleteFromFilmAct);
				pst.setInt(1, id);
				count=pst.executeUpdate();
				
				
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
		
		
		
		
		return count;
	}

	//Search Film
	@Override
	public List<Film> searchFilm(Film film) {
		List<Film> resFilm=new ArrayList<>();
		int count=0;
		Connection con=getConnection();
		String sql="select * from film where ";
		
		System.out.println("Dao will search for:"+film);
		if(film!=null){
		
			if(film.getFilm_ID()>0)
			{
				sql+="filmId="+film.getFilm_ID();
				count=1;
				
			}
			
			if((film.getTitle()!=null)&&(film.getTitle().length()!=0))
			{
				if(count==1)
				{
					System.out.println("Appending title "+film.getTitle());
					sql+=" and title='"+film.getTitle()+"'";
					
				}
				else 
				{
					sql+="title='"+film.getTitle()+"'";
				}
				count=2;
				
			}
			
			if(!(film.getActors()==null))
			{
				Actor act=new Actor();
				Set<Actor> actors=film.getActors();
				for(Actor acts:actors)
				{
					act=acts;
				}
				if(count==1||count==2)
				{
					sql+=" and filmId IN (select filmId from film_actors where actorId="+act.getActor_Id()+")";
					
				}
				else
				{
					sql+=" filmId IN (select filmId from film_actors where actorId="+act.getActor_Id()+")";
				}
				count=3;
			}
			if(!(film.getOriginalLanguage()==null))
			{
				Language lang=new Language();
				Language langs=film.getOriginalLanguage();
				System.out.println("Dao got Languages:"+langs);
				
					
				
				if(count==1||count==2||count==3)
				{
					sql+=" and (filmId IN(select filmId from film_languages where languageId="+langs.getLanguage_Id()+") or filmId IN(select filmId from film where originalLanguage="+langs.getLanguage_Id()+"))";
				}
				else 
				{
					sql+=" (filmId IN(select filmId from film_languages where languageId="+langs.getLanguage_Id()+") or filmId IN(select filmId from film where originalLanguage="+langs.getLanguage_Id()+"))";
				}
				count=4;
			}
			System.out.println("The sql query is: "+sql);
			try {
				PreparedStatement pst=con.prepareStatement(sql);
				ResultSet rs=pst.executeQuery();
				
				while(rs.next()){
					Film film1=new Film();
					film1.setFilm_ID(rs.getInt(1));
					film1.setTitle(rs.getString(2));
					film1.setDescription(rs.getString(3));
					film1.setReleaseYear(rs.getDate(4).valueOf(rs.getDate(4).toString()));
					film1.setRentalDuration(rs.getDate(6).valueOf(rs.getDate(6).toString()));
					film1.setLength(rs.getInt(7));
					film1.setReplacementCost(rs.getDouble(8));
					film1.setRatings(rs.getInt(9));
					film1.setSpecialFeatures(rs.getString(10));
					int categoryId=rs.getInt(11);
					Category category=getCategory(categoryId);
					film1.setCategory(category);
					Set<Actor> actors=new HashSet<>();
					List<Integer> actorId=getActorIds(film1.getFilm_ID());
					for(Integer actor2:actorId){
						actors.add(getActors(actor2));
					}
					film1.setActors(actors);
					int langID=rs.getInt(5);
					Language lang=getOriginalLanguage(langID);
					film1.setOriginalLanguage(lang);
					//Get List Other LAnguages
					List<Language> otherLangName=new ArrayList<>();
					List<Integer> otherLangId=getLanguageId(film1.getFilm_ID());
					for(Integer langId:otherLangId){
						
						otherLangName.add(getOriginalLanguage(langId));
					}
					film1.setLanguages(otherLangName);
					resFilm.add(film1);
					
					System.out.println(resFilm);
				}
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			
			
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
			
	
		
		return resFilm;
	}

	@Override
	public Film updateFilm(int id) {
		Film film1=new Film();
		Connection con=getConnection();
		String sqlUpd="select * from film where filmId=?";
		
		try {
			PreparedStatement pst=con.prepareStatement(sqlUpd);
			pst.setInt(1, id);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next()){
				//Film film1=new Film();
				
				//Get FilmId
				film1.setFilm_ID(rs.getInt(1));
				
				//Get Film Title
				film1.setTitle(rs.getString(2));
				
				//Get Film Description
				film1.setDescription(rs.getString(3));
				
				//Get Release Year
				film1.setReleaseYear(rs.getDate(4).valueOf(rs.getDate(4).toString()));
				
				//Get Original Language
				/*int orgLangId=rs.getInt(5);
				Language lang=getLanguages(orgLangId);*/
				
				//Get Rental Duration
				film1.setRentalDuration(rs.getDate(6).valueOf(rs.getDate(6).toString()));
				
				//Get Length
				film1.setLength(rs.getInt(7));
				
				//Get Replacement Cost
				film1.setReplacementCost(rs.getDouble(8));
				
				//Get Ratings
				film1.setRatings(rs.getInt(9));
			
				//Get special Features
				film1.setSpecialFeatures(rs.getString(10));
				
				//Get Category
				int categoryId=rs.getInt(11);
				Category category=getCategory(categoryId);
				film1.setCategory(category);
				//films.add(film1);
				
				
				
				
				/*film1.setCategory(rs.getString(11));*/
				
				//Get List of Actors
				Set<Actor> actors=new HashSet<>();
				List<Integer> actorId=getActorIds(film1.getFilm_ID());
				for(Integer actor:actorId){
					actors.add(getActors(actor));
				}
				film1.setActors(actors);
				//films.add(film1);
				
				//Get Original Language
				int langID=rs.getInt(5);
				Language lang=getOriginalLanguage(langID);
				film1.setOriginalLanguage(lang);
				//films.add(film1);
				
				
				
				//Get List Other LAnguages
				List<Language> otherLangName=new ArrayList<>();
				List<Integer> otherLangId=getLanguageId(film1.getFilm_ID());
				for(Integer langId:otherLangId){
					
					otherLangName.add(getOriginalLanguage(langId));
				}
				film1.setLanguages(otherLangName);
				//film.add(film1);
				
				//System.out.println(updFilm);
			}
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
		
		
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return film1;
	}

	@Override
	public int updatedFilm(int id, Film film) {
		int count=0;
		List<Film> updatedFilm=new ArrayList<>();
		Connection con=getConnection();
		String sql="update film set title=?,description=?,releaseYear=?,originalLanguage=?,rentalduration=?,length=?,replacementCost=?,rating=?,specialFeatures=?,category=? where filmId="+id;
		String sqlActDel="delete from film_actors where filmId=?";
		String sqlLanDel="delete from film_languages where filmId=?";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setString(1, film.getTitle());
			pst.setString(2,film.getDescription());
			pst.setDate(3,new Date(film.getReleaseYear().getTime()));
			pst.setInt(4,(film.getOriginalLanguage()).getLanguage_Id());
			pst.setDate(5, new Date(film.getRentalDuration().getTime()));
			pst.setInt(6, film.getLength());
			pst.setDouble(7, film.getReplacementCost());
			pst.setInt(8, film.getRatings());
			pst.setString(9, film.getSpecialFeatures());
			pst.setInt(10, film.getCategory().getCategory_Id());
			
			count=pst.executeUpdate();
			
			System.out.println("count is:"+count);
			
			if(count>0){
				//insert into third party tables
				
				//Getting Film Id
				int filmId=id;
				
				//Deleting Actors
				PreparedStatement pstAct=con.prepareStatement(sqlActDel);
				pstAct.setInt(1, filmId);
				pstAct.executeUpdate();
					
				//Deleting Languages
				PreparedStatement pstLan=con.prepareStatement(sqlLanDel);
				pstLan.setInt(1, filmId);
				pstLan.executeUpdate();
				
				//Inserting into Actor table
				String sqlActorAdd="insert into film_actors(filmId,actorId) values(?,?)";
				pst=con.prepareStatement(sqlActorAdd);
				
				Set<Actor> actors=film.getActors();
				for(Actor act:actors){
					pst.setInt(1, filmId);
					pst.setInt(2, act.getActor_Id());
					
					count=pst.executeUpdate();
				}
				
				//Inserting into Languages table
				String sqllanguageAdd="insert into film_languages(filmId,languageId) values(?,?)";
				pst=con.prepareStatement(sqllanguageAdd);
				
				List<Language> languages=film.getLanguages();
				for(Language lang:languages){
					pst.setInt(1, filmId);
					pst.setInt(2, lang.getLanguage_Id());
					
					count=pst.executeUpdate();
					
				}
				}	
			
			
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		
		
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return count;
	}

	@Override
	public List<Film> searchFilm2(String title) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int searchForRemove(Film film) {
		int resFilmId=0;
		
		
		return resFilmId;
	}

	@Override
	public int removeFilmById(int opt1) {
		int count=0;
		String sql="delete from film where filmId=?";
		String sql1="delete from film_languages where filmId=?";
		String sql2="delete from film_actors where filmId=?";
		Connection con=getConnection();
		try {
			PreparedStatement pst1=con.prepareStatement(sql);
			pst1.setInt(1, opt1);
			count=pst1.executeUpdate();
			
			PreparedStatement pst2=con.prepareStatement(sql1);
			pst2.setInt(1, opt1);
			count=pst2.executeUpdate();
			
			PreparedStatement pst3=con.prepareStatement(sql2);
			pst3.setInt(1, opt1);
			count=pst3.executeUpdate();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		try {
			con.close();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		return count;
	}

	@Override
	public int removeFilmByTitle(String opt3) {
		int count=0;
		int filmId=0;
		String sql="select filmId from film where title=?";
		String sql1="delete from film where filmId=?";
		String sql2="delete from film_languages where filmId=?";
		String sql3="delete from film_actors where filmId=?";
		Connection con=getConnection();
		
		try {
			PreparedStatement pst1=con.prepareStatement(sql);
			pst1.setString(1, opt3);
			ResultSet rs=pst1.executeQuery();
			
			while(rs.next()){
				filmId=rs.getInt(1);
			}
			
			
			PreparedStatement pst2=con.prepareStatement(sql1);
			pst2.setInt(1, filmId);
			count=pst2.executeUpdate();
			
			PreparedStatement pst3=con.prepareStatement(sql2);
			pst3.setInt(1, filmId);
			count=pst3.executeUpdate();
			
			PreparedStatement pst4=con.prepareStatement(sql3);
			pst4.setInt(1, filmId);
			count=pst4.executeUpdate();
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return count;
	}

	@Override
	public int removeFilmByRating(int rating) {
		int count=0;
		int filmId=0;
		String sql="select filmId from film where rating=?";
		String sql1="delete from film where filmId=?";
		String sql2="delete from film_languages where filmId=?";
		String sql3="delete from film_actors where filmId=?";
		Connection con=getConnection();
		
		try {
			PreparedStatement pst1=con.prepareStatement(sql);
			pst1.setInt(1, rating);
			ResultSet rs=pst1.executeQuery();
			
			while(rs.next()){
				filmId=rs.getInt(1);
			}
			
			
			PreparedStatement pst2=con.prepareStatement(sql1);
			pst2.setInt(1, filmId);
			count=pst2.executeUpdate();
			
			PreparedStatement pst3=con.prepareStatement(sql2);
			pst3.setInt(1, filmId);
			count=pst3.executeUpdate();
			
			PreparedStatement pst4=con.prepareStatement(sql3);
			pst4.setInt(1, filmId);
			count=pst4.executeUpdate();
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		return count;
	}
	
	

	
	
	

	
	}

	

