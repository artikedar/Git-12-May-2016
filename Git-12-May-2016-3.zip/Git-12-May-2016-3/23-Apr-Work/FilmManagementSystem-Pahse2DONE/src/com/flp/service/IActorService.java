package com.flp.service;

import java.util.Set;


import com.flp.fms.domain.Actor;

public interface IActorService {
	public Set<Actor> getActors();
}
