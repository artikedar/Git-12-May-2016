package com.flp.fms.util;

import static org.junit.Assert.*;


import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;


import org.junit.Test;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;

public class Testing {
	ActorServiceImpl service=new ActorServiceImpl();
	FilmServiceImpl  serviceFilm=new FilmServiceImpl();

	//TEST CASES FOR ADD ACTOR METHOD
	//1.Object is null
	//2.All mandatory fields should be filled
	//3.duplicate actor entry should not be allowed
	//4.All entries are valid and non duplicate

	@Test
	public void ActorObjectIsNull() throws ParseException
	{

		Actor actor=null;
		assertEquals(service.addActor(null),"Actor object null");
	}

	@Test
	public void AllMandatoryActorFieldsAreThereDuringAddition() throws ParseException
	{

		String strDate = "1990-01-01";
		DateFormat formatter = new SimpleDateFormat("yyyy-mm-dd");

		java.util.Date date = formatter.parse(strDate);
		java.sql.Date sqlDate = new java.sql.Date(date.getTime());
		Actor actor=new Actor("Salman","",sqlDate,"https://www.google.com");
		assertEquals(service.addActor(actor),"Some mandatory fields are misiing");

	}

	@Test
	public void NoDuplicateActorEntryAllowed() throws ParseException
	{

		String strDate = "1990-01-01";
		DateFormat formatter = new SimpleDateFormat("yyyy-mm-dd");

		java.util.Date date = formatter.parse(strDate);
		java.sql.Date sqlDate = new java.sql.Date(date.getTime());
		Actor actor=new Actor("ranbir3","kapoor", sqlDate,"http://abc.com");
		assertNotNull(service.addActor(actor));

	}

	@Test
	public void AllEntriesAreValidAndNoDuplicates() throws ParseException
	{

		String strDate = "1990-02-02";
		DateFormat formatter = new SimpleDateFormat("yyyy-mm-dd");

		java.util.Date date = formatter.parse(strDate);
		java.sql.Date sqlDate = new java.sql.Date(date.getTime());
		Actor actor=new Actor("Shrggaddh","Aaarmaniaa",sqlDate,"http://abc.com");
		assertNotNull(service.addActor(actor),"Actor added");


	}

	//TEST CASES FOR MODIFY ACTOR METHOD
	//1.Object should not be null
	//2.Mandatory fields should be there
	//3.Successfully updated

	@Test
	public void NullObjectIsPassedDuringModify() throws Exception
	{

		Actor actor=null;
		assertEquals(service.modifyActor("","",null),"Actor object null");
	}

	@Test
	public void MandatoryFieldsShouldBePresentDuringModification() throws Exception
	{
		String strDate = "1990-02-02";
		DateFormat formatter = new SimpleDateFormat("yyyy-mm-dd");

		java.util.Date date = formatter.parse(strDate);
		java.sql.Date sqlDate = new java.sql.Date(date.getTime());
		Actor actor=new Actor("","",sqlDate,"http://abc.com");

		assertEquals(service.modifyActor("Shraddha","Kapoor",actor),"Some mandatory fields are misiing");
	}

	@Test
	public void CouldNotSearchTheActorTobeUpdated() throws Exception
	{

		String strDate = "1990-02-02";
		DateFormat formatter = new SimpleDateFormat("yyyy-mm-dd");

		java.util.Date date = formatter.parse(strDate);
		java.sql.Date sqlDate = new java.sql.Date(date.getTime());
		Actor actor=new Actor("alia","bhatt",sqlDate,"http://abc.com");

		assertNotNull(service.modifyActor("ee","fff",actor),"S Kapoor not present");

	}

	@Test
	public void AllFieldsAreValidandSuccessfullyUpdated() throws Exception
	{
		String strDate = "1990-02-02";
		DateFormat formatter = new SimpleDateFormat("yyyy-mm-dd");

		java.util.Date date = formatter.parse(strDate);
		java.sql.Date sqlDate = new java.sql.Date(date.getTime());
		Actor actor=new Actor("Shraddha","Kapoor2",sqlDate,"http://abc.com");

		assertNotNull(service.modifyActor("raju","reddy",actor),"Actor successfully updated");

	}



	//TEST CASES FOR SEARCH ACTOR
	//1.name not null
	//2.should return collection
	//3.name must be present


	@Test
	public void WhenNamePassedIsNull()
	{
		assertEquals(service.searchActor(null),null);
	}

	@Test
	public void WhenNameIsNotFound()
	{
		assertEquals(service.searchActor("rohi"),null);
	}


	@Test
	public void WhenCollectionIsReturned() throws ParseException
	{

		String strDate = "1950-01-01";
		DateFormat formatter = new SimpleDateFormat("yyyy-mm-dd");
		java.util.Date date = formatter.parse(strDate);
		java.sql.Date sqlDate = new java.sql.Date(date.getTime());

		Actor actor=new Actor("rishi","kapoor",sqlDate,"abc.com");
		actor.setActorId(10);


		String strDate2 = "2016-04-08";
		DateFormat formatter2 = new SimpleDateFormat("yyyy-mm-dd");
		java.util.Date date2 = formatter.parse(strDate);
		java.sql.Date sqlDate2 = new java.sql.Date(date.getTime());
		actor.setCreateDate(sqlDate2);

		String strDate3 = "2016-04-08";
		DateFormat formatter3 = new SimpleDateFormat("yyyy-mm-dd");
		java.util.Date date3 = formatter.parse(strDate);
		java.sql.Date sqlDate3 = new java.sql.Date(date.getTime());
		actor.setDeleteDate(sqlDate3);

		ArrayList<Actor> actorList=new ArrayList<Actor>();
		actorList.add(actor);


		assertEquals((service.searchActor("rishi").get(0).getActorId()),10);
	}


	//TEST CASES FOR ADD FILM
	//1.Film object should not be null
	//2.All mandatory film fields should be there
	//3.When length of the movie is lesser than 10 and greater than 200 minutes
	//4.When duplicate film entry is present
	//5.When valid film entries are present and film successfully added

	@Test
	public void WhenFilmObjectIsNull()
	{

		assertEquals(serviceFilm.addFilm(null),"Film object null");
	}


	@Test
	public void WhenAnyOfTheFilmMandatoryFieldIsNotGiven()
	{

		Film film=new Film("","hiiiiii","1999-09-12",30,3,null);

		assertEquals(serviceFilm.addFilm(film),"Some mandatory fields are missing or Length is invalid");
	}

	@Test
	public void WhenLengthOfMovieIsLesserThan10AndGreaterThan200()
	{
		Language lang=new Language("Hindi");
		Film film=new Film("hello","hiiiiii","1999-09-12",9,3,lang);

		assertEquals(serviceFilm.addFilm(film),"Some mandatory fields are missing or Length is invalid");
	}


	@Test
	public void WhenFilmDuplicateEntryIsFilled()
	{
		Language lang=new Language("Hindi");
		Film film=new Film("kung fu panda 3","niceeeeeee","2016",180,4,lang);
		assertNotNull(serviceFilm.addFilm(film),"Duplicate entry present");

	}


	@Test
	public void WhenFilmEntriesAreValidAndNonDuplicateAndHenceSuccessfullyAdded()
	{
		Language lang=new Language("Punjabi");
		Film film=new Film("ambarsariya","diljeeeeeeet","2017",170,3,lang);
		assertEquals(serviceFilm.addFilm(film),"Film added");

	}

	//TEST CASES FOR MODIFY FILM
	//1.Film Object Should not be null
	//2.All mandatory fields must be present
	//3.Film object must be present
	//4.Film successfully updated


	@Test
	public void WhenFilmObjectIsNullDuringUpdation()
	{
		assertEquals(serviceFilm.modifyFilm("fan","2016",null),"Film object null");
	}

	@Test
	public void WhenDuringUpdationFilmMandatoryFieldsAreNotGiven()
	{
		Language lang=new Language("Hindi");
		Film film=new Film("","hiiiiii","1999-09-12",30,3,lang);

		assertEquals(serviceFilm.modifyFilm("fan","2016",film),"Some mandatory fields are missing or Length is invalid");
	}

	@Test
	public void WhenFilmToBeUpdatedIsNotPresent()
	{
		Language lang=new Language("Hindi");
		Film film=new Film("hello","hiiiiii","1999-09-12",30,3,lang);

		assertEquals(serviceFilm.modifyFilm("superman","2016",film),"Film not present");
	}

	@Test
	public void WhenAllFilmDetailsAreValidAndNonDuplicateAndHenceSuccessfullyUpdated()
	{
		Language lang=new Language("urdu");
		Film film=new Film("fan2","geruuuuuaaaaa againnnn","2018",60,4,lang);

		assertEquals(serviceFilm.modifyFilm("teddy","2018",film),"Film successfully updated");
	}



	//TEST CASES FOR SEARCH FILM

	//TEST CASES FOR SEARCH FILM BY TITLE
	//1.Film object not found during search film by title
	//2.Film title not found
	//3.Film Successfully searched by title

	@Test
	public void WhenFilmObjectDuringSearchingByTitleIsNull()
	{

		assertEquals(serviceFilm.searchByTitle(null),null);
	}

	@Test
	public void WhenFilmObjectIsNotNullButFilmTitleNotFound()
	{
		assertEquals(serviceFilm.searchByTitle("ambarsgc"),null);
	}

	@Test
	public void WhenFilmTitleIsSuccessfullySearched()
	{

		assertNotNull(serviceFilm.searchByTitle("meangirl"));

	}


	//TEST CASES FOR SEARCH FILM BY RELEASE YEAR
	//1.Film object not found during search film by release year
	//2.Film release year not found
	//3.Film Successfully searched by release year


	@Test
	public void WhenFilmObjectDuringSearchingByReleaseYearIsNull()
	{

		assertEquals(serviceFilm.searchByReleaseYear(null),null);
	}

	@Test
	public void WhenFilmObjectIsNotNullButFilmReleaseYearNotFound()
	{
		assertEquals(serviceFilm.searchByReleaseYear("2000"),null);
	}

	@Test
	public void WhenFilmReleaseYearIsSuccessfullySearched()
	{

		assertNotNull(serviceFilm.searchByReleaseYear("2014"));

	}


	//TEST CASES FOR SEARCH FILM BY RATING
	//1.Film object not found during search film by rating
	//2.Film rating not found
	//3.Film Successfully searched by rating


	@Test
	public void WhenFilmObjectDuringSearchingByRatingIsNull()
	{

		assertEquals(serviceFilm.searchByRating(null),null);
	}


	@Test
	public void WhenFilmObjectIsNotNullButFilmRatingNotFound()
	{
		assertEquals(serviceFilm.searchByRating("0"),null);
	}


	@Test
	public void WhenFilmRatingIsSuccessfullySearched()
	{
		assertNotNull(serviceFilm.searchByRating("4"));
	}



	//TEST CASES FOR SEARCH FILM BY LANGUAGE
	//1.Film object not found during search film by language
	//2.Film language not found
	//3.Film Successfully searched by language


	@Test
	public void WhenFilmObjectDuringSearchingByLanguageIsNull()
	{

		assertEquals(serviceFilm.searchByLanguage(null),null);
	}


	@Test
	public void WhenFilmObjectIsNotNullButFilmLanguageNotFound()
	{
		assertEquals(serviceFilm.searchByLanguage("Telugu"),null);
	}


	@Test
	public void WhenFilmLanguageIsSuccessfullySearched()
	{

		equals(serviceFilm.searchByLanguage("hindi"));

	}



	//TEST CASES FOR SEARCH FILM BY ACTOR
	//1.Film object not found during search film by actor
	//2.Film actor not found
	//3.Film Successfully searched by actor

	@Test
	public void WhenActorPassedIsNullDuringSearcFilmByActor()
	{
		assertEquals(serviceFilm.searchByActor(null),null);
	}

	@Test
	public void WhenActorPassedIsNotNullButCorrespondingFilmIsNotSearched()
	{
		assertEquals(serviceFilm.searchByActor("baltej"),null);
	}

	@Test
	public void WhenActorPassedIsValidAndFilmIsSuccessfullySearched()
	{
		assertNotNull(serviceFilm.searchByActor("aaa"));
	}


	//TEST CASES FOR SEARCH FILM BY CATEGORY	
	//1.Film object not found during search film by category
	//2.Film category not found
	//3.Film Successfully searched by category

	@Test
	public void WhenCategoryPassedIsNullDuringSearcFilmByCategory()
	{
		assertEquals(serviceFilm.searchByCategory(null),null);
	}

	@Test
	public void WhenCategoryPassedIsNotNullButCorrespondingFilmIsNotSearched()
	{
		assertEquals(serviceFilm.searchByCategory("FICT"),null);
	}

	@Test
	public void WhenCategoryPassedIsValidAndFilmIsSuccessfullySearched()
	{
		assertNotNull(serviceFilm.searchByCategory("action"));
	}



}
