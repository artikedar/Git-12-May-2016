package com.flp.fms.dao;

import java.util.Set;

import com.flp.fms.domain.Actor;

public interface IActorDao {

	public Set<Actor> getActors();
	public int addActor(Actor actor);
	public int removeActor(int id);
	
	public Actor searchActorByID(int id);
	public int updateActor(Actor actor, int actorId);
}
