package com.flp.fms.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
//import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.dao.ActorDaoImplForDatabase;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;

public class AddFilm extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	
		Film film=new Film();
		
		film.setTitle(request.getParameter("title"));
		
		film.setDescription(request.getParameter("desc"));
		
		String releaseYear=request.getParameter("releaseYear");
		Date releaseYear1=new Date(releaseYear);
		film.setRelease_Year(releaseYear1);
		
		Language originallang=new Language();
		int originalLangId=Integer.parseInt(request.getParameter("originalLang"));
		originallang.setLanguage_Id(originalLangId);
		film.setOriginal_Langauges(originallang);
		
		String rentalDuration=request.getParameter("rentalduration");
		Date rentalDuration1=new Date(rentalDuration);
		film.setRental_Duration(rentalDuration1);
		
		int len=Integer.parseInt(request.getParameter("length"));
		film.setLength(len);
		
		int replacementCost=Integer.parseInt(request.getParameter("cost"));
		film.setReplacement_Cost(replacementCost);
		
		int ratings=Integer.parseInt(request.getParameter("rating"));
		film.setRating(ratings);
		
		film.setSpecial_Features(request.getParameter("specialFeatures"));
		
		Category category=new Category();
		int categoryId=Integer.parseInt(request.getParameter("category"));
		category.setCategory_Id(categoryId);
		film.setCategory(category);
		

		Set<Actor> actor=new HashSet<>();
		
		String[] actorArray=request.getParameterValues("actor");
		for(String actor1:actorArray)
		{
			Actor actors=new Actor();
			actors.setActor_Id(Integer.parseInt(actor1));
			actor.add(actors);
		}
		film.setActors(actor);
		
		List<Language> language=new ArrayList<>();
		
		
		String[] otherLang=request.getParameterValues("Lang");
		for(String otherlang1:otherLang)
		{
			Language otherLanguages=new Language();
			otherLanguages.setLanguage_Id(Integer.parseInt(otherlang1));
			language.add(otherLanguages);
		}
		film.setLanguages(language);
		
		System.out.println(film);
		IFilmService ifilmservice=new FilmServiceImpl();
		ifilmservice.addFilm(film);
		
	}

}
