package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.dao.FilmDaoImplForDatabase;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;


public class ListAllFilms extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		FilmServiceImpl filmservice=new FilmServiceImpl();
		List<Film> allFilms=filmservice.getAllFilms();
		
		
		PrintWriter out=response.getWriter();
		
		
		out.println("<html>");
		out.println("<head><center><b>List of All Films<b></center></head>"
				+"<body>"
				+ "<table border=4px>"
				+"<tr>"
				+"<th>Film ID</th>"
				+"<th>Title</th>" 
				+"<th>Description</th>" +
				"<th> Release Year</th>" +
				"<th>Original Language</th>" +
				"<th>Rental Duration</th>" +
				"<th>Length</th>" +
				"<th>Replacement Cost</th>" +
				"<th>Ratings</th>" +
				"<th>Special Features</th>" +
				"<th>Category</th>" +
				"<th>Other Languages</th>" +
				"<th>Actors</th>" +
				"</tr>"
				);
			
		
		for(Film film:allFilms)
		{
		
			out.println("<tr>");
			out.println("<td>" +film.getFilmId()+"</td>");
			out.println("<td>"+film.getTitle()+"</td>");
			out.println("<td>"+film.getDescription()+"</td>");
			out.println("<td>"+film.getRelease_Year()+"</td>");
			out.println("<td>"+film.getOriginal_Langauges().getLanguage_Name()+"</td>");
			out.println("<td>"+film.getRental_Duration()+"</td>");
			out.println("<td>"+film.getLength()+"</td>");
			out.println("<td>"+film.getReplacement_Cost()+"</td>");
			out.println("<td>"+film.getRating()+"</td>");
			out.println("<td>"+film.getSpecial_Features()+"</td>");
			out.println("<td>"+film.getCategory().getCategory_Name()+"</td>");
			
			List<Language>langs=new ArrayList<>();
			langs=film.getLanguages();
			out.println("<td>");
			for(Language lang:langs)
				out.println(lang.getLanguage_Name()+",");
				out.println("</td>");
			
			Set<Actor> actors =new HashSet<>();
			actors=film.getActors();
			out.println("<td>");
			for(Actor act:actors)
				out.println(act.getActor_First_Name()+" "+act.getActor_Last_Name());
				out.println("</td>");
			out.println("</tr>");
			
		}
		out.println("</table></body>");
		
		out.println("</html>");
		
		
	}

}
