package com.flp.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

import com.flp.fms.domain.Actor;

public class ActorDaoImplForDatabase implements IActorDao{

	@Override
	public Set<Actor> getActors() {
	
		Set<Actor> actors=new HashSet<Actor>();
		DatabaseConnection connection = new DatabaseConnection();
		Connection newconnection=  connection.getConnection();
		Set<Actor> actors1 = new HashSet<>();
		
		//execute query
		boolean flag=false;
		String sql = "select * from actor";
		PreparedStatement stmt;
		try {
			
			stmt = newconnection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();	
			
			while(rs.next())
			{
				Actor actor = new Actor();
				
				actor.setActor_Id(rs.getInt(1));
				actor.setActor_First_Name(rs.getString(2));
				
				actor.setActor_Last_Name(rs.getString(3));
				actors1.add(actor);
			}
			
			flag = true;
			} 
		catch (SQLException e) {
			e.printStackTrace();
		}
		
		return actors1;
	}

	@Override
	public int addActor(Actor actor) {
		DatabaseConnection connection = new DatabaseConnection();
		Connection newconnection= connection.getConnection();
		String sql="insert into Actor(FirstName,LastName)"
				+ "	 values(?,?)";
		
		int count=0;
		try {
			PreparedStatement pst=newconnection.prepareStatement(sql);
			pst.setString(1, actor.getActor_First_Name());
			pst.setString(2, actor.getActor_Last_Name());
			
			count=pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			newconnection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}

	@Override
	public int removeActor(int id) {
		int count=0, count1;
		
	DatabaseConnection connection = new DatabaseConnection();
	Connection newconnection= connection.getConnection();
		
		String  sql="delete from Actor where Actor_id=?";
		String sql1="delete from film_actors where actor_id=?";
		
		try {
			PreparedStatement pst=newconnection.prepareStatement(sql);
			pst.setInt(1, id);
			count=pst.executeUpdate();
			
			
			PreparedStatement pst1=newconnection.prepareStatement(sql1);
			pst1.setInt(1, id);
			count=pst1.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		return count;
	
	}

	@Override
	public Actor searchActorByID(int id) {
		
		 Actor actor=new Actor();
		 DatabaseConnection connection = new DatabaseConnection();
		 Connection newconnection= connection.getConnection();
		 
		 String sql="select * from ACTOR where actor_id=?";
			
			try {
				PreparedStatement pst=newconnection.prepareStatement(sql);
				pst.setInt(1, id);
				ResultSet rs=pst.executeQuery();
				
				
				while(rs.next())
				{
					actor.setActor_First_Name(rs.getString(2));
					actor.setActor_Last_Name(rs.getString(3));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return actor;
	}

	@Override
	public int updateActor(Actor actor, int actorId) {
		int count=0;
		
		DatabaseConnection connection = new DatabaseConnection();
		Connection newconnection= connection.getConnection();
	    String sql="update Actor set FirstName=?,LastName=? where actor_id=?";
	    
	    
	    try {
			PreparedStatement pst=newconnection.prepareStatement(sql);
			pst.setString(1, actor.getActor_First_Name());
			pst.setString(2, actor.getActor_Last_Name());
			pst.setInt(3, actorId);
			
			
			count=pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	
	        return count;
}

	


		
		
		
		
		
		/*actors.add(new Actor(101,"Seema","Mane"));
		actors.add(new Actor(102,"Priya","Salunke"));
		actors.add(new Actor(103,"Priyanka","Chopra"));
		actors.add(new Actor(104,"Yuvraj","Singh"));
		actors.add(new Actor(105,"Shewta","Kokate"));
		actors.add(new Actor(106,"Jarin","Khan"));
		actors.add(new Actor(107,"Asin","Devgan"));
		actors.add(new Actor(108,"Kajol","Kapoor"));
		return actors;*/
	

}
