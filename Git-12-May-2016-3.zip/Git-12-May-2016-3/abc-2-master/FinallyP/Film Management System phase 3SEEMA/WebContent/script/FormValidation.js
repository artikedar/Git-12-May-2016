/*function formValidation(){
	
	var flag = true;
	var title1 = film.title.value;
	var length1 = film.length.value;
	var ratings = film.rating.value;
	var rentalDuration=document.getElementById("datepicker1").value;
	var releaseDate=document.getElementById("datepicker").value;
	var specialFeatures1=film.specialFeatures.value;
	var replacementCost=film.cost.value;
	
	if(title1==""||title1==null||!isValidTitle()){
		
		document.getElementById("titleDiv").innerHTML="*Please enter a valid title";
		flag = false;
	}
	else
		document.getElementById("titleDiv").innerHTML="";
	
	if(length1==""||length1==null||!isValidLength()){
		
		document.getElementById("lengthDiv").innerHTML="*Please enter a value between 1 to 1000";
		flag = false;
	}
	else
		document.getElementById("lengthDiv").innerHTML="";
	
	
	if(rentalDuration==""||rentalDuration==null||!isValidateRentalDuration()){
		
		document.getElementById("renDur_Div").innerHTML="*Please enter a valid rental duration";
		flag = false;
		}
	else
		document.getElementById("renDur_Div").innerHTML="";
	
	
	if(specialFeatures1==""||specialFeatures1==null||!isValidSpecialFeatures()){
		
		document.getElementById("specialFeaturesDiv").innerHTML="*Please enter a valid Features";
		flag = false;
		}
	else
		document.getElementById("specialFeaturesDiv").innerHTML="";
	
	if(replacementCost==""||replacementCost==null||!isValidReplacementCost()){
		
		document.getElementById("replacementDiv").innerHTML="*Please enter a valid Cost";
		flag = false;
		}
	else
		document.getElementById("replacementDiv").innerHTML="";
	return flag;
}*/

function isValidTitle(){
	var title1 = film.title.value;
	var pattern=/[A-Za-z]+/;
	
	if(title1.match(pattern))
		{
		document.getElementById("titleDiv").innerHTML="";
		return true;
		}
	else
		{
		document.getElementById("titleDiv").innerHTML="*Please enter a valid title";
		
		return false;
		}
}

function isValidLength(){
	
	var length1 = film.length.value;
	
	if(length1==""||length1==null||isNaN(length1)|| length1<0 || length1>1000){
		document.getElementById("lengthDiv").innerHTML="*Please enter a value between 1 to 1000";
		return false;
	}
	else{
		document.getElementById("lengthDiv").innerHTML="";
		return true;
	}
}

function isValidateRentalDuration(){
	var releaseDate=document.getElementById("datepicker").value;
	var rentalDuration=document.getElementById("datepicker1").value;
	if((releaseDate>rentalDuration)){
		document.getElementById("renDur_Div").innerHTML="Please Enter A Date Greater than Release Date";
		//rentalDuration.focus();
		return false;
	}
	else{
		document.getElementById("renDur_Div").innerHTML="";
		return true;
	}
	
}

function isValidSpecialFeatures(){
	var specialFeatures1=film.specialFeatures.value;
	
	var pattern = /[A-Za-z0-9.,! ]+/;
	if((specialFeatures1.match(pattern))){
		document.getElementById("specialFeaturesDiv").innerHTML="";
		return true;
	}
	else{
		document.getElementById("specialFeaturesDiv").innerHTML="*Please Enter Valid Special Features";
		//specialFeaturesErr.focus();
		return false;
	}
}

/*function isValidReplacementCost(){
	var replacementCost=film.cost.value;
	
	if(isNaN(replacementCost)||replacementCost==0){
		document.getElementById("repCostErr").innerHTML="*Please Enter a Valid Replacement cost";
		replacementCost.focus();
		return false;
	}
	else{
		document.getElementById("repCostErr").innerHTML="";
		return true;
	}
}*/


function replacementCostValidation(){
	//var repCost=createfilm.cost.value;
	var replacementCost=film.cost.value;
	if(isNaN(replacementCost)||replacementCost==0){
		document.getElementById("replacementDiv").innerHTML="*Please Enter a Valid Replacement cost";
		//replacementDiv.focus();
		return false;
	}
	else{
		document.getElementById("replacementDiv").innerHTML="";
		return true;
	}
}

/*function titleValidation()  
{   
		var filmname=film.title.value;
		var letters = /^[A-Za-z]+$/;  
	
		if(filmname.match(letters))  
		{  
			document.getElementById("titleerr").innerHTML="";
			return true;  
		}  
		else  
		{  
			document.getElementById("titleerr").innerHTML="*Please enter Title starts with alphabet"; 
			filmname.focus();  
			return false;  
		}  
} 

function lengthValidation(){
	
	var filmlength=film.length.value;
	
	if(isNaN(filmlength) || filmlength<1 || filmlength>1000){
		
		document.getElementById("lengtherr").innerHTML="*Please enter length between 1 to 1000";
		lengtherr.focus();
		return false;
		
	}
	else
		{
		document.getElementById("lengtherr").innerHTML="";
		return true;
		}
}

function ratingValidation(){
	
	var ratings=film.rating.value;
	if(isNaN(ratings)||ratings>1||ratings<5){
		
		document.getElementById("ratingserr").innerHTML="";
		
		return true;
		
	}
		
	else {
		document.getElementById("ratingserr").innerHTML="*Please enter ratings between 1 to 5";
		return false;
	}
	
}

function specialFeatureValidation(){
	
	var specialfeatures=film.specialfeatures.value;
	
	var letters = /[A-Za-z0-9.,! ]+/;
	
	
	if(specialfeatures.match(letters))  
	{  
		document.getElementById("featureErr").innerHTML="";
		return true;  
	}  
	else  
	{  
		document.getElementById("featureErr").innerHTML="*Please enter valid Special Features"; 
		specialfeatures.focus();  
		return false;  
	} 
	
}*/