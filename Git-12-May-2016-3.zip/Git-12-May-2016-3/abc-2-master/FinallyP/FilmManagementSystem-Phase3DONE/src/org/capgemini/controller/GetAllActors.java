package org.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.pojo.Actor;
import com.flp.service.ActorServiceImplDataBase;

/**
 * Servlet implementation class GetAllActors
 */
public class GetAllActors extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		ActorServiceImplDataBase actorService=new ActorServiceImplDataBase();
		Set<Actor> actor=actorService.getActors();
		


		out.println("<head>");
		out.print("<link rel='stylesheet' type='text/css' href='css/MyStyle.css'>");
		out.println("</head>");
		
		
		out.println("<body>"
				+ "<h2 align='center'>List of Actors</h2>"
				+ "<center>"
				+ "<table border='1'>"
				+ "<tr>"
				+ "<th>Actor Id</th>"
				+ "<th>First Name</th>"
				+ "<th>Last Name</th>"
				+ "</tr>");
		for(Actor actor1:actor){
			
			out.println("<tr>");
			out.println("<td>"+actor1.getActor_Id()+"</td>");
			out.println("<td>"+actor1.getFirst_Name()+"</td>");
			out.println("<td>"+actor1.getLast_Name()+"</td>");
			
			out.println("</tr>");
		}
			out.println("</table></center></body>");
	}

}
