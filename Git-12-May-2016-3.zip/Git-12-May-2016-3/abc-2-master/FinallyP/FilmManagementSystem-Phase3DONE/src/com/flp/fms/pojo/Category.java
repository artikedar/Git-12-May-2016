package com.flp.fms.pojo;

public class Category {
	
	
	private int category_Id;
	private String name;
	
	
	//No Argument Constructor
	public Category(){};
	
	//Constructor with Fields
	public Category(int category_Id, String name) {
		super();
		this.category_Id = category_Id;
		this.name = name;
		
	}
	
	//Getters and Setters
	public int getCategory_Id() {
		return category_Id;
	}
	public void setCategory_Id(int category_Id) {
		this.category_Id = category_Id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	//toString Method
	@Override
	public String toString() {
		return "Category [category_Id=" + category_Id + ", name=" + name + "]";
	}

	//hashCode Method
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + category_Id;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	//equals Method
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Category other = (Category) obj;
		if (category_Id != other.category_Id)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}



	
}
