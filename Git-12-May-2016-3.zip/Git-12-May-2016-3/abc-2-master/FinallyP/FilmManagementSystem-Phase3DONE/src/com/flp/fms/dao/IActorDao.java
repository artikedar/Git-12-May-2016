package com.flp.fms.dao;

import java.util.Set;

import com.flp.fms.pojo.Actor;

public interface IActorDao {

	Set<Actor> getActors();

	public int addActor(Actor actor);

	public int removeActor(int id);

	public Actor searchActorById(int id);

	public int updateActor(Actor actor, int id);
	
	
}
