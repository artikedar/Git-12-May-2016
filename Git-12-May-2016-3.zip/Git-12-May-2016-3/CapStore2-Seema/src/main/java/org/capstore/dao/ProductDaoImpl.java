package org.capstore.dao;

import java.util.ArrayList;
import java.util.List;

import org.capstore.domain.Brand;
import org.capstore.domain.Category;
import org.capstore.domain.Merchant;
import org.capstore.domain.Product;
import org.capstore.domain.Stock;
import org.capstore.domain.Sub_category;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;


@Repository("productDao")
public class ProductDaoImpl implements ProductDao{

	

	@Autowired
	public SessionFactory sessionFactory;
	
	@Override
	public List<Brand> getAllBrands() {
		List< Brand> brands=sessionFactory.getCurrentSession().createQuery("from Brand").list();
		
		//System.out.println(brands);
		
		return brands;
	}

	

	@Override
	public List<Sub_category> getAllSub_category() {
	List< Sub_category> sub_category=sessionFactory.getCurrentSession().createQuery("from Sub_category").list();
		
		//System.out.println(sub_category);
		
		return sub_category;
	}

	@Override
	public List<Stock> getAllStock() {
		
		List< Stock> stock=sessionFactory.getCurrentSession().createQuery("from Stock").list();
		
		//System.out.println(stock);
		
		return stock;
	}

	
	@Override
	public void saveProduct(Product product) {
		/* Session session = this.sessionFactory.getCurrentSession();
		session.beginTransaction();*/
		//System.out.println(product+"dao");
		sessionFactory.getCurrentSession().saveOrUpdate(product);
		//System.out.println("Commited");
		
		/*session.getTransaction().commit();*/
	}
	
	
	@Override
	public List<Product> getAllProducts() {
		
		return sessionFactory.getCurrentSession().createQuery("from Product").list();
	}



}
