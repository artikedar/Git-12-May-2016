package org.capstore.controller;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.capstore.domain.Product;
import org.capstore.service.CategoryService;
import org.capstore.service.MerchantService;
import org.capstore.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class ProductController {

	@Autowired
	public CategoryService categoryService;
	@Autowired
	public ProductService productservice;
	@Autowired
	public MerchantService merchantservice;
	@RequestMapping("/ProductForm")
	public String showProductForm(Map<String, Object> maps){
	/*	SimpleDateFormat myFormat=new SimpleDateFormat("dd-MMM-yyyy");
		List<Employee> employees= employeeService.getAllEmployees();
		maps.put("emps",employees);
		maps.put("empSearch",searchEmployee);*/
		maps.put("prod",new Product());
		maps.put("categorys", categoryService.getAllCategories());
		maps.put("brands", productservice.getAllBrands());
		maps.put("merchants", merchantservice.getAllMerchants());
		maps.put("sub_categories", productservice.getAllSub_category());
		//maps.put("stocks", productservice.getAllStock());
		 return "Product";
	}
	
	@RequestMapping(value={"/showProduct"},method=RequestMethod.POST)
	public String showProductDetails(Map<String, Object> map,
			@Valid @ModelAttribute("prod") Product prod, BindingResult result){
		/*List<Product> products= productservice.getAllProducts();
		map.put("products1",products);*/
		//map.put("empSearch",searchEmployee);
		//System.out.println(prod);
		/*if(result.hasErrors()){
			//System.out.println("Search Object:" + searchEmployee);
			//System.out.println(result);
			return "Product";
		}
		else{
			//searchEmployee=null;
			productservice.saveProduct(prod);
			return "redirect:/ProductForm";
		}*/
		productservice.saveProduct(prod);
		return "redirect:/ProductForm";
	}
	
	
	
}
