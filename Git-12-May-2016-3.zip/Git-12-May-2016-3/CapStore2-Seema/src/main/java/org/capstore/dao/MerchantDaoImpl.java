package org.capstore.dao;

import java.util.List;

import org.capstore.domain.Merchant;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;

@Repository(value="merchantDao")
public class MerchantDaoImpl implements MerchantDao{

	@Autowired
	public SessionFactory sessionFactory;
	
	
	
	@Override
	public void saveMerchant(Merchant merchant) {
	
		System.out.println("DAO"+merchant);
		sessionFactory.getCurrentSession().save(merchant);
	}
	
	@Override
	public List<Merchant> getAllMerchants() {
		
	List< Merchant> merchants=sessionFactory.getCurrentSession().createQuery("from Merchant").list();
		
		System.out.println(merchants);
		
		return merchants;
	}

}
