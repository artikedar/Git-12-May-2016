package org.capstore.service;

import java.util.List;

import org.capstore.pojo.Category;

public interface CategoryService {

	
	public List<Category> getAllCategories();
}
