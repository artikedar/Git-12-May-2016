package org.capgemini.service;

import java.util.ArrayList;

import org.capgemini.dao.LoginDao;
import org.capgemini.dao.loginDaoImpl;
import org.capgemini.pojo.LoginUser;

public class LoginServiceImpl implements LoginService{

	LoginUser loginUser=new LoginUser();
	LoginDao loginDao=new loginDaoImpl();
	@Override
	public void createForm(LoginUser loginUser) {
		loginDao.createForm(loginUser);
		
		
	}



	@Override
	public ArrayList<LoginUser> getAllDetails() {
		
		return loginDao.getAllDetails();
	}





	public void deleteForm(int custId) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public ArrayList<LoginUser> searchForm(int custId) {
		return loginDao.searchForm(custId);
		
	}

	
	

}
