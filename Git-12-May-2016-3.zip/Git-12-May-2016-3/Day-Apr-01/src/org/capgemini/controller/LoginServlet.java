package org.capgemini.controller;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.pojo.LoginUser;
import org.capgemini.service.LoginServiceImpl;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		LoginUser loginUser=new LoginUser();
		
		String custFName=request.getParameter("custFName");
		String custLName=request.getParameter("custLName");
		String custAddr=request.getParameter("custAddr");
		String gender=request.getParameter("gender");
		String regDate1=request.getParameter("regDate");
		Date regDate=new Date(regDate1);
		double regFees=Double.parseDouble(request.getParameter("regFees"));
		String custType=request.getParameter("custType");
		
		
		
		loginUser.setCustFName(custFName);
		loginUser.setCustLName(custLName);
		loginUser.setCustAddr(custAddr);
		loginUser.setGender(gender);
		loginUser.setRegDate(regDate);
		loginUser.setRegFees(regFees);
		loginUser.setCustType(custType);
		
		
		LoginServiceImpl loginServiceImpl=new LoginServiceImpl();
		loginServiceImpl.createForm(loginUser);
		
		request.getRequestDispatcher("pages/form.html").forward(request, response);
		
		
		
		
		
		
		
		
		
		
	}

}
