package org.capgemini.service;

import org.capgemini.pojo.LoginUser;

public interface LoginService {

	public void createForm(LoginUser loginUser);
	public void updateForm();
	public void deleteForm();
	public void getAllForm();
	
}
