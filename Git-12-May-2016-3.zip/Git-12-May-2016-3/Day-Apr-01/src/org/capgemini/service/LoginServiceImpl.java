package org.capgemini.service;

import org.capgemini.dao.LoginDao;
import org.capgemini.dao.LoginDaoImpl;
import org.capgemini.pojo.LoginUser;

public class LoginServiceImpl implements LoginService{

	LoginUser loginUser=new LoginUser();
	LoginDao loginDao=new LoginDaoImpl();
	@Override
	public void createForm(LoginUser loginUser) {
		loginDao.createForm(loginUser);
		
		
	}

	@Override
	public void updateForm() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteForm() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getAllForm() {
		// TODO Auto-generated method stub
		
	}

	
	

}
