package org.capgemini.pojo;

import java.util.Date;

public class LoginUser {
	private int custId;
	private String custFName;
	private String custLName;
	private String custAddr;
	private Date regDate;
	private double regFees;
	private String gender;
	private String custType;
	
	//NoArgument Constructor
		public LoginUser(){}
		
	//Argument Constructor
		public LoginUser(int custId, String custFName, String custLName, String custAddr, Date regDate, double regFees,
				String gender, String custType) {
			super();
			this.custId = custId;
			this.custFName = custFName;
			this.custLName = custLName;
			this.custAddr = custAddr;
			this.regDate = regDate;
			this.regFees = regFees;
			this.gender = gender;
			this.custType = custType;
		}
		
	//Getters and Setters
		public int getCustId() {
			return custId;
		}

		public void setCustId(int custId) {
			this.custId = custId;
		}

		public String getCustFName() {
			return custFName;
		}

		public void setCustFName(String custFName) {
			this.custFName = custFName;
		}

		public String getCustLName() {
			return custLName;
		}

		public void setCustLName(String custLName) {
			this.custLName = custLName;
		}

		public String getCustAddr() {
			return custAddr;
		}

		public void setCustAddr(String custAddr) {
			this.custAddr = custAddr;
		}

		public Date getRegDate() {
			return regDate;
		}

		public void setRegDate(Date regDate) {
			this.regDate = regDate;
		}

		public double getRegFees() {
			return regFees;
		}

		public void setRegFees(double regFees) {
			this.regFees = regFees;
		}

		public String getGender() {
			return gender;
		}

		public void setGender(String gender) {
			this.gender = gender;
		}

		public String getCustType() {
			return custType;
		}

		public void setCustType(String custType) {
			this.custType = custType;
		}
	
	//Override toString method
		@Override
		public String toString() {
			return "LoginUser [custId=" + custId + ", custFName=" + custFName + ", custLName=" + custLName + ", custAddr="
					+ custAddr + ", regDate=" + regDate + ", regFees=" + regFees + ", gender=" + gender + ", custType="
					+ custType + "]";
		}
	
	
	
	
	
	
}
