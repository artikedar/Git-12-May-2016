package org.capgemini.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.capgemini.pojo.LoginUser;

public class LoginDaoImpl implements LoginDao{

	public Connection getConnection(){ 
		Connection connection=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			DriverManager.getConnection("jdbc:mysql://localhost:3306/CAP", "root", "Pass1234");
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return connection;
		
	}
	
	
	@Override
	public void createForm(LoginUser loginUser) {
		Connection con=getConnection();
		String sql="insert into loginUser(firstName,lastName,address,gender,regDate,regFees,custType)" + "values(?,?,?,?,?,?,?)";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setString(1, loginUser.getCustFName());
			pst.setString(2, loginUser.getCustLName());
			pst.setString(3, loginUser.getCustAddr());
			pst.setString(4, loginUser.getGender());
			pst.setDate(5,new Date(loginUser.getRegDate().getTime()));
			pst.setDouble(6, loginUser.getRegFees());
			pst.setString(7, loginUser.getCustType());
			
			int count=pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	
}
