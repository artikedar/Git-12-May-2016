package org.capgemini.dao;

import org.capgemini.pojo.LoginUser;

public interface LoginDao {


	void createForm(LoginUser loginUser);

}
