package org.capstore.controller;

import java.security.Provider.Service;
import java.util.Map;

import org.capstore.daointerface.CustomerDaoInterface;
import org.capstore.pojo.products;
import org.capstore.service.impl.CustomerServiceImpl;
import org.capstore.serviceinterface.CustomerServiceInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloController {

	@Autowired
	CustomerServiceImpl service;
	
	@Autowired
	CustomerDaoInterface dao;
	
	
	
	@RequestMapping("/hello")
	public ModelAndView sayHello(){
		//String message="Hello Spring MVC";
		service.search();

		return service.search();
	}
	
	@RequestMapping("/search")
	public String showSearchCustomer(Map<String, Object> maps){
		maps.put("product", new products());
		
		return "searchResult";
	}
	
	
	@RequestMapping(value="/searching",method=RequestMethod.POST)
	public String showSearchResults(@ModelAttribute("product") products product, BindingResult result){
		System.out.println(product);
		return "showSerRes";
	}
	
	
	
	
	
	
}
