package org.capstore.serviceinterface;

import org.springframework.web.servlet.ModelAndView;

public interface CustomerServiceInterface {

	
	public ModelAndView search();
	
}
