package org.capstore.daointerface;


import org.springframework.web.servlet.ModelAndView;

public interface CustomerDaoInterface {

	public ModelAndView searchCustomer();
}
