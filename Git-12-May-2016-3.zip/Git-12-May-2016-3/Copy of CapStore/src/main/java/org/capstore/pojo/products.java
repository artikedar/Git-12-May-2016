package org.capstore.pojo;

import java.util.Date;

public class products {

	private int product_id;
	private String product_name;
	private int category_id;
	private int subCategory_id;
	private int brand_id;
	private String specification;
	private int price;
	private Date dateOfPosting;
	private int stock_id;
	private int merchant_id;
	private int no_Of_time_Visited;
	
	
	//No Argument Constructor 
	public products(){}
	
	//Constructor
	public products(int product_id, String product_name, int category_id, int subCategory_id, int brand_id,
			String specification, int price, Date dateOfPosting, int stock_id, int merchant_id, int no_Of_time_Visited) {
		super();
		this.product_id = product_id;
		this.product_name = product_name;
		this.category_id = category_id;
		this.subCategory_id = subCategory_id;
		this.brand_id = brand_id;
		this.specification = specification;
		this.price = price;
		this.dateOfPosting = dateOfPosting;
		this.stock_id = stock_id;
		this.merchant_id = merchant_id;
		this.no_Of_time_Visited = no_Of_time_Visited;
	}
	
	
	//Getters and Setters
	public int getProduct_id() {
		return product_id;
	}
	
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public int getCategory_id() {
		return category_id;
	}
	public void setCategory_id(int category_id) {
		this.category_id = category_id;
	}
	public int getSubCategory_id() {
		return subCategory_id;
	}
	public void setSubCategory_id(int subCategory_id) {
		this.subCategory_id = subCategory_id;
	}
	public int getBrand_id() {
		return brand_id;
	}
	public void setBrand_id(int brand_id) {
		this.brand_id = brand_id;
	}
	public String getSpecification() {
		return specification;
	}
	public void setSpecification(String specification) {
		this.specification = specification;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public Date getDateOfPosting() {
		return dateOfPosting;
	}
	public void setDateOfPosting(Date dateOfPosting) {
		this.dateOfPosting = dateOfPosting;
	}
	public int getStock_id() {
		return stock_id;
	}
	public void setStock_id(int stock_id) {
		this.stock_id = stock_id;
	}
	public int getMerchant_id() {
		return merchant_id;
	}
	public void setMerchant_id(int merchant_id) {
		this.merchant_id = merchant_id;
	}
	public int getNo_Of_time_Visited() {
		return no_Of_time_Visited;
	}
	public void setNo_Of_time_Visited(int no_Of_time_Visited) {
		this.no_Of_time_Visited = no_Of_time_Visited;
	}
	
	//toString Method
	@Override
	public String toString() {
		return "Inventory [product_id=" + product_id + ", product_name=" + product_name + ", category_id=" + category_id
				+ ", subCategory_id=" + subCategory_id + ", brand_id=" + brand_id + ", specification=" + specification
				+ ", price=" + price + ", dateOfPosting=" + dateOfPosting + ", stock_id=" + stock_id + ", merchant_id="
				+ merchant_id + ", no_Of_time_Visited=" + no_Of_time_Visited + "]";
	}
	
	
}
