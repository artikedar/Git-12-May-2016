package org.capstore.controller;

import java.util.Map;

import org.capstore.pojo.products;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


@Controller
@RequestMapping("/search")
public class SearchController {

	@RequestMapping("/search")
	public String showSearchCustomer(Map<String, Object> maps){
		maps.put("product", new products());
		
		return "searchResult";
	}
	
	
	@RequestMapping(value="/searching",method=RequestMethod.POST)
	public String showSearchResults(@ModelAttribute("product") products product, BindingResult result){
		System.out.println(product);
		return "showSerRes";
	}
	
	@RequestMapping("/inventory")
	public ModelAndView searchInventory(){
		String message="U are searching inventory";
		return new ModelAndView("inventorySearch","msg",message);
	}
}
