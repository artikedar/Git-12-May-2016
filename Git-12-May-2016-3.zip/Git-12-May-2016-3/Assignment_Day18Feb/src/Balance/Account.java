package Balance;

public class Account {
	
	public void display_Balance(){
		System.out.println("Display Balance");
	}

}
