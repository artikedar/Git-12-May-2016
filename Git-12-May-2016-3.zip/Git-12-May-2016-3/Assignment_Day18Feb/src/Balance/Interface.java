package Balance;

public interface Interface {
	public static final float PI=3.14f;
}
