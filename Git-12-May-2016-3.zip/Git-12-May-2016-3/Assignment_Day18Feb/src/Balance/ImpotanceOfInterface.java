package Balance;

abstract public class ImpotanceOfInterface implements Interface {
	public static void main(String[] args){
		
		float area;
		int r=4;
		area=PI*r*r;
		System.out.println("Area of Circle: "+area);
		}

	

}
