package DivisionModules;

public interface DivisionModules {
	
		public static final int num1=10;
		public static final int num2=2;
		

		void division();

		void modules();		
}


	
	


	
	
