package DivisionModules;

public class MainClass {
public static void main(String[] args){
	Overriding ov=new Overriding();
	ov.division();
	ov.modules();
}
}