package DivisionModules;

import java.util.Scanner;

public class Overriding implements DivisionModules{

@Override
public void division() {
	int ans;
	ans=num1/num2;
	System.out.println(ans);
	
}

@Override
public void modules() {
	int ans2;
	ans2=num1%num2;
	System.out.println(ans2);
	
}



	

}
