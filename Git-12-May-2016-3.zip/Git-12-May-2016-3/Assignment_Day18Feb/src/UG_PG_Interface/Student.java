package UG_PG_Interface;

public interface Student {
	public final int A=70;
	public final int B=60;
	public final int C=50;
	public final int D=40;
	
void Display_Grade();

void Attendance_PG_Students();

void Attendance_UG_Students();

}
