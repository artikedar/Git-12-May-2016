package UG_PG_Interface;

import java.util.Scanner;

public class OccurenceOfCharacter {

	public static void main(String[] args) {
		String str1;
		String str2;
		int count=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter string: ");
		str1=sc.next();
		System.out.println("Enter Character: ");
		str2=sc.next();
		
		for(int i=0;i<str1.length();i++){
			if(str2.charAt(0)==str1.charAt(i)){
				count++;
			}
			
		}
		if(count>0){
			System.out.println("Character "+str2+"is present and occurs "+count+ "times");
			}
		else
			System.out.println("Character is not present.");
		

	}

}
