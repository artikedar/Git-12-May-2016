package UG_PG_Interface;

public class StudentsData implements Student{

	@Override
	public void Display_Grade() {
		
	}

	@Override
	public void Attendance_PG_Students() {
	
	}

	@Override
	public void Attendance_UG_Students() {
	
	}

}
