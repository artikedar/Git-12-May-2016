package UG_PG_Interface;

import java.util.Scanner;

public class Palindrome {
public static void main(String[] args){
	String str1;
	String str2=new String();
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter String: ");
	str1=sc.next();
	for(int i=str1.length()-1;i>=0;i--){
		str2=str2+str1.charAt(i);
	}
	
	if(str1.equals(str2))
	System.out.println("Palindrome String");
	else
		System.out.println("Not a Palindrome String");
	
}
}
