package UG_PG_Interface;

import java.util.Scanner;

public class EncryptString{

	public static void main(String[] args) {
		String str1;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter String:");
		str1=sc.next();
		String str2="";
		for(int i=0;i<str1.length();i++){
			switch(str1.charAt(i)){
			case 'a':
			case 'A':str2=str2+'p';
				break;
			case 'b':
			case 'B':str2=str2+'q';
				break;
			case 'd':
			case 'D':str2=str2+'s';
				break;
			default:
				str2=str2+str1.charAt(i);
				
			}
			
		}System.out.println("Encrypted String is: "+str2);
		

	
	}
}
