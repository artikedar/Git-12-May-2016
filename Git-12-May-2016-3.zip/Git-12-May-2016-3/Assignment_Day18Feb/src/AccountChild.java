import Balance.Account;
public class AccountChild extends Account {

	public static void main(String[] args) {
		AccountChild a1= new AccountChild();
		a1.display_Balance();
	}

}
