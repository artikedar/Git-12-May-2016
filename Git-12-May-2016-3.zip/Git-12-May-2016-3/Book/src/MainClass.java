import java.util.Scanner;

public class MainClass {
	public static void main(String[] args){
		int option;
		String choice;
		Book book=new Book();
		BookDaoImplementation bookdaoimplementation=new BookDaoImplementation();
		Scanner sc=new Scanner(System.in);
		do{
		System.out.println("Enter Option: \n1.Save Book \n2.List All Books \n3.Search Book");
		option=sc.nextInt();
		
			if(option==1){
				book=book.getBookDetails();
				bookdaoimplementation.saveBook(book);
			}
			else if(option==2)
			bookdaoimplementation.listAllBooks();
			
			else if(option==3){
				System.out.println("Enter Book Id: ");
				int newBookId=sc.nextInt();
				bookdaoimplementation.searchBook(newBookId);
		}
			
		System.out.println("Wish to continue?[y/n]");
		choice=sc.next();
		}while(choice.charAt(0)=='Y' || choice.charAt(0)=='y');
		
	}

}
