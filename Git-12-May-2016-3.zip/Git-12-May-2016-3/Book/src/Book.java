import java.util.Scanner;

public class Book {
	public int bookId;
	public String bookName,author,publisher;
	public double price;
	
                        
	public Book getBookDetails(){
		Book book=new Book();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Book Id: ");
		book.bookId=sc.nextInt();
		System.out.println("Enter Book Name: ");
		book.bookName=sc.next();
		System.out.println("Enter Book Author: ");
		book.author=sc.next();
		System.out.println("Enter Book Publisher: ");
		book.publisher=sc.next();
		System.out.println("Enter Book Price: ");
		book.price=sc.nextDouble();
		
		return book;		
	}
	public void showBookDetails(){
		System.out.println("Book Id \tBook Name \tBook Author \tBook Publisher \tPrice ");
		System.out.println(bookId +"\t"+bookName +"\t"+author +"\t"+publisher +"\t"+price );
	}
	
	

}
