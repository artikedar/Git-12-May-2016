
public interface BookDAO {
	public void saveBook(Book book);
	public void listAllBooks();
	public void deleteBook();
	public void searchBook(int newBookId);
	

}
