
public class BookDaoImplementation implements BookDAO{
	Book[] books;
	int index;
	public BookDaoImplementation(){
		books=new Book[50];
	}
	
	@Override
	public void saveBook(Book book) {
		books[index]=book;
		index++;
		
	}

	@Override
	public void listAllBooks() {
		for(int i=0;i<index;i++){
			books[i].showBookDetails();
		}
	
	
	}
	@Override
	public void searchBook(int newBookId) {
		for(int i=0;i<index;i++){
			if(newBookId==bookId){
				
			}
		}
		
		
	}
	@Override
	public void deleteBook() {
		
		
	}
	


	
	
}
	

	


