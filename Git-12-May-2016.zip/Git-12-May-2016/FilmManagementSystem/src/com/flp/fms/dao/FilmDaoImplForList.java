package com.flp.fms.dao;

import java.util.ArrayList;
import java.util.List;

import com.flp.fms.domain.Language;

public class FilmDaoImplForList implements IFilmDao{

	@Override
	public List<Language> getLanguages() {
		List<Language> languages=new ArrayList<>();
		languages.add(new Language(1, "English"));
		languages.add(new Language(2, "Hindi"));
		languages.add(new Language(3, "Telegu"));
		languages.add(new Language(4, "Marati"));
		languages.add(new Language(5, "Kananta"));
		languages.add(new Language(6, "Tamil"));
		languages.add(new Language(7, "Malayalam"));
		
		
		return languages;
	}

}
