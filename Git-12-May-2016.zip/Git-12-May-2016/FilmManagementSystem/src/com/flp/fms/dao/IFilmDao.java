package com.flp.fms.dao;

import java.util.List;

import com.flp.fms.domain.Language;

public interface IFilmDao {
	
	public List<Language> getLanguages();

}
