package org.capstore.Dao;

import java.util.List;

import org.capstore.pojo.Category;

public interface ProductDao {
	
	public List<Category> getAllCategory();

}
