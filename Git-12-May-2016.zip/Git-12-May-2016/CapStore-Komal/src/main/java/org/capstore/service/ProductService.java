package org.capstore.service;

import java.util.List;

import org.capstore.pojo.Category;

public interface ProductService {
	public List<Category> getAllCategory();
}
