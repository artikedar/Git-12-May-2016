package org.capstore.controller;

import java.text.SimpleDateFormat;
import java.util.Map;

import org.capstore.pojo.Product;
import org.capstore.service.ProductService;
import org.capstore.service.ProductServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.sun.org.apache.regexp.internal.recompile;

@Controller
public class ProductController {
	
	
	ProductServiceImpl productService=new ProductServiceImpl();
	
	@RequestMapping("/product")
	public String showProductForm(Map<String, Object>maps){
	
		SimpleDateFormat simpleDate=new SimpleDateFormat("dd-MMM-yyyy");
		maps.put("product", new Product());
		maps.put("category", productService.getAllCategory());
		
		
	  return "product";		
	}
	
	
	
	

}
