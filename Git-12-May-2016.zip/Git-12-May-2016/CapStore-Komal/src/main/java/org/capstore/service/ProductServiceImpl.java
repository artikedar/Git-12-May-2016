package org.capstore.service;

import java.util.List;

import org.capstore.Dao.ProductDao;
import org.capstore.Dao.ProductDaoImpl;
import org.capstore.pojo.Category;
import org.springframework.transaction.annotation.Transactional;

public class ProductServiceImpl implements ProductService{

	ProductDaoImpl productDao=new ProductDaoImpl();
	
	
@Transactional
	public List<Category> getAllCategory() {
		// TODO Auto-generated method stub
		return productDao.getAllCategory();
	}

}
