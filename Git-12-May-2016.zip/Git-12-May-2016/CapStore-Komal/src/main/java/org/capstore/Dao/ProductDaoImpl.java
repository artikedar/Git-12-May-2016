package org.capstore.Dao;

import java.util.List;

import org.capstore.pojo.Category;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


@Repository
public class ProductDaoImpl implements ProductDao{
	
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public List<Category> getAllCategory() {
		
	return sessionFactory.getCurrentSession().createQuery("from Category").list();
	}

}
