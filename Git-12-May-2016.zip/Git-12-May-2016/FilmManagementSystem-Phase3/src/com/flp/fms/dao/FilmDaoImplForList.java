package com.flp.fms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class FilmDaoImplForList implements IFilmDao{
	
/*	private Map<Integer, Film> film_Repository=new HashMap<>();*/
	private List<Film> film_Repository=new ArrayList<>();
	
	
	public Connection getConnection(){
		Connection connection=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/filmdb", "root", "Pass1234");
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return connection;
	}
	
	@Override
	public List<Language> getLanguages() {
			List<Language> languages=new ArrayList<>();
			Connection con=getConnection();
			String sql="SELECT * FROM languages";
						
			try {
				Statement stm=con.createStatement();
				 ResultSet rs=stm.executeQuery(sql);
				 while(rs.next())
				 {
				Language language=new Language();
				language.setLanguage_Id(rs.getInt(1));
				language.setName(rs.getString(2));
				
				languages.add(language);
				 }
				
				
				
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			
			
			
			
			/*languages.add(new Language(1, "English"));
			languages.add(new Language(2, "Hindi"));
			languages.add(new Language(3, "Marathi"));
			languages.add(new Language(4, "Tamil"));
			languages.add(new Language(5, "Telegu"));
		*/
			return languages;
			}

	@Override
	public List<Category> getCategories() {
		List<Category> categories=new ArrayList<>();
		Connection con=getConnection();
		String sql="SELECT * FROM category";
		try {
			Statement stm=con.createStatement();
			ResultSet rs=stm.executeQuery(sql);
			while(rs.next())
			 {
			Category category=new Category();
			category.setCategory_Id(rs.getInt(1));
			category.setName(rs.getString(2));
			categories.add(category);
			 }
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		/*categories.add(new Category(1, "Horror"));
		categories.add(new Category(2, "Comedy"));
		categories.add(new Category(3, "Romance"));
		categories.add(new Category(4, "Drama"));
		categories.add(new Category(5, "Action"));
		categories.add(new Category(6, "Documentry"));*/
		
		return categories;
	}

	@Override
	public void addFilm(Film film) {
		Connection con=getConnection();
		String sql="insert into film(title,description,releaseYear,originalLanguage,rentalduration,length,replacementCost,rating,specialFeatures,category)"+"values(?,?,?,?,?,?,?,?,?,?)";
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setString(1, film.getTitle());
			pst.setString(2,film.getDescription());
			pst.setDate(3,new Date(film.getReleaseYear().getTime()));
			pst.setInt(4,(film.getOriginalLanguage()).getLanguage_Id());
			pst.setDate(5, new Date(film.getRentalDuration().getTime()));
			pst.setInt(6, film.getLength());
			pst.setDouble(7, film.getReplacementCost());
			pst.setInt(8, film.getRatings());
			pst.setString(9, film.getSpecialFeatures());
			pst.setInt(10, film.getCategory().getCategory_Id());
			
			int count=pst.executeUpdate();
			
			System.out.println(count);
			
			if(count>0){
				//insert into third party tables
				
				//Getting Film Id
				int filmId=0;
				String sqlFilmId="select * from film order by filmId desc limit 1";
				PreparedStatement pst2=con.prepareStatement(sqlFilmId);
				ResultSet rs2=pst2.executeQuery();
				while(rs2.next()){
					filmId=rs2.getInt(1);
				}
				
				//Inserting into Actor table
				String sqlActorAdd="insert into film_actors(filmId,actorId) values(?,?)";
				pst=con.prepareStatement(sqlActorAdd);
				
				Set<Actor> actors=film.getActors();
				for(Actor act:actors){
					pst.setInt(1, filmId);
					pst.setInt(2, act.getActor_Id());
					
					count=pst.executeUpdate();
				}
				
				//Inserting into Languages table
				String sqllanguageAdd="insert into film_languages(filmId,languageId) values(?,?)";
				pst=con.prepareStatement(sqllanguageAdd);
				
				List<Language> languages=film.getLanguages();
				for(Language lang:languages){
					pst.setInt(1, filmId);
					pst.setInt(2, lang.getLanguage_Id());
					
					count=pst.executeUpdate();
				}
						
			}
							
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	/*	film_Repository.put(film.getFilm_ID(), film);*/
		}

	@Override
	public List<Film> getAllFilms() {
		List<Film> films=new ArrayList<>();
		Connection con=getConnection();
		String sqlGetFilm="select * from film";
		try {
			PreparedStatement pst4=con.prepareStatement(sqlGetFilm);
			ResultSet rs=pst4.executeQuery();
			
			while(rs.next()){
				Film film1=new Film();
				
				film1.setFilm_ID(rs.getInt(1));
				film1.setTitle(rs.getString(2));
				film1.setDescription(rs.getString(3));
				film1.setReleaseYear(rs.getDate(4).valueOf(rs.getDate(4).toString()));
				/*film1.setOriginalLanguage(rs.getString(5));*/
				film1.setRentalDuration(rs.getDate(6).valueOf(rs.getDate(6).toString()));
				film1.setLength(rs.getInt(7));
				film1.setReplacementCost(rs.getDouble(8));
				film1.setRatings(rs.getInt(9));
				film1.setSpecialFeatures(rs.getString(10));
				/*film1.setCategory(rs.getString(11));*/
				
				films.add(film1);
				
				/*String sqlCategoryAdd="select * from category where "
				*/
				
				
				
			}
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		
		return films;
	}

	
	
	

	
	}

	

